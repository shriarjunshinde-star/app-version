#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Empire Trade Vault — one-command launcher
#
#   ./start.sh              start the server (installs nothing if deps exist)
#   ./start.sh --force      re-seed the demo vault first, then start
#   ./start.sh --reset      delete the database, seed a fresh vault, then start
#
# Dependencies live in ./deps/pkgs so the app keeps working even when
# node_modules is wiped by a fresh sandbox/snapshot. If they are missing, this
# script installs them once and moves them into deps/.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail
cd "$(dirname "$0")"

GOLD='\033[0;33m'; GREEN='\033[0;32m'; DIM='\033[2m'; NC='\033[0m'
say() { printf "${GOLD}▸${NC} %s\n" "$1"; }

DEPS="$PWD/deps/pkgs"
if [ ! -d "$DEPS/express" ] || [ ! -d "$DEPS/better-sqlite3" ] || [ ! -d "$DEPS/socket.io" ]; then
  say "dependencies missing → installing (one time, ~2 min)…"
  npm install --no-audit --no-fund
  mkdir -p deps
  rm -rf deps/pkgs
  mv node_modules deps/pkgs
  find deps -name "obj.target" -type d -exec rm -rf {} + 2>/dev/null || true
  find deps -name "test_extension.node" -delete 2>/dev/null || true
  say "dependencies vendored into deps/pkgs"
fi
export export NODE_PATH="$DEPS"
export NODE_OPTIONS="${NODE_OPTIONS:-} --max-old-space-size=512"

if [ "${1:-}" = "--reset" ]; then
  say "resetting the demo database…"
  rm -f data/empire.db data/empire.db-shm data/empire.db-wal
fi
if [ "${1:-}" = "--force" ] || [ "${1:-}" = "--reset" ]; then
  node server/seed.js --force || true
fi

say "starting Empire Trade Vault on http://localhost:${PORT:-3000}"
exec node server/boot.js "$@"
