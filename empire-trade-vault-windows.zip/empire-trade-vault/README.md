# Arjun — trading terminal, messenger & journal

A complete, multiuser trading platform built around the demo you shared — a **TradingView-style charting terminal**, a **messenger where chart analyses, photos and documents are shared into rooms** (analyses arrive as live objects, not screenshots), and a **trading journal with a process score computed from your real trade book**.

Everything is real code: Node + Express + Socket.IO + **SQLite** backend, **email accounts** (register by email, verification, password reset), live market data, a full REST API, file uploads for the messenger, and a hand-built frontend that talks to it. The original `empire-trade-vault.html` mock-up is kept and served at `/legacy/empire-trade-vault.html` (linked in the app under **System → Vault demo (v1)**).

---

## 1 · Run it

```bash
cd empire-trade-vault
./start.sh              # → http://localhost:3000
```

On **Windows** double-click **`start.bat`** (or run `npm start`). `start.sh` / `start.bat` / `npm start` all do the same thing:

* install dependencies once and **vendor them into `deps/pkgs`** if they are missing,
* create `data/arjun.db` and **seed the demo desk automatically** when the database is empty (~30-60 s, it fetches live prices),
* then start the server on `PORT` (default 3000).

```bash
npm start -- --seed     # re-seed users, trades, journals and rooms
npm start -- --reset    # wipe the database, seed a brand-new desk, start
```

**Deploying?** `Dockerfile`, `docker-compose.yml`, `render.yaml`, `fly.toml` and `.env.example` are included — see **[DEPLOY.md](DEPLOY.md)** for Render / Fly.io / VPS-in-Docker walkthroughs, SMTP setup, backups and the go-live checklist.

### Sign in

The fastest way: press **“Enter the demo vault as Arjun Shinde”** on the login screen — one click, no typing.

| user | password | who |
|---|---|---|
| **`arjunshinde`** | **`arjun123`** | **Arjun Shinde — owner/admin, $250,000 vault** |
| `trader` | `empire123` | Vikram Rao — discretionary day trader |
| `mentor` | `empire123` | Meera Nair — 15-year desk veteran |
| `riya` | `empire123` | Riya Sharma — swing trader, crypto |
| `arjun` | `empire123` | Arjun Mehta — BankNifty scalper |

Every demo account also has an email (`arjun.shinde@arjun.trade`, `vikram@`, `meera@`, `riya@`, `arjun.mehta@arjun.trade`) so **sign in with the email address** works out of the box.

Prefer your own account? Use **Create account** — email + password, you get a paper account, a journal and access to every room. Verification and password-reset links are emailed (SMTP) or, while SMTP is unset, printed to the server console and shown in the app.

> If the login card ever says **“server offline”**, the API process is not running: start it with `./start.sh`. The sign-in screen pings `/api/health` and tells you which of the two it is (server down vs. wrong password).

Environment knobs (full list in `.env.example`): `PORT`, `PUBLIC_URL`, `ALLOWED_ORIGINS`, `JWT_SECRET`, `JWT_EXPIRES`, `DATA_DIR` / `DB_PATH`, `UPLOAD_DIR`, `MAX_UPLOAD_MB`, `REQUIRE_EMAIL_VERIFICATION`, `SMTP_HOST` / `SMTP_PORT` / `SMTP_USER` / `SMTP_PASS` / `MAIL_FROM`, `OWNER_PASSWORD`, `TRUST_PROXY`, `ALLOW_IFRAME`, `TICK_MS`.

---

## 2 · What's in it

### Terminal (`/` → Terminal)
* Lightweight Charts candlesticks / Heikin-Ashi / bars / line / area on 8 timeframes (1m → 1W)
* Indicators: EMA 20/50/200, Bollinger bands, session VWAP, volume histogram — all computed client-side from real candles
* Drawing tools: horizontal level, trend line, two-point **measure tool** (%, price delta), clear-all
* OHLC crosshair legend, live price ticker merged into the forming candle every tick
* Order ticket with **risk-based auto-sizing** (leave qty empty → the server sizes the position so the stop risks your account risk %), plus SL/TP lines drawn on the chart
* Trade markers (entries/exits) plotted on the chart from your own blotter
* **Ask desk for analysis** — deterministic rule engine that scores 6 signals into a bias, strength %, plan (entry/stop/TP1/TP2), invalidation and checklist
* Price alerts, watchlist, copy-plan, and **share chart to room**

### Messenger (`/` → Messenger)
* Group rooms and direct messages over Socket.IO (live delivery, typing indicators, presence)
* **Shared analyses carry the whole setup**: symbol, timeframe, bias, 90-candle snapshot, levels, indicators, notes, plan — rendered as a live mini chart everyone can open, react to, and **copy as an order** in one click
* **Trade cards**: share a live position or a closed result; copy it into your own ticket
* **Photos and documents**: attach images (inline preview + click-to-zoom lightbox) and documents (PDF, Word, Excel, CSV, text, zip → download cards) with the 📎 button, drag-and-drop onto the conversation, or paste from the clipboard. 20 MB per file, 6 files per message, uploaded to `/uploads` and streamed back with the message.
* Emoji reactions, replies by DM, room membership controls, public/private rooms, **unread badges** per room/DM and a total unread count in the sidebar

### Journal (`/` → Journal)
* Daily entry: session, bias, market context, plan, lessons, one instruction for tomorrow, mood + discipline sliders (1-5)
* **Process score** recomputed server-side against the actual trade book (plan, context, stops attached, written reviews, tomorrow's instruction)
* Net outcome, win rate and review-completion for the day, trade list with R multiples
* 45-session heatmap — click any day to jump to that entry

### Dashboard, Trades, Analyze, Risk
* Dashboard: equity, today's P&L, win rate, avg R, equity curve (all/30d/7d), daily P&L bars, guardrail meters, live exposure table, session clock, next events, armed alerts
* Trades: open positions with live floating P&L, working orders, filterable blotter (status/symbol/date/text), trade detail with review notes, tags, emotion and CSV export
* Analyze: R-multiple distribution, performance by market, tag/habit P&L, daily P&L calendar, execution-quality stats
* Risk: per-trade risk, daily loss limit, leverage, exposure vs equity, guardrail meters, equity drawdown, position-size calculator
* Playbooks, Watchlist, Alerts, News (live headlines + indicative calendar), Rooms index, Settings, and an in-app **API reference**

---

## 3 · Market data

Every market has **two sources** so a regional block or a rate limit can never stop the desk:

| asset class | symbols | primary | free fallback (no key) |
|---|---|---|---|
| Crypto | BTC, ETH, SOL, XRP, BNB, DOGE, ADA | OKX public REST | **Kraken** OHLC / Ticker |
| FX majors | EURUSD, GBPUSD, USDJPY, AUDUSD, USDCAD, USDCHF, USDINR | Yahoo Finance chart API | **open.er-api.com** spot rates |
| Metals | XAUUSD, XAGUSD | Yahoo Finance | **gold-api.com** spot |
| Energy | USOIL, NATGAS | Yahoo Finance | — |
| Indices | SPX500, NAS100, US30, GER40, UK100, JP225, NIFTY50, BANKNIFTY | Yahoo Finance | — |
| Stocks | AAPL, MSFT, NVDA, TSLA, RELIANCE, TCS, HDFCBANK | Yahoo Finance | — |

33 markets total. A quote is tagged `live`, `fallback` (second provider), `cached`, or `sim` (offline synthetic) so you always know what you are looking at. The engine:

* refreshes quotes on an interval (crypto every tick, the rest rotated in batches to stay polite),
* caches candles per symbol/timeframe and serves stale cache instead of nothing when a provider hiccups,
* **backs off per provider** on HTTP 429 and keeps the last known price walking forward, so the UI never breaks,
* falls back to clearly-labelled synthetic candles (`source: "sim"`) if there is no internet at all — every chart header shows the live/stale/offline state.

4H and 1W candles are aggregated from 1H and daily bars respectively.

---

## 4 · API

Full details are also in-app (**System → API docs**). Base URL `/api`, auth via `Authorization: Bearer <token>`.

```
POST /auth/register            POST /auth/login (username OR email)   GET|PATCH /auth/me     GET /auth/users
POST /auth/verify-email        POST /auth/resend-verification         POST /auth/password (change)
POST /auth/forgot-password     POST /auth/reset-password              GET  /auth/config
POST /upload                   GET  /uploads/<year-month>/<file>       GET  /health
GET  /market/symbols           GET  /market/quotes         GET  /market/quote/:symbol
GET  /market/candles?symbol=&tf=&limit=
GET  /market/indicators?symbol=&tf=
GET  /market/sessions          GET  /market/news?symbol=   GET  /market/calendar
GET  /market/alerts            POST /market/alerts         DELETE /market/alerts/:id
GET  /accounts                 POST /accounts              PATCH /accounts/:id
GET  /trades?status=&symbol=&from=&to=&search=
POST /trades                   PATCH /trades/:id           POST /trades/:id/close     DELETE /trades/:id
GET  /trades/stats             GET  /risk
GET  /playbooks                POST /playbooks             PATCH|DELETE /playbooks/:id
GET  /journal?day=             PUT  /journal               GET /journal/range        GET /journal/stats
GET  /analysis/:symbol?tf=     GET  /watchlist             POST /watchlist           DELETE /watchlist/:symbol
GET  /social/groups            POST /social/groups         POST /social/groups/:id/join|leave
GET  /social/groups/:id/members                             POST /social/groups/:id/members
GET  /social/messages?room=    POST /social/messages (text + attachments)   POST /social/messages/:id/react   DELETE /social/messages/:id
GET  /social/unread            POST /social/read
POST /social/share/analysis    POST /social/share/trade    GET  /social/dm            GET /social/dm/:userId
GET  /notifications            POST /notifications/read    GET  /search?q=            GET /health
```

Socket.IO (JWT in the handshake `auth.token`) — server → client: `market:tick`, `positions:update`, `message`, `message:deleted`, `reaction`, `typing`, `presence`, `alert:triggered`, `order:filled`, `dm:new`; client → server: `chat:send`, `typing`, `room:open`, `chart:sub`.

---

## 5 · Project layout

```
empire-trade-vault/
├─ server/
│  ├─ index.js          API + Socket.IO server, helmet/compression/rate limits, graceful shutdown
│  ├─ boot.js           cross-platform launcher (auto-install · auto-seed · --reset/--seed)
│  ├─ dep_path.js       dependency resolver (deps/pkgs → node_modules → NODE_PATH)
│  ├─ config.js         app identity, storage, auth, SMTP, upload limits, prod health checks
│  ├─ db.js             SQLite schema + idempotent migrations (users, accounts, trades, playbooks,
│  │                    journal, groups, messages, reactions, watchlist, alerts, notifications,
│  │                    sessions, emails, room_reads, attachments)
│  ├─ mailer.js         SMTP sender (nodemailer) with console + `emails` table fallback
│  ├─ upload.js         multer upload route + /uploads static server (type/size whitelist)
│  ├─ marketdata.js     quote/candle engine, indicators, sessions, calendar
│  ├─ pnl.js            position sizing, P&L, R multiples, drawdown
│  ├─ auth.js           bcrypt + JWT
│  ├─ realtime.js       socket↔route broadcast bridge
│  ├─ seed.js           demo desk generator (45 days of history + sample photos/documents)
│  └─ routes/           auth · market · trades · journal · social · misc
├─ public/
│  ├─ index.html        app shell + auth screen
│  ├─ css/app.css       terminal theme (dark, gold)
│  ├─ js/api.js         API client, store, toasts, modals, socket wiring
│  ├─ js/charts.js      Lightweight Charts wrapper (panes, indicators, tools, snapshots)
│  ├─ js/app.js         auth, router, ticker, command palette (⌘K)
│  ├─ js/views/         dashboard · terminal · trades · journal · analyze · messenger · more
│  ├─ vendor/           lightweight-charts (TradingView), served locally
│  └─ legacy/           your original empire-trade-vault.html demo
├─ deps/pkgs            vendored dependencies (kept in the repo so the app always boots)
├─ start.sh / start.bat one-command launchers (Linux/macOS · Windows)
├─ Dockerfile · docker-compose.yml · render.yaml · fly.toml · Procfile · .env.example
├─ DEPLOY.md            go-live guide: Render / Fly / VPS, SMTP, backups, checklist
├─ tests/smoke.py       headless browser test that walks every view and reports errors
├─ tests/auth_test.py   sign-in test: normal page, sandboxed iframe, broken storage,
│                       stale token, server offline (12 checks)
├─ tests/attachments_test.py  photos + documents in the messenger, and the whole email
│                       account flow — register, sign in by email, verify, reset (20 checks)
├─ uploads/             photos + documents sent in the messenger (mount a volume here)
└─ data/arjun.db        SQLite database (created on first run)
```

---

## 6 · Notes & next steps

* Demo accounts are **paper traded on live prices** — no broker connection, so nothing is at risk. An MT5/broker bridge would slot in behind `POST /trades` and the `positions:update` stream.
* The economic calendar is an indicative weekly pattern; swap `marketdata.economicCalendar()` for a real provider when you have a key.
* Security: change `JWT_SECRET` and the owner password before exposing this to the internet, and put it behind HTTPS. The server prints a warning at boot for any production setting still on its default — see the checklist in **DEPLOY.md**.
* **Multiuser**: every account has its own paper desk, journal, playbooks, watchlist and alerts; rooms and DMs are shared. Registration works with email, `REQUIRE_EMAIL_VERIFICATION=true` enforces confirmed inboxes, and password resets run through the same mailer.
* The browser tests (`python3 tests/smoke.py`, `python3 tests/auth_test.py`, `python3 tests/attachments_test.py` — or `npm test`, `npm run test:auth`, `npm run test:attachments`) need the server running; they install headless Chromium themselves, walk all 14 views plus order placement/sharing/journal save, upload a file through the messenger UI, and fail on any console error.
* Login is hardened for embedded/preview use: the session store falls back to memory when `localStorage` is blocked (sandboxed iframes, private mode), network failures return a plain-English reason, and a stale token drops you back to the sign-in card instead of a blank screen.
