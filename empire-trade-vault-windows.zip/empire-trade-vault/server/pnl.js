'use strict';
/**
 * Position sizing / P&L maths shared by the REST order engine and the seed script.
 *
 * Contract model
 *  • forex / metal / energy : qty is expressed in LOTS (contract = lotSize units of base)
 *  • crypto / stock / index : qty is expressed in UNITS (coins, shares, contracts)
 *  • quotes in JPY are converted to the account currency using the exit price.
 */
const { SYMBOL_MAP } = require('./config');

const round = (v, d = 2) => Math.round(v * 10 ** d) / 10 ** d;

function unitsPerQty(symbol, qty) {
  const s = SYMBOL_MAP[symbol];
  if (!s) return qty;
  if (['forex', 'metal', 'energy'].includes(s.klass)) return qty * (s.lotSize || 1);
  return qty;
}

function rawPnl(symbol, side, entry, exit, qty) {
  const s = SYMBOL_MAP[symbol] || { currency: 'USD', digits: 2 };
  const dir = side === 'buy' ? 1 : -1;
  let pnl = (exit - entry) * dir * unitsPerQty(symbol, qty);
  if (s.currency === 'JPY') pnl = pnl / exit;           // convert JPY quote P&L to USD
  else if (s.currency === 'INR') pnl = pnl / 88;        // approx INR→USD for demo accounts
  return pnl;
}

function computePnl(symbol, side, entry, exit, qty) {
  const s = SYMBOL_MAP[symbol] || { digits: 2 };
  const gross = rawPnl(symbol, side, entry, exit, qty);
  return { pnl: round(gross, 2), pnlPips: round((exit - entry) * (side === 'buy' ? 1 : -1) / (s.tick || 1), 1) };
}

/** Risk in account currency for an entry/stop pair. */
function riskAmount(symbol, entry, stop, qty) {
  if (!stop) return null;
  const diff = Math.abs(entry - stop);
  const s = SYMBOL_MAP[symbol] || {};
  let risk = diff * unitsPerQty(symbol, qty);
  if (s.currency === 'JPY') risk = risk / entry;
  else if (s.currency === 'INR') risk = risk / 88;
  return round(risk, 2);
}

/** Position size (lots/units) so that the stop risks `riskUsd` of the account. */
function sizeForRisk(symbol, entry, stop, riskUsd) {
  const diff = Math.abs(entry - stop);
  if (!diff) return 0;
  const s = SYMBOL_MAP[symbol] || {};
  const units = riskUsd / diff;
  if (['forex', 'metal', 'energy'].includes(s.klass)) return round(units / (s.lotSize || 1), 2);
  return round(units, 4);
}

function rMultiple(pnl, risk) {
  if (!risk) return null;
  return round(pnl / risk, 2);
}

function maxDrawdown(equityCurve) {
  let peak = -Infinity, mdd = 0;
  equityCurve.forEach((p) => {
    peak = Math.max(peak, p.equity);
    if (peak > 0) mdd = Math.min(mdd, (p.equity - peak) / peak);
  });
  return round(Math.abs(mdd) * 100, 2);
}

module.exports = { computePnl, riskAmount, sizeForRisk, rMultiple, maxDrawdown, round };
