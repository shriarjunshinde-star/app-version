'use strict';
const jwt = require('jsonwebtoken');
const CONFIG = require('../server/config');

function sign(user) {
  return jwt.sign({ id: user.id, username: user.username }, CONFIG.JWT_SECRET, { expiresIn: CONFIG.JWT_EXPIRES });
}

function verify(token) {
  try { return jwt.verify(token, CONFIG.JWT_SECRET); } catch { return null; }
}

/** Express middleware + socket.io handshake share this reader. */
function userFromReq(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : req.query.token;
  if (!token) return null;
  return verify(token);
}

function requireAuth(req, res, next) {
  const payload = userFromReq(req);
  if (!payload) return res.status(401).json({ error: 'Not authenticated' });
  req.userId = payload.id;
  req.username = payload.username;
  next();
}

module.exports = { sign, verify, userFromReq, requireAuth };
