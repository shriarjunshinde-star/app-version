'use strict';
/**
 * Dependency resolver — makes the app start from any entry point on any OS.
 *
 * Look order:
 *   1. ./deps/pkgs           (vendored copy that survives workspace snapshots)
 *   2. ./node_modules        (regular `npm install`)
 *
 * NODE_PATH entries behave exactly like node_modules folders, so deps/pkgs works
 * as a drop-in replacement while keeping a name snapshots do not delete.
 * If neither contains express, the caller can install on demand (server/boot.js).
 *
 * Call ensurePath() BEFORE requiring express / socket.io / better-sqlite3.
 */
const path = require('path');
const fs = require('fs');
const Module = require('module');

const root = path.join(__dirname, '..');
const local = path.join(root, 'node_modules');
const vendored = path.join(root, 'deps', 'pkgs');   // note: not named "node_modules",
                                                    // because snapshots strip that name at any depth

const has = (dir) => !!dir && fs.existsSync(path.join(dir, 'express')) && fs.existsSync(path.join(dir, 'better-sqlite3'));

function active() {
  if (has(vendored)) return vendored;
  if (has(local)) return local;
  // honour an explicit NODE_PATH (CI, docker, custom installs)
  for (const dir of String(process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean)) {
    if (has(dir)) return dir;
  }
  return null;
}

function ensurePath() {
  const dir = active();
  if (!dir) return null;
  const parts = String(process.env.NODE_PATH || '').split(path.delimiter).filter(Boolean);
  if (!parts.includes(dir)) {
    process.env.NODE_PATH = [dir, ...parts].join(path.delimiter);
    Module._initPaths();                       // re-read NODE_PATH for this process
  }
  return dir;
}

module.exports = { ensurePath, active, vendored, local };
