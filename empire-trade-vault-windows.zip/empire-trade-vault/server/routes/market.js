'use strict';
const express = require('express');
const engine = require('../marketdata');
const CONFIG = require('../config');
const { q } = require('../db');
const { requireAuth } = require('../auth');

const router = express.Router();

router.get('/symbols', (req, res) => {
  res.json({
    symbols: engine.listSymbols(),
    timeframes: Object.entries(CONFIG.TIMEFRAMES).map(([key, t]) => ({ key, label: t.label })),
    status: engine.status,
  });
});

router.get('/quotes', (req, res) => {
  const want = req.query.symbols ? String(req.query.symbols).split(',') : null;
  const all = engine.listSymbols();
  res.json(want ? all.filter((s) => want.includes(s.symbol)) : all);
});

router.get('/quote/:symbol', (req, res) => {
  const qt = engine.getQuote(String(req.params.symbol).toUpperCase());
  if (!qt) return res.status(404).json({ error: 'Unknown symbol' });
  res.json(qt);
});

router.get('/candles', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || 'BTCUSD').toUpperCase();
    const tf = String(req.query.tf || '1h').toLowerCase();
    const limit = Math.min(Number(req.query.limit || 400), 800);
    const { candles, source } = await engine.getCandles(symbol, tf);
    const meta = engine.meta(symbol) || {};
    const live = engine.getQuote(symbol);
    res.json({ symbol, tf, source, live: live ? { price: live.price, source: live.source, ts: live.ts } : null, meta, candles: candles.slice(-limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/indicators', async (req, res) => {
  try {
    const symbol = String(req.query.symbol || 'BTCUSD').toUpperCase();
    const tf = String(req.query.tf || '1h').toLowerCase();
    res.json(await engine.indicatorPack(symbol, tf));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/sessions', (req, res) => res.json(engine.marketStatus()));

router.get('/news', async (req, res) => {
  try {
    const symbol = req.query.symbol ? String(req.query.symbol).toUpperCase() : null;
    let items = await engine.fetchNews(symbol);
    if (!items.length) items = await engine.fetchNews(null);
    res.json({ symbol: symbol || 'MARKET', items });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/calendar', (req, res) => res.json({ events: engine.economicCalendar() }));

/* ------------------------------------------------------ alerts (per user) */
router.get('/alerts', requireAuth, (req, res) => {
  res.json(q.all('SELECT * FROM alerts WHERE user_id = ? ORDER BY id DESC', req.userId));
});

router.post('/alerts', requireAuth, (req, res) => {
  const { symbol, condition, price, note } = req.body || {};
  if (!symbol || !Number(price)) return res.status(400).json({ error: 'symbol and price required' });
  const info = q.run('INSERT INTO alerts (user_id, symbol, condition, price, note) VALUES (?,?,?,?,?)',
    req.userId, String(symbol).toUpperCase(), condition === 'below' ? 'below' : 'above', Number(price), note || '');
  res.json(q.one('SELECT * FROM alerts WHERE id = ?', info.lastInsertRowid));
});

router.delete('/alerts/:id', requireAuth, (req, res) => {
  q.run('DELETE FROM alerts WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  res.json({ ok: true });
});

router.get('/status', (req, res) => {
  res.json({
    engine: engine.status,
    symbols: CONFIG.SYMBOLS.length,
    sessions: engine.marketStatus(),
    quotes: engine.listSymbols().slice(0, 3),
  });
});

module.exports = router;
