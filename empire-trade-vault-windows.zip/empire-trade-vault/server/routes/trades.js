'use strict';
const express = require('express');
const { q, makeAccount } = require('../db');
const { requireAuth } = require('../auth');
const { computePnl, riskAmount, rMultiple, maxDrawdown, round } = require('../pnl');
const engine = require('../marketdata');

const router = express.Router();
router.use(requireAuth);

const parseTags = (t) => {
  if (Array.isArray(t)) return t;
  try { return JSON.parse(t || '[]'); } catch { return []; }
};
const shape = (t) => ({ ...t, tags: parseTags(t.tags) });

function accountOf(userId, accountId) {
  if (accountId) {
    const a = q.one('SELECT * FROM accounts WHERE id = ? AND user_id = ?', Number(accountId), userId);
    if (a) return a;
  }
  let a = q.one('SELECT * FROM accounts WHERE user_id = ? ORDER BY id LIMIT 1', userId);
  if (!a) { const id = makeAccount(userId); a = q.one('SELECT * FROM accounts WHERE id = ?', id); }
  return a;
}

/* ------------------------------------------------------------- accounts */
router.get('/accounts', (req, res) => {
  res.json(q.all('SELECT * FROM accounts WHERE user_id = ? ORDER BY id', req.userId));
});

router.post('/accounts', (req, res) => {
  const { name, startBalance, currency, leverage } = req.body || {};
  const id = makeAccount(req.userId, name || 'Vault Paper', Number(startBalance) || 100000);
  if (currency || leverage) {
    q.run('UPDATE accounts SET currency = COALESCE(?, currency), leverage = COALESCE(?, leverage) WHERE id = ?', currency || null, leverage || null, id);
  }
  res.json(q.one('SELECT * FROM accounts WHERE id = ?', id));
});

router.patch('/accounts/:id', (req, res) => {
  const { riskPerTrade, maxDailyLoss, leverage, name } = req.body || {};
  q.run(`UPDATE accounts SET risk_per_trade = COALESCE(?, risk_per_trade), max_daily_loss = COALESCE(?, max_daily_loss),
         leverage = COALESCE(?, leverage), name = COALESCE(?, name) WHERE id = ? AND user_id = ?`,
    riskPerTrade ?? null, maxDailyLoss ?? null, leverage ?? null, name ?? null, Number(req.params.id), req.userId);
  res.json(q.one('SELECT * FROM accounts WHERE id = ?', Number(req.params.id)));
});

/* --------------------------------------------------------------- trades */
router.get('/trades', (req, res) => {
  const { status, symbol, playbook, tag, from, to, search } = req.query;
  const limit = Math.min(Number(req.query.limit || 500), 2000);
  let sql = 'SELECT * FROM trades WHERE user_id = ?';
  const p = [req.userId];
  if (status && status !== 'all') { sql += ' AND status = ?'; p.push(status); }
  if (symbol) { sql += ' AND symbol = ?'; p.push(String(symbol).toUpperCase()); }
  if (playbook) { sql += ' AND playbook_id = ?'; p.push(Number(playbook)); }
  if (from) { sql += ' AND date(COALESCE(closed_at, opened_at)) >= date(?)'; p.push(from); }
  if (to) { sql += ' AND date(COALESCE(closed_at, opened_at)) <= date(?)'; p.push(to); }
  if (search) { sql += ' AND (symbol LIKE ? OR notes LIKE ? OR setup_tag LIKE ?)'; const s = `%${search}%`; p.push(s, s, s); }
  sql += ' ORDER BY COALESCE(closed_at, opened_at) DESC, id DESC LIMIT ?';
  p.push(limit);
  let rows = q.all(sql, ...p).map(shape);
  if (tag) rows = rows.filter((t) => t.tags.includes(tag));
  res.json(rows);
});

/** Place an order. Live market orders fill instantly at the current price. */
router.post('/trades', (req, res) => {
  const b = req.body || {};
  const symbol = String(b.symbol || '').toUpperCase();
  if (!engine.meta(symbol)) return res.status(400).json({ error: 'Unknown symbol' });
  const side = b.side === 'sell' ? 'sell' : 'buy';
  const acc = accountOf(req.userId, b.accountId);
  const quote = engine.getQuote(symbol);
  const orderType = b.orderType === 'limit' ? 'limit' : 'market';

  let qty = Number(b.qty);
  const entry = orderType === 'market' ? (b.price ? Number(b.price) : quote.price) : Number(b.price || quote.price);
  const stop = b.stopLoss ? Number(b.stopLoss) : null;
  const target = b.takeProfit ? Number(b.takeProfit) : null;

  if (!qty || qty <= 0) {
    // auto-size from RISK % of equity when the trader lets the terminal decide
    if (stop) {
      const { sizeForRisk } = require('../pnl');
      const riskUsd = (acc.balance * (acc.risk_per_trade || 1)) / 100;
      qty = sizeForRisk(symbol, entry, stop, riskUsd);
    } else {
      qty = ['forex', 'metal', 'energy'].includes(engine.meta(symbol).class) ? 0.1 : 1;
    }
  }
  const risk = riskAmount(symbol, entry, stop, qty);

  const status = orderType === 'limit' ? 'pending' : 'open';
  const info = q.run(
    `INSERT INTO trades (user_id, account_id, symbol, side, qty, entry_price, stop_loss, take_profit, status,
      order_type, risk_amount, playbook_id, setup_tag, tags, emotion, confidence, notes, origin)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
    req.userId, acc.id, symbol, side, qty, entry, stop, target, status, orderType, risk,
    b.playbookId ? Number(b.playbookId) : null, b.setupTag || null, JSON.stringify(parseTags(b.tags)),
    b.emotion || null, b.confidence ? Number(b.confidence) : null, b.notes || null,
    b.origin === 'analysis' ? 'analysis' : b.origin === 'message' ? 'message' : 'manual'
  );
  const trade = shape(q.one('SELECT * FROM trades WHERE id = ?', info.lastInsertRowid));
  res.json({ trade, account: q.one('SELECT * FROM accounts WHERE id = ?', acc.id) });
});

router.patch('/trades/:id', (req, res) => {
  const id = Number(req.params.id);
  const t = q.one('SELECT * FROM trades WHERE id = ? AND user_id = ?', id, req.userId);
  if (!t) return res.status(404).json({ error: 'Trade not found' });
  const b = req.body || {};
  q.run(`UPDATE trades SET stop_loss = COALESCE(?, stop_loss), take_profit = COALESCE(?, take_profit),
         notes = COALESCE(?, notes), setup_tag = COALESCE(?, setup_tag), tags = COALESCE(?, tags),
         emotion = COALESCE(?, emotion), confidence = COALESCE(?, confidence), playbook_id = COALESCE(?, playbook_id),
         qty = COALESCE(?, qty) WHERE id = ?`,
    b.stopLoss ?? null, b.takeProfit ?? null, b.notes ?? null, b.setupTag ?? null,
    b.tags ? JSON.stringify(parseTags(b.tags)) : null, b.emotion ?? null,
    b.confidence ?? null, b.playbookId ?? null, b.qty ?? null, id);
  res.json(shape(q.one('SELECT * FROM trades WHERE id = ?', id)));
});

function closeTrade(userId, id, exitPrice, reason, notes) {
  const t = q.one('SELECT * FROM trades WHERE id = ? AND user_id = ?', id, userId);
  if (!t) return { error: 'Trade not found', code: 404 };
  if (t.status === 'closed') return { error: 'Trade already closed', code: 400 };
  const acc = q.one('SELECT * FROM accounts WHERE id = ?', t.account_id);
  const exit = Number(exitPrice) || engine.getQuote(t.symbol).price;
  const { pnl, pnlPips } = computePnl(t.symbol, t.side, t.entry_price, exit, t.qty);
  const risk = t.risk_amount || riskAmount(t.symbol, t.entry_price, t.stop_loss, t.qty);
  const r = rMultiple(pnl, risk);
  q.run(`UPDATE trades SET status='closed', exit_price=?, closed_at=datetime('now'), pnl=?, r_multiple=?,
         close_reason=?, notes=COALESCE(?, notes), risk_amount=? WHERE id = ?`,
    exit, pnl, r, reason || 'manual', notes ?? null, risk, id);
  q.run('UPDATE accounts SET balance = balance + ? WHERE id = ?', pnl, acc.id);
  const updated = shape(q.one('SELECT * FROM trades WHERE id = ?', id));
  return { trade: updated, account: q.one('SELECT * FROM accounts WHERE id = ?', acc.id), pnlPips };
}

router.post('/trades/:id/close', (req, res) => {
  const out = closeTrade(req.userId, Number(req.params.id), req.body?.exitPrice, req.body?.reason, req.body?.notes);
  if (out.error) return res.status(out.code).json({ error: out.error });
  res.json(out);
});

router.delete('/trades/:id', (req, res) => {
  const t = q.one('SELECT * FROM trades WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  if (!t) return res.status(404).json({ error: 'Not found' });
  if (t.status === 'closed') q.run('UPDATE accounts SET balance = balance - ? WHERE id = ?', t.pnl || 0, t.account_id);
  q.run('DELETE FROM trades WHERE id = ?', t.id);
  res.json({ ok: true });
});

/* ---------------------------------------------------------------- stats */
router.get('/trades/stats', (req, res) => {
  const acc = accountOf(req.userId, req.query.accountId);
  const all = q.all('SELECT * FROM trades WHERE user_id = ? AND account_id = ? ORDER BY COALESCE(closed_at, opened_at)', req.userId, acc.id);
  const closed = all.filter((t) => t.status === 'closed');
  const open = all.filter((t) => t.status === 'open' || t.status === 'pending');

  const wins = closed.filter((t) => t.pnl > 0);
  const losses = closed.filter((t) => t.pnl < 0);
  const grossWin = wins.reduce((a, t) => a + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((a, t) => a + t.pnl, 0));
  const net = closed.reduce((a, t) => a + t.pnl, 0);

  const floating = open.filter((t) => t.status === 'open').reduce((a, t) => {
    const cur = engine.getQuote(t.symbol).price;
    return a + computePnl(t.symbol, t.side, t.entry_price, cur, t.qty).pnl;
  }, 0);

  let equity = acc.start_balance;
  const closedSorted = closed.slice().sort((a, b) => String(a.closed_at || a.opened_at).localeCompare(String(b.closed_at || b.opened_at)));
  const firstAt = closedSorted.length
    ? new Date(new Date(String(closedSorted[0].closed_at || closedSorted[0].opened_at).replace(' ', 'T') + 'Z').getTime() - 3600e3)
      .toISOString().slice(0, 19).replace('T', ' ')
    : acc.created_at;
  const curve = [{ t: firstAt, equity: round(equity, 2) }];
  closedSorted.forEach((t) => { equity += t.pnl; curve.push({ t: t.closed_at || t.opened_at, equity: round(equity, 2), pnl: round(t.pnl, 2), symbol: t.symbol }); });

  const byDay = {};
  closed.forEach((t) => {
    const d = (t.closed_at || t.opened_at || '').slice(0, 10);
    byDay[d] = round((byDay[d] || 0) + t.pnl, 2);
  });
  const bySymbol = {};
  closed.forEach((t) => {
    bySymbol[t.symbol] = bySymbol[t.symbol] || { symbol: t.symbol, trades: 0, pnl: 0, wins: 0 };
    bySymbol[t.symbol].trades++;
    bySymbol[t.symbol].pnl = round(bySymbol[t.symbol].pnl + t.pnl, 2);
    if (t.pnl > 0) bySymbol[t.symbol].wins++;
  });
  const byTag = {};
  closed.forEach((t) => {
    parseTags(t.tags).forEach((tag) => {
      byTag[tag] = byTag[tag] || { tag, trades: 0, pnl: 0, wins: 0 };
      byTag[tag].trades++; byTag[tag].pnl = round(byTag[tag].pnl + t.pnl, 2);
      if (t.pnl > 0) byTag[tag].wins++;
    });
  });
  const byPlaybook = {};
  closed.forEach((t) => {
    if (!t.playbook_id) return;
    const pb = q.one('SELECT name, color FROM playbooks WHERE id = ?', t.playbook_id);
    if (!pb) return;
    byPlaybook[pb.name] = byPlaybook[pb.name] || { name: pb.name, color: pb.color, trades: 0, pnl: 0, wins: 0 };
    byPlaybook[pb.name].trades++; byPlaybook[pb.name].pnl = round(byPlaybook[pb.name].pnl + t.pnl, 2);
    if (t.pnl > 0) byPlaybook[pb.name].wins++;
  });

  const today = new Date().toISOString().slice(0, 10);
  const todayPnl = round(closed.filter((t) => (t.closed_at || '').slice(0, 10) === today).reduce((a, t) => a + t.pnl, 0), 2);
  const dayLossLimit = round((acc.balance * (acc.max_daily_loss || 3)) / 100, 2);

  res.json({
    account: acc,
    totals: {
      netPnl: round(net, 2), floating: round(floating, 2), todayPnl,
      equity: round(acc.balance + floating, 2), balance: round(acc.balance, 2),
      startBalance: acc.start_balance,
      returnPct: round(((acc.balance + floating - acc.start_balance) / acc.start_balance) * 100, 2),
      closed: closed.length, open: open.length,
      wins: wins.length, losses: losses.length,
      winRate: closed.length ? round((wins.length / closed.length) * 100, 1) : 0,
      profitFactor: grossLoss ? round(grossWin / grossLoss, 2) : (grossWin ? 99 : 0),
      avgWin: wins.length ? round(grossWin / wins.length, 2) : 0,
      avgLoss: losses.length ? round(-grossLoss / losses.length, 2) : 0,
      expectancy: closed.length ? round(net / closed.length, 2) : 0,
      avgR: closed.filter((t) => t.r_multiple != null).length
        ? round(closed.reduce((a, t) => a + (t.r_multiple || 0), 0) / closed.filter((t) => t.r_multiple != null).length, 2) : 0,
      bestTrade: closed.length ? round(Math.max(...closed.map((t) => t.pnl)), 2) : 0,
      worstTrade: closed.length ? round(Math.min(...closed.map((t) => t.pnl)), 2) : 0,
      maxDrawdownPct: maxDrawdown(curve),
      dayLossLimit, dayLossUsed: todayPnl < 0 ? Math.abs(todayPnl) : 0,
      streak: (() => {
        let s = 0;
        for (let i = closed.length - 1; i >= 0; i--) {
          if (closed[i].pnl > 0) { if (s >= 0) s++; else break; } else if (closed[i].pnl < 0) { if (s <= 0) s--; else break; } else break;
        }
        return s;
      })(),
    },
    equityCurve: curve,
    dailyPnl: Object.entries(byDay).map(([day, pnl]) => ({ day, pnl })).sort((a, b) => a.day.localeCompare(b.day)),
    bySymbol: Object.values(bySymbol).sort((a, b) => b.pnl - a.pnl),
    byTag: Object.values(byTag).sort((a, b) => b.trades - a.trades),
    byPlaybook: Object.values(byPlaybook),
    openTrades: open.map((t) => ({
      ...shape(t),
      currentPrice: engine.getQuote(t.symbol).price,
      floating: computePnl(t.symbol, t.side, t.entry_price, engine.getQuote(t.symbol).price, t.qty).pnl,
    })),
  });
});

/* ------------------------------------------------------------ playbooks */
router.get('/playbooks', (req, res) => {
  res.json(q.all('SELECT * FROM playbooks WHERE user_id = ? ORDER BY id', req.userId)
    .map((p) => ({ ...p, rules: (() => { try { return JSON.parse(p.rules || '[]'); } catch { return []; } })() })));
});

router.post('/playbooks', (req, res) => {
  const { name, description, rules, color } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const info = q.run('INSERT INTO playbooks (user_id, name, description, rules, color) VALUES (?,?,?,?,?)',
    req.userId, name, description || '', JSON.stringify(rules || []), color || '#C9A94C');
  res.json(q.one('SELECT * FROM playbooks WHERE id = ?', info.lastInsertRowid));
});

router.patch('/playbooks/:id', (req, res) => {
  const b = req.body || {};
  q.run(`UPDATE playbooks SET name = COALESCE(?, name), description = COALESCE(?, description),
         rules = COALESCE(?, rules), color = COALESCE(?, color) WHERE id = ? AND user_id = ?`,
    b.name ?? null, b.description ?? null, b.rules ? JSON.stringify(b.rules) : null, b.color ?? null,
    Number(req.params.id), req.userId);
  res.json(q.one('SELECT * FROM playbooks WHERE id = ?', Number(req.params.id)));
});

router.delete('/playbooks/:id', (req, res) => {
  q.run('DELETE FROM playbooks WHERE id = ? AND user_id = ?', Number(req.params.id), req.userId);
  res.json({ ok: true });
});

/* ----------------------------------------------------------------- risk */
router.get('/risk', (req, res) => {
  const acc = accountOf(req.userId, req.query.accountId);
  const open = q.all("SELECT * FROM trades WHERE user_id = ? AND status IN ('open','pending')", req.userId);
  const openRisk = open.reduce((a, t) => a + (t.risk_amount || 0), 0);
  const endOfDay = new Date(); endOfDay.setHours(23, 59, 59, 999);
  res.json({
    account: acc,
    riskPerTradePct: acc.risk_per_trade,
    riskPerTradeUsd: round((acc.balance * acc.risk_per_trade) / 100, 2),
    maxDailyLossPct: acc.max_daily_loss,
    maxDailyLossUsd: round((acc.balance * acc.max_daily_loss) / 100, 2),
    openPositions: open.length,
    openRiskUsd: round(openRisk, 2),
    openRiskPct: round((openRisk / acc.balance) * 100, 2),
    leverage: acc.leverage,
    exposure: open.map((t) => ({
      symbol: t.symbol, side: t.side, qty: t.qty,
      notional: round(engine.getQuote(t.symbol).price * (['forex', 'metal', 'energy'].includes(engine.meta(t.symbol).class) ? t.qty * (require('../config').SYMBOL_MAP[t.symbol].lotSize || 1) : t.qty), 2),
      risk: t.risk_amount,
    })),
  });
});

module.exports = router;
module.exports.closeTrade = closeTrade;
