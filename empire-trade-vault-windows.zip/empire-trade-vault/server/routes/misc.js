'use strict';
const express = require('express');
const { q } = require('../db');
const { requireAuth } = require('../auth');
const engine = require('../marketdata');
const { round } = require('../pnl');

const router = express.Router();
router.use(requireAuth);

/* ------------------------------------------------------------ watchlist */
router.get('/watchlist', (req, res) => {
  const rows = q.all('SELECT symbol FROM watchlist WHERE user_id = ? ORDER BY sort, symbol', req.userId);
  const symbols = rows.length ? rows.map((r) => r.symbol) : ['BTCUSD', 'ETHUSD', 'XAUUSD', 'EURUSD', 'NAS100', 'NIFTY50'];
  res.json(symbols.map((s) => engine.listSymbols().find((x) => x.symbol === s)).filter(Boolean));
});

router.post('/watchlist', (req, res) => {
  const symbol = String(req.body?.symbol || '').toUpperCase();
  if (!engine.meta(symbol)) return res.status(400).json({ error: 'Unknown symbol' });
  q.run('INSERT OR IGNORE INTO watchlist (user_id, symbol) VALUES (?,?)', req.userId, symbol);
  res.json({ ok: true });
});

router.delete('/watchlist/:symbol', (req, res) => {
  q.run('DELETE FROM watchlist WHERE user_id = ? AND symbol = ?', req.userId, String(req.params.symbol).toUpperCase());
  res.json({ ok: true });
});

/* -------------------------------------------------------- notifications */
router.get('/notifications', (req, res) => {
  res.json(q.all('SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 50', req.userId));
});
router.post('/notifications/read', (req, res) => {
  q.run('UPDATE notifications SET read = 1 WHERE user_id = ?', req.userId);
  res.json({ ok: true });
});

/* ---------------------------------------------------------------- search */
router.get('/search', (req, res) => {
  const s = String(req.query.q || '').trim();
  if (!s) return res.json({ symbols: [], users: [], groups: [] });
  const like = `%${s}%`;
  res.json({
    symbols: engine.listSymbols().filter((x) => x.symbol.includes(s.toUpperCase()) || x.name.toLowerCase().includes(s.toLowerCase())).slice(0, 12),
    users: q.all('SELECT id, username, display_name, avatar_color FROM users WHERE (username LIKE ? OR display_name LIKE ?) AND id != ? LIMIT 8', like, like, req.userId),
    groups: q.all('SELECT id, name, topic, icon FROM groups WHERE name LIKE ? OR topic LIKE ? LIMIT 8', like, like),
  });
});

/* ----------------------------------------------------- analysis engine */
/**
 * Rule-based technical desk note built from the live indicator pack.
 * Deterministic, explainable, and always available — even offline.
 */
router.get('/analysis/:symbol', async (req, res) => {
  try {
    const symbol = String(req.params.symbol).toUpperCase();
    const tf = String(req.query.tf || '1h').toLowerCase();
    const p = await engine.indicatorPack(symbol, tf);
    const d = engine.meta(symbol)?.digits ?? 2;
    const score = [];
    const reasons = [];

    if (p.ema.ema20 > p.ema.ema50) { score.push(1); reasons.push(`EMA20 (${p.ema.ema20}) is above EMA50 (${p.ema.ema50}) — short-term momentum favours buyers.`); }
    else { score.push(-1); reasons.push(`EMA20 (${p.ema.ema20}) sits below EMA50 (${p.ema.ema50}) — sellers control the short term.`); }
    if (p.price > p.ema.ema200) { score.push(1); reasons.push(`Price trades above the EMA200 (${p.ema.ema200}) — the higher-timeframe trend is constructive.`); }
    else { score.push(-1); reasons.push(`Price trades under the EMA200 (${p.ema.ema200}) — rallies are counter-trend until reclaimed.`); }
    if (p.rsi14 > 55) { score.push(1); reasons.push(`RSI ${p.rsi14} shows positive momentum but is ${p.rsi14 > 70 ? 'overbought — watch for exhaustion' : 'not yet stretched'}.`); }
    else if (p.rsi14 < 45) { score.push(-1); reasons.push(`RSI ${p.rsi14} is on the weak side of 50 ${p.rsi14 < 30 ? '(oversold, bounce risk)' : ''}.`); }
    else reasons.push(`RSI ${p.rsi14} is neutral — momentum is undecided.`);
    if (p.macd.hist > 0) { score.push(1); reasons.push(`MACD histogram is positive (${p.macd.hist}) — trend pressure is up.`); }
    else { score.push(-1); reasons.push(`MACD histogram is negative (${p.macd.hist}) — trend pressure is down.`); }
    if (p.price > p.vwap) { score.push(1); reasons.push(`Trading above VWAP (${p.vwap}) — buyers are in profit on the session.`); }
    else { score.push(-1); reasons.push(`Below VWAP (${p.vwap}) — intraday value is being rejected.`); }
    const range = p.bollinger.upper - p.bollinger.lower;
    const pos = range ? (p.price - p.bollinger.lower) / range : 0.5;
    if (pos > 0.8) { score.push(-1); reasons.push('Price is pinned to the upper Bollinger band — extended, poor reward for new longs.'); }
    else if (pos < 0.2) { score.push(1); reasons.push('Price is riding the lower Bollinger band — stretched to the downside.'); }

    const net = score.reduce((a, b) => a + b, 0);
    const strength = round((Math.abs(net) / score.length) * 100, 0);
    const bias = net >= 2 ? 'bullish' : net <= -2 ? 'bearish' : 'neutral';
    const atr = p.atr14 || Math.abs(p.price * 0.005);

    const plan = {
      entry: round(p.price, d),
      stop: round(bias === 'bearish' ? p.price + atr * 1.2 : p.price - atr * 1.2, d),
      target1: round(bias === 'bearish' ? p.price - atr * 1.8 : p.price + atr * 1.8, d),
      target2: round(bias === 'bearish' ? p.price - atr * 3.2 : p.price + atr * 3.2, d),
      rr: 1.5,
    };
    if (bias === 'neutral') { plan.stop = round(p.price - atr * 1.2, d); plan.target1 = round(p.price + atr * 1.2, d); plan.rr = 1.0; }

    res.json({
      symbol, tf, bias, strength, trend: p.trend,
      summary: `${symbol} on the ${tf} chart reads ${bias} (${strength}% of checks agree). ` +
        (p.trend === 'uptrend' ? 'Structure is making higher highs and higher lows. '
          : p.trend === 'downtrend' ? 'Structure keeps stepping lower. '
            : 'Price is range-bound, so fade the extremes rather than chase the middle. ') +
        `ATR(14) is ${p.atr14}, which sets the day's working distance.`,
      reasons,
      indicators: p,
      levels: {
        pivot: p.pivots?.P, r1: p.pivots?.R1, r2: p.pivots?.R2, s1: p.pivots?.S1, s2: p.pivots?.S2,
        swingHigh: p.swingHigh, swingLow: p.swingLow,
        vwap: p.vwap, bollUpper: p.bollinger.upper, bollLower: p.bollinger.lower,
      },
      plan,
      invalidation: bias === 'bullish' ? `Losing ${p.pivots?.S1 ?? plan.stop} on a closing basis flips this back to neutral.`
        : bias === 'bearish' ? `Reclaiming ${p.pivots?.R1 ?? plan.stop} invalidates the short side.`
          : `Break and hold outside ${p.pivots?.S1} – ${p.pivots?.R1} is needed before taking a directional swing.`,
      checklist: [
        'Wait for the retest, do not chase the breakout candle.',
        `Risk no more than 1% — stop belongs at ${plan.stop}.`,
        `Scale at ${plan.target1}, trail the rest toward ${plan.target2}.`,
      ],
      generatedAt: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
