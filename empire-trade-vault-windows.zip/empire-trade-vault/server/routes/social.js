'use strict';
/**
 * Messenger: group rooms + direct messages.
 * Messages can carry a chart-analysis payload or a trade card (kind = 'analysis' | 'trade'),
 * which is how members share setups into a room.
 */
const express = require('express');
const { q } = require('../db');
const { requireAuth } = require('../auth');
const rt = require('../realtime');
const engine = require('../marketdata');

const router = express.Router();
router.use(requireAuth);

const dmKey = (a, b) => `dm:${Math.min(Number(a), Number(b))}:${Math.max(Number(a), Number(b))}`;
const parsePayload = (m) => {
  let payload = {};
  try { payload = JSON.parse(m.payload || '{}'); } catch { /* keep {} */ }
  let attachments = [];
  try { attachments = JSON.parse(m.attachments || '[]'); } catch { /* keep [] */ }
  return { ...m, payload, attachments, reactions: reactMap(m.id) };
};

/** Keep only well-formed attachment descriptors that point at our own store. */
const cleanAttachments = (list) => (Array.isArray(list) ? list : [])
  .slice(0, 6)
  .filter((a) => a && typeof a.url === 'string' && a.url.startsWith('/uploads/'))
  .map((a) => ({
    id: String(a.id || '').slice(0, 60),
    name: String(a.name || 'file').slice(0, 160),
    size: Number(a.size) || 0,
    sizeText: String(a.sizeText || '').slice(0, 20),
    mime: String(a.mime || '').slice(0, 100),
    kind: a.kind === 'image' ? 'image' : 'doc',
    ext: String(a.ext || '').slice(0, 8),
    url: a.url.slice(0, 300),
    uploadedAt: a.uploadedAt || new Date().toISOString(),
  }));
const reactMap = (messageId) => {
  const rows = q.all(`SELECT emoji, COUNT(*) AS n, GROUP_CONCAT(user_id) AS users FROM reactions WHERE message_id = ? GROUP BY emoji`, messageId);
  return rows.map((r) => ({ emoji: r.emoji, count: r.n, users: String(r.users).split(',').map(Number) }));
};

/* ---------------------------------------------------------------- groups */
router.get('/groups', (req, res) => {
  const rows = q.all(
    `SELECT g.*, (SELECT COUNT(*) FROM group_members m WHERE m.group_id = g.id) AS members,
            (SELECT body FROM messages ms WHERE ms.room = 'g:' || g.id ORDER BY id DESC LIMIT 1) AS lastBody,
            (SELECT created_at FROM messages ms WHERE ms.room = 'g:' || g.id ORDER BY id DESC LIMIT 1) AS lastAt,
            (SELECT symbol FROM messages ms WHERE ms.room = 'g:' || g.id ORDER BY id DESC LIMIT 1) AS lastSymbol,
            (SELECT COUNT(*) FROM messages ms WHERE ms.room = 'g:' || g.id AND ms.deleted_at IS NULL) AS messageCount,
            (SELECT COUNT(*) FROM messages ms WHERE ms.room = 'g:' || g.id AND ms.user_id != ?
             AND ms.id > COALESCE((SELECT r.last_read_id FROM room_reads r WHERE r.user_id = ? AND r.room = 'g:' || g.id), 0)) AS unread,
            EXISTS(SELECT 1 FROM group_members m2 WHERE m2.group_id = g.id AND m2.user_id = ?) AS joined
     FROM groups g ORDER BY g.is_private, g.id`, req.userId, req.userId, req.userId
  );
  res.json(rows.map((g) => ({ ...g, joined: !!g.joined, unread: g.unread || 0 })));
});

router.post('/groups', (req, res) => {
  const { name, topic, icon, isPrivate, memberIds } = req.body || {};
  if (!name) return res.status(400).json({ error: 'name required' });
  const slug = String(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Math.random().toString(36).slice(2, 5);
  const info = q.run('INSERT INTO groups (slug, name, topic, icon, created_by, is_private) VALUES (?,?,?,?,?,?)',
    slug, name, topic || '', icon || '#', req.userId, isPrivate ? 1 : 0);
  const gid = info.lastInsertRowid;
  q.run('INSERT OR IGNORE INTO group_members (group_id, user_id, role) VALUES (?,?,?)', gid, req.userId, 'owner');
  (Array.isArray(memberIds) ? memberIds : []).forEach((uid) => {
    q.run('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?,?)', gid, Number(uid));
    rt.emitToUser(uid, 'group:added', { groupId: gid, name });
  });
  res.json(q.one('SELECT * FROM groups WHERE id = ?', gid));
});

router.post('/groups/:id/join', (req, res) => {
  const gid = Number(req.params.id);
  const g = q.one('SELECT * FROM groups WHERE id = ?', gid);
  if (!g) return res.status(404).json({ error: 'Group not found' });
  q.run('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?,?)', gid, req.userId);
  res.json({ ok: true, group: g });
});

router.post('/groups/:id/leave', (req, res) => {
  q.run('DELETE FROM group_members WHERE group_id = ? AND user_id = ?', Number(req.params.id), req.userId);
  res.json({ ok: true });
});

router.get('/groups/:id/members', (req, res) => {
  const rows = q.all(
    `SELECT u.id, u.username, u.display_name, u.avatar_color, u.bio, m.role
     FROM group_members m JOIN users u ON u.id = m.user_id WHERE m.group_id = ? ORDER BY m.role DESC, u.display_name`,
    Number(req.params.id)
  );
  res.json(rows.map((u) => ({ ...u, online: rt.isOnline(u.id) })));
});

router.post('/groups/:id/members', (req, res) => {
  const gid = Number(req.params.id);
  const ids = Array.isArray(req.body?.memberIds) ? req.body.memberIds : [];
  ids.forEach((uid) => {
    q.run('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?,?)', gid, Number(uid));
    rt.emitToUser(uid, 'group:added', { groupId: gid });
  });
  res.json({ ok: true, added: ids.length });
});

/* -------------------------------------------------------------- messages */
function canAccessRoom(userId, room) {
  if (room.startsWith('g:')) {
    const gid = Number(room.slice(2));
    return !!q.one('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?', gid, userId);
  }
  if (room.startsWith('dm:')) {
    const parts = room.split(':').slice(1).map(Number);
    return parts.includes(userId);
  }
  return false;
}

router.get('/messages', (req, res) => {
  const room = String(req.query.room || '');
  if (!canAccessRoom(req.userId, room)) return res.status(403).json({ error: 'Not in this room' });
  const limit = Math.min(Number(req.query.limit || 60), 200);
  const before = req.query.before ? Number(req.query.before) : null;
  const rows = before
    ? q.all(`SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id
             WHERE m.room = ? AND m.id < ? AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT ?`, room, before, limit)
    : q.all(`SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id
             WHERE m.room = ? AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT ?`, room, limit);
  res.json(rows.reverse().map(parsePayload));
});

router.post('/messages', (req, res) => {
  const { room, body, kind, payload, symbol, attachments } = req.body || {};
  if (!room || !canAccessRoom(req.userId, room)) return res.status(403).json({ error: 'Not in this room' });
  const text = String(body || '').slice(0, 4000);
  const files = cleanAttachments(attachments);
  if (!text && !payload && !files.length) return res.status(400).json({ error: 'Message is empty' });
  const info = q.run(
    'INSERT INTO messages (room, room_type, user_id, body, kind, payload, symbol, attachments) VALUES (?,?,?,?,?,?,?,?)',
    room, room.startsWith('dm:') ? 'dm' : 'group', req.userId, text,
    kind === 'analysis' ? 'analysis' : kind === 'trade' ? 'trade' : (files.length ? (files.some((f) => f.kind === 'image') ? 'image' : 'file') : 'text'),
    JSON.stringify(payload || {}), symbol || null, JSON.stringify(files));
  const msg = parsePayload(q.one(
    `SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id WHERE m.id = ?`,
    info.lastInsertRowid
  ));
  // sender has obviously read their own message
  q.run(`INSERT INTO room_reads (user_id, room, last_read_id) VALUES (?,?,?)
         ON CONFLICT(user_id, room) DO UPDATE SET last_read_id = excluded.last_read_id, updated_at = datetime('now')`,
    req.userId, room, msg.id);
  rt.emitToRoom(room, 'message', msg);
  if (room.startsWith('dm:')) {
    room.split(':').slice(1).map(Number).filter((id) => id !== req.userId)
      .forEach((uid) => rt.emitToUser(uid, 'dm:new', msg));
  }
  res.json(msg);
});

/* ─────────────────────────────────────────── unread counts + read marks */
router.get('/unread', (req, res) => {
  const rooms = q.all(
    `SELECT m.room, COUNT(*) AS n, MAX(m.id) AS lastId
     FROM messages m
     WHERE m.user_id != ?
       AND m.id > COALESCE((SELECT r.last_read_id FROM room_reads r WHERE r.user_id = ? AND r.room = m.room), 0)
       AND (m.room LIKE 'g:%' OR m.room LIKE ? OR m.room LIKE ?)
     GROUP BY m.room`, req.userId, req.userId, `dm:${req.userId}:%`, `dm:%:${req.userId}`
  );
  const visible = rooms.filter((r) => canAccessRoom(req.userId, r.room));
  res.json({
    total: visible.reduce((a, r) => a + r.n, 0),
    rooms: Object.fromEntries(visible.map((r) => [r.room, r.n])),
  });
});

router.post('/read', (req, res) => {
  const room = String(req.body?.room || '');
  if (!canAccessRoom(req.userId, room)) return res.status(403).json({ error: 'Not in this room' });
  const last = Number(req.body?.lastId) || q.one('SELECT COALESCE(MAX(id),0) AS id FROM messages WHERE room = ?', room).id;
  q.run(`INSERT INTO room_reads (user_id, room, last_read_id) VALUES (?,?,?)
         ON CONFLICT(user_id, room) DO UPDATE SET last_read_id = MAX(excluded.last_read_id, room_reads.last_read_id), updated_at = datetime('now')`,
    req.userId, room, last);
  res.json({ ok: true, room, lastId: last });
});

router.post('/messages/:id/react', (req, res) => {
  const id = Number(req.params.id);
  const emoji = String(req.body?.emoji || '').slice(0, 8);
  const msg = q.one('SELECT * FROM messages WHERE id = ?', id);
  if (!msg) return res.status(404).json({ error: 'Message not found' });
  const existing = q.one('SELECT 1 FROM reactions WHERE message_id = ? AND user_id = ? AND emoji = ?', id, req.userId, emoji);
  if (existing) q.run('DELETE FROM reactions WHERE message_id = ? AND user_id = ? AND emoji = ?', id, req.userId, emoji);
  else q.run('INSERT INTO reactions (message_id, user_id, emoji) VALUES (?,?,?)', id, req.userId, emoji);
  const out = { messageId: id, reactions: reactMap(id) };
  rt.emitToRoom(msg.room, 'reaction', out);
  res.json(out);
});

router.delete('/messages/:id', (req, res) => {
  const msg = q.one('SELECT * FROM messages WHERE id = ?', Number(req.params.id));
  if (!msg) return res.status(404).json({ error: 'Not found' });
  if (msg.user_id !== req.userId) return res.status(403).json({ error: 'Only the author can delete this' });
  q.run("UPDATE messages SET deleted_at = datetime('now') WHERE id = ?", msg.id);
  rt.emitToRoom(msg.room, 'message:deleted', { id: msg.id, room: msg.room });
  res.json({ ok: true });
});

/* -------------------------------------------------- sharing (the point!) */
/** Share a full chart analysis (symbol, tf, snapshot of candles, levels, notes) into a room. */
router.post('/share/analysis', (req, res) => {
  const b = req.body || {};
  const room = String(b.room || '');
  if (!canAccessRoom(req.userId, room)) return res.status(403).json({ error: 'Not in this room' });
  const symbol = String(b.symbol || 'BTCUSD').toUpperCase();
  const tf = String(b.tf || '1h');
  const payload = {
    symbol, tf,
    title: b.title || `${symbol} ${tf} setup`,
    notes: b.notes || '',
    bias: b.bias || 'neutral',
    levels: b.levels || {},
    indicators: b.indicators || {},
    snapshot: b.snapshot || [],
    markers: b.markers || [],
    quote: engine.getQuote(symbol),
    author: req.userId,
  };
  const info = q.run('INSERT INTO messages (room, room_type, user_id, body, kind, payload, symbol) VALUES (?,?,?,?,?,?,?)',
    room, room.startsWith('dm:') ? 'dm' : 'group', req.userId,
    String(b.body || `${symbol} ${tf} — ${payload.bias} bias`).slice(0, 500), 'analysis',
    JSON.stringify(payload), symbol);
  const msg = parsePayload(q.one(
    `SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id WHERE m.id = ?`,
    info.lastInsertRowid));
  rt.emitToRoom(room, 'message', msg);
  if (room.startsWith('dm:')) room.split(':').slice(1).map(Number).filter((x) => x !== req.userId).forEach((uid) => rt.emitToUser(uid, 'dm:new', msg));
  res.json(msg);
});

/** Share a trade card (live position or closed result) into a room. */
router.post('/share/trade', (req, res) => {
  const b = req.body || {};
  const room = String(b.room || '');
  if (!canAccessRoom(req.userId, room)) return res.status(403).json({ error: 'Not in this room' });
  const trade = q.one('SELECT * FROM trades WHERE id = ? AND user_id = ?', Number(b.tradeId), req.userId);
  if (!trade) return res.status(404).json({ error: 'Trade not found' });
  const payload = { trade, message: b.message || '' };
  const info = q.run('INSERT INTO messages (room, room_type, user_id, body, kind, payload, symbol) VALUES (?,?,?,?,?,?,?)',
    room, room.startsWith('dm:') ? 'dm' : 'group', req.userId,
    String(b.message || `${trade.side.toUpperCase()} ${trade.symbol}`).slice(0, 500), 'trade',
    JSON.stringify(payload), trade.symbol);
  const msg = parsePayload(q.one(
    `SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id WHERE m.id = ?`,
    info.lastInsertRowid));
  rt.emitToRoom(room, 'message', msg);
  if (room.startsWith('dm:')) room.split(':').slice(1).map(Number).filter((x) => x !== req.userId).forEach((uid) => rt.emitToUser(uid, 'dm:new', msg));
  res.json(msg);
});

/* -------------------------------------------------------------- DMs list */
router.get('/dm', (req, res) => {
  const rows = q.all(
    `SELECT m.room,
            MAX(m.id) AS lastId,
            MAX(m.created_at) AS lastAt
     FROM messages m WHERE m.room LIKE 'dm:%' AND (m.room LIKE ? OR m.room LIKE ? OR m.room LIKE ?)
     GROUP BY m.room ORDER BY lastAt DESC`,
    `dm:${req.userId}:%`, `dm:%:${req.userId}`, `dm:${req.userId}`
  );
  const out = rows.map((r) => {
    const other = r.room.split(':').slice(1).map(Number).find((id) => id !== req.userId);
    const user = q.one('SELECT id, username, display_name, avatar_color FROM users WHERE id = ?', other);
    const last = parsePayload(q.one('SELECT m.*, u.display_name, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id WHERE m.id = ?', r.lastId));
    const unread = q.one(
      `SELECT COUNT(*) AS n FROM messages m WHERE m.room = ? AND m.user_id != ? AND m.deleted_at IS NULL
       AND m.id > COALESCE((SELECT rr.last_read_id FROM room_reads rr WHERE rr.user_id = ? AND rr.room = ?), 0)`,
      r.room, req.userId, req.userId, r.room
    ).n;
    return { room: r.room, user, last, lastAt: r.lastAt, online: rt.isOnline(other), unread };
  }).filter((x) => x.user);
  res.json(out);
});

router.get('/dm/:userId', (req, res) => {
  const other = Number(req.params.userId);
  const key = dmKey(req.userId, other);
  const rows = q.all(
    `SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id
     WHERE m.room = ? ORDER BY m.id DESC LIMIT ?`, key, Math.min(Number(req.query.limit || 80), 200));
  const user = q.one('SELECT id, username, display_name, avatar_color, bio FROM users WHERE id = ?', other);
  res.json({ room: key, user: user ? { ...user, online: rt.isOnline(other) } : null, messages: rows.reverse().map(parsePayload) });
});

module.exports = router;
