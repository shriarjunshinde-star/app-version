'use strict';
const express = require('express');
const { q } = require('../db');
const { requireAuth } = require('../auth');
const { round } = require('../pnl');

const router = express.Router();
router.use(requireAuth);

const dayOf = (d) => new Date(d || Date.now()).toISOString().slice(0, 10);

/** Recompute the day's net outcome + review completion from the trade book. */
function decorate(entry, userId) {
  if (!entry) return null;
  const trades = q.all(
    `SELECT * FROM trades WHERE user_id = ? AND date(COALESCE(closed_at, opened_at)) = date(?) ORDER BY COALESCE(closed_at, opened_at)`,
    userId, entry.day
  );
  const closed = trades.filter((t) => t.status === 'closed');
  const net = round(closed.reduce((a, t) => a + t.pnl, 0), 2);
  const wins = closed.filter((t) => t.pnl > 0).length;
  const reviewed = trades.filter((t) => t.notes && t.notes.trim().length > 8).length;
  const processScore = (() => {
    let score = 0;
    if (entry.plan) score += 20;
    if (entry.market_context) score += 15;
    if (entry.discipline >= 3) score += 15;
    if (entry.tomorrow) score += 10;
    if (entry.lessons) score += 10;
    const withStops = closed.filter((t) => t.stop_loss).length;
    if (closed.length === 0) score += 30;
    else score += Math.round((withStops / closed.length) * 30);
    return Math.min(100, score);
  })();
  return {
    ...entry,
    net_outcome: net,
    trades: trades.map((t) => ({ id: t.id, symbol: t.symbol, side: t.side, pnl: t.pnl, status: t.status, r_multiple: t.r_multiple })),
    tradeCount: trades.length,
    closedCount: closed.length,
    wins,
    winRate: closed.length ? round((wins / closed.length) * 100, 1) : null,
    reviewComplete: trades.length ? round((reviewed / trades.length) * 100, 0) : 100,
    processScore,
  };
}

/** GET /api/journal?day=YYYY-MM-DD  → single entry (created on the fly if absent) */
router.get('/', (req, res) => {
  const day = dayOf(req.query.day);
  let entry = q.one('SELECT * FROM journal_entries WHERE user_id = ? AND day = ?', req.userId, day);
  if (!entry) {
    q.run('INSERT INTO journal_entries (user_id, day, session) VALUES (?,?,?)', req.userId, day, guessSession());
    entry = q.one('SELECT * FROM journal_entries WHERE user_id = ? AND day = ?', req.userId, day);
  }
  res.json(decorate(entry, req.userId));
});

function guessSession() {
  const h = new Date().getUTCHours();
  if (h >= 12.5 && h < 17) return 'London / New York overlap';
  if (h >= 7 && h < 12.5) return 'London';
  if (h >= 17 && h < 21) return 'New York';
  if (h >= 0 && h < 7) return 'Tokyo';
  return 'Sydney';
}

router.put('/', (req, res) => {
  const b = req.body || {};
  const day = dayOf(b.day);
  const cur = q.one('SELECT * FROM journal_entries WHERE user_id = ? AND day = ?', req.userId, day);
  if (!cur) q.run('INSERT INTO journal_entries (user_id, day) VALUES (?,?)', req.userId, day);
  q.run(
    `UPDATE journal_entries SET session = COALESCE(?, session), bias = COALESCE(?, bias),
      market_context = COALESCE(?, market_context), plan = COALESCE(?, plan), mood = COALESCE(?, mood),
      discipline = COALESCE(?, discipline), lessons = COALESCE(?, lessons), tomorrow = COALESCE(?, tomorrow),
      updated_at = datetime('now') WHERE user_id = ? AND day = ?`,
    b.session ?? null, b.bias ?? null, b.marketContext ?? null, b.plan ?? null,
    b.mood ?? null, b.discipline ?? null, b.lessons ?? null, b.tomorrow ?? null, req.userId, day
  );
  res.json(decorate(q.one('SELECT * FROM journal_entries WHERE user_id = ? AND day = ?', req.userId, day), req.userId));
});

router.get('/range', (req, res) => {
  const days = Math.min(Number(req.query.days || 30), 365);
  const rows = q.all('SELECT * FROM journal_entries WHERE user_id = ? ORDER BY day DESC LIMIT ?', req.userId, days);
  const pnlByDay = q.all(
    `SELECT date(COALESCE(closed_at, opened_at)) AS day, ROUND(SUM(pnl),2) AS pnl, COUNT(*) AS trades
     FROM trades WHERE user_id = ? AND status='closed' GROUP BY day ORDER BY day DESC LIMIT ?`, req.userId, days);
  const map = Object.fromEntries(pnlByDay.map((r) => [r.day, r]));
  res.json(rows.map((r) => ({
    day: r.day, session: r.session, mood: r.mood, discipline: r.discipline,
    pnl: map[r.day]?.pnl ?? 0, trades: map[r.day]?.trades ?? 0,
    hasNotes: !!(r.plan || r.lessons || r.market_context || r.tomorrow),
  })));
});

router.get('/stats', (req, res) => {
  const rows = q.all('SELECT * FROM journal_entries WHERE user_id = ?', req.userId);
  const filled = rows.filter((r) => r.plan || r.lessons || r.market_context);
  const avg = (k) => rows.length ? round(rows.reduce((a, r) => a + (r[k] || 0), 0) / rows.length, 2) : 0;
  res.json({
    entries: rows.length,
    completedEntries: filled.length,
    avgMood: avg('mood'),
    avgDiscipline: avg('discipline'),
    streak: (() => {
      let s = 0; const d = new Date();
      for (;;) {
        const key = d.toISOString().slice(0, 10);
        const hit = rows.find((r) => r.day === key && (r.plan || r.lessons));
        if (hit) { s++; d.setDate(d.getDate() - 1); } else break;
      }
      return s;
    })(),
  });
});

module.exports = router;
