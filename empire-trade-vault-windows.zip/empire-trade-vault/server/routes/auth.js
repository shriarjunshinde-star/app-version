'use strict';
/**
 * Accounts: username + email sign-in, email verification, password reset,
 * profile management and the trader directory.
 */
const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');

const CONFIG = require('../config');
const { q, makeAccount } = require('../db');
const { sign, requireAuth } = require('../auth');
const mailer = require('../mailer');

const router = express.Router();

const COLORS = ['#C9A94C', '#4CAF7D', '#5AA2F0', '#D96456', '#A78BFA', '#F59E0B', '#22D3EE', '#F472B6'];
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const normEmail = (e) => String(e || '').trim().toLowerCase();
const newToken = () => crypto.randomBytes(24).toString('hex');

/* Sensitive endpoints get their own limiter (per IP). */
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many attempts — please wait a few minutes and try again.' },
});
const mailLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: 12,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many emails requested — try again later.' },
});

const publicUser = (u) => ({
  id: u.id, username: u.username, display_name: u.display_name, avatar_color: u.avatar_color,
  bio: u.bio, country: u.country, email: u.email,
  emailVerified: !!u.email_verified, createdAt: u.created_at,
});

/** In development, hand the action link back so flows work without SMTP. */
const devLink = (mail, path, token) => (
  !mailer.isLive() && !CONFIG.IS_PROD ? `${CONFIG.PUBLIC_URL}${path}?token=${token}` : undefined
);

/* ═════════════════════════════════════════════════════ register */
router.post('/register', authLimiter, async (req, res) => {
  try {
    const { username, password, displayName, email, startBalance, riskPerTrade } = req.body || {};
    const uname = String(username || '').trim().toLowerCase().replace(/[^a-z0-9_.]/g, '');
    const mail = normEmail(email);

    if (uname.length < 3) return res.status(400).json({ error: 'Username must be at least 3 characters (letters, numbers, _ or .)' });
    if (!mail || !EMAIL_RE.test(mail)) return res.status(400).json({ error: 'A valid email address is required — it is how you sign in and recover your account' });
    if (!password || String(password).length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
    if (q.one('SELECT id FROM users WHERE username = ?', uname)) return res.status(409).json({ error: 'That username is already taken' });
    if (q.one('SELECT id FROM users WHERE email = ?', mail)) return res.status(409).json({ error: 'An account with that email already exists — try signing in instead' });

    const hash = bcrypt.hashSync(String(password), 10);
    const verifyToken = newToken();
    const info = q.run(
      `INSERT INTO users (username, email, password_hash, display_name, avatar_color, email_verified, verify_token, verify_expires)
       VALUES (?,?,?,?,?,0,?,datetime('now','+1 day'))`,
      uname, mail, hash, (displayName || uname).slice(0, 60),
      COLORS[Math.floor(Math.random() * COLORS.length)], verifyToken
    );
    const userId = info.lastInsertRowid;

    const balance = Number(startBalance) > 0 ? Number(startBalance) : 100000;
    const accId = makeAccount(userId, 'Vault Paper #1', balance);
    q.run('UPDATE accounts SET is_default = 1 WHERE id = ?', accId);
    if (Number(riskPerTrade) > 0) q.run('UPDATE accounts SET risk_per_trade = ? WHERE id = ?', Number(riskPerTrade), accId);

    // join every public room so a new trader lands in a populated terminal
    q.all('SELECT id FROM groups WHERE is_private = 0').forEach((r) =>
      q.run('INSERT OR IGNORE INTO group_members (group_id, user_id) VALUES (?,?)', r.id, userId));

    const user = q.one('SELECT * FROM users WHERE id = ?', userId);
    const mail1 = await mailer.sendVerification(user, verifyToken);
    mailer.sendWelcome(user).catch(() => {});

    res.json({
      token: sign(user),
      user: publicUser(user),
      verificationSent: !!mail1.sent || !!mail1.queued,
      emailConfigured: mailer.isLive(),
      devVerifyLink: devLink(mail1, '/verify-email', verifyToken),
    });
  } catch (e) {
    console.error('[auth/register]', e.message);
    res.status(500).json({ error: 'Could not create the account: ' + e.message });
  }
});

/* ═════════════════════════════════════════════════════════ login */
router.post('/login', authLimiter, (req, res) => {
  const id = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  if (!id || !password) return res.status(400).json({ error: 'Enter your email (or username) and password' });

  const user = q.one(
    'SELECT * FROM users WHERE username = ? OR email = ?',
    id.toLowerCase(), normEmail(id)
  );
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Invalid email / username or password' });
  }
  if (CONFIG.REQUIRE_EMAIL_VERIFICATION && user.email && !user.email_verified) {
    return res.status(403).json({ error: 'Please confirm your email address first — check your inbox for the link.', needsVerification: true });
  }
  q.run("UPDATE users SET last_login = datetime('now') WHERE id = ?", user.id);
  res.json({ token: sign(user), user: publicUser(user) });
});

/* ═════════════════════════════════════════════════════ current user */
router.get('/me', requireAuth, (req, res) => {
  const user = q.one('SELECT * FROM users WHERE id = ?', req.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ user: publicUser(user), accounts: q.all('SELECT * FROM accounts WHERE user_id = ?', req.userId) });
});

router.patch('/me', requireAuth, (req, res) => {
  const { displayName, bio, country, avatarColor } = req.body || {};
  q.run(
    `UPDATE users SET display_name = COALESCE(?, display_name), bio = COALESCE(?, bio),
     country = COALESCE(?, country), avatar_color = COALESCE(?, avatar_color) WHERE id = ?`,
    displayName ?? null, bio ?? null, country ?? null, avatarColor ?? null, req.userId
  );
  res.json(publicUser(q.one('SELECT * FROM users WHERE id = ?', req.userId)));
});

/* change password while signed in */
router.post('/password', requireAuth, authLimiter, (req, res) => {
  const { current, next } = req.body || {};
  const user = q.one('SELECT * FROM users WHERE id = ?', req.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (!bcrypt.compareSync(String(current || ''), user.password_hash)) return res.status(401).json({ error: 'Current password is incorrect' });
  if (String(next || '').length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  q.run('UPDATE users SET password_hash = ? WHERE id = ?', bcrypt.hashSync(String(next), 10), user.id);
  res.json({ ok: true });
});

/* ═════════════════════════════════════════════ email verification */
router.post('/verify-email', authLimiter, (req, res) => {
  const token = String(req.body?.token || req.query?.token || '');
  if (!token) return res.status(400).json({ error: 'Verification token missing' });
  const user = q.one('SELECT * FROM users WHERE verify_token = ?', token);
  if (!user) return res.status(400).json({ error: 'That link is not valid any more — request a new one.' });
  if (user.verify_expires && new Date(user.verify_expires.replace(' ', 'T') + 'Z') < new Date()) {
    return res.status(400).json({ error: 'That link has expired — request a new one from your profile.' });
  }
  q.run("UPDATE users SET email_verified = 1, verify_token = NULL, verify_expires = NULL WHERE id = ?", user.id);
  res.json({ ok: true, user: publicUser(q.one('SELECT * FROM users WHERE id = ?', user.id)) });
});

router.post('/resend-verification', requireAuth, mailLimiter, async (req, res) => {
  const user = q.one('SELECT * FROM users WHERE id = ?', req.userId);
  if (!user?.email) return res.status(400).json({ error: 'No email on this account' });
  if (user.email_verified) return res.json({ ok: true, alreadyVerified: true });
  const token = newToken();
  q.run("UPDATE users SET verify_token = ?, verify_expires = datetime('now','+1 day') WHERE id = ?", token, user.id);
  const out = await mailer.sendVerification(user, token);
  res.json({ ok: true, sent: !!out.sent || !!out.queued, emailConfigured: mailer.isLive(), devVerifyLink: devLink(out, '/verify-email', token) });
});

/* ═════════════════════════════════════════════ password reset */
router.post('/forgot-password', mailLimiter, async (req, res) => {
  const mail = normEmail(req.body?.email);
  // always answer the same way — never reveal whether an address exists
  const generic = { ok: true, message: 'If that email is registered you will receive a reset link shortly.' };
  if (!mail) return res.status(400).json({ error: 'Enter the email address on your account' });
  const user = q.one('SELECT * FROM users WHERE email = ?', mail);
  if (!user) return res.json(generic);
  const token = newToken();
  q.run("UPDATE users SET reset_token = ?, reset_expires = datetime('now','+1 hour') WHERE id = ?", token, user.id);
  const out = await mailer.sendPasswordReset(user, token);
  res.json({ ...generic, emailConfigured: mailer.isLive(), devResetLink: devLink(out, '/reset-password', token) });
});

router.post('/reset-password', authLimiter, (req, res) => {
  const token = String(req.body?.token || '');
  const next = String(req.body?.password || '');
  if (!token) return res.status(400).json({ error: 'Reset token missing' });
  if (next.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  const user = q.one('SELECT * FROM users WHERE reset_token = ?', token);
  if (!user) return res.status(400).json({ error: 'That reset link is not valid any more — request a new one.' });
  if (user.reset_expires && new Date(user.reset_expires.replace(' ', 'T') + 'Z') < new Date()) {
    return res.status(400).json({ error: 'That reset link has expired — request a new one.' });
  }
  q.run("UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?",
    bcrypt.hashSync(next, 10), user.id);
  res.json({ ok: true, token: sign(user), user: publicUser(q.one('SELECT * FROM users WHERE id = ?', user.id)) });
});

/* ═══════════════════════════════════════════════════ directory */
router.get('/users', requireAuth, (req, res) => {
  res.json(q.all(
    `SELECT u.id, u.username, u.display_name, u.avatar_color, u.bio, u.email,
            EXISTS(SELECT 1 FROM sessions s WHERE s.user_id = u.id) AS has_session
     FROM users u WHERE u.id != ? ORDER BY u.display_name`, req.userId
  ).map(({ has_session, ...u }) => u));
});

/* Who am I on this deployment (handy for the client + health checks). */
router.get('/config', (req, res) => {
  res.json({
    appName: CONFIG.APP_NAME, tagline: CONFIG.APP_TAGLINE, owner: CONFIG.OWNER,
    env: CONFIG.ENV, publicUrl: CONFIG.PUBLIC_URL,
    emailConfigured: mailer.isLive(),
    requireEmailVerification: CONFIG.REQUIRE_EMAIL_VERIFICATION,
    maxUploadMb: CONFIG.MAX_UPLOAD_MB, attachments: CONFIG.ATTACHMENTS,
  });
});

module.exports = router;
