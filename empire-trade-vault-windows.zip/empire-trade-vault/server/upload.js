'use strict';
/**
 * File uploads for the messenger — images and documents.
 *
 *   POST /api/upload      multipart/form-data, field "file" (repeatable)
 *   GET  /uploads/<path>  static file server (random unguessable names)
 *
 * Safety: extension + mime whitelist, size cap, random uuid names, no
 * executable/scriptable types, files stored by month so a volume stays tidy.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const CONFIG = require('./config');
const { requireAuth } = require('./auth');

const IMAGE_EXT = new Set(CONFIG.ATTACHMENTS.image);
const DOC_EXT = new Set(CONFIG.ATTACHMENTS.doc);
const ALLOWED = new Set([...IMAGE_EXT, ...DOC_EXT]);

fs.mkdirSync(CONFIG.UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination(req, file, cb) {
    const month = new Date().toISOString().slice(0, 7);           // YYYY-MM
    const dir = path.join(CONFIG.UPLOAD_DIR, month);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename(req, file, cb) {
    const ext = path.extname(file.originalname || '').toLowerCase().slice(0, 8);
    cb(null, `${Date.now().toString(36)}-${crypto.randomBytes(8).toString('hex')}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: CONFIG.MAX_UPLOAD_MB * 1024 * 1024, files: 6 },
  fileFilter(req, file, cb) {
    const ext = path.extname(file.originalname || '').toLowerCase();
    if (!ALLOWED.has(ext)) return cb(new Error(`File type ${ext || '(none)'} is not allowed`));
    cb(null, true);
  },
});

const router = express.Router();

/** Human readable size helper for the message payload. */
const human = (bytes) => {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
};

router.post('/upload', requireAuth, (req, res) => {
  upload.array('file', 6)(req, res, (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: `That file is bigger than the ${CONFIG.MAX_UPLOAD_MB} MB limit` });
      }
      if (err.code === 'LIMIT_FILE_COUNT') {
        return res.status(413).json({ error: 'Too many files at once — send up to 6 per message' });
      }
      return res.status(400).json({ error: err.message });
    }
    const files = req.files || [];
    if (!files.length) return res.status(400).json({ error: 'No file received' });
    const out = files.map((f) => {
      const ext = path.extname(f.filename).toLowerCase();
      const rel = path.relative(CONFIG.UPLOAD_DIR, f.path).split(path.sep).join('/');
      return {
        id: crypto.randomUUID(),
        name: f.originalname,
        size: f.size,
        sizeText: human(f.size),
        mime: f.mimetype,
        kind: IMAGE_EXT.has(ext) ? 'image' : 'doc',
        ext: ext.replace('.', ''),
        url: '/uploads/' + rel,
        uploadedAt: new Date().toISOString(),
      };
    });
    res.json({ files: out });
  });
});

/** Serve stored files with headers that stop browsers executing anything. */
const staticServer = express.static(CONFIG.UPLOAD_DIR, {
  index: false,
  dotfiles: 'ignore',
  maxAge: '30d',
  setHeaders(res, filePath) {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self'; media-src 'self'");
    if (!/\.(png|jpe?g|gif|webp)$/i.test(filePath)) {
      res.setHeader('Content-Disposition', 'attachment');       // never render docs inline
    }
  },
});

module.exports = { router, staticServer, upload };
