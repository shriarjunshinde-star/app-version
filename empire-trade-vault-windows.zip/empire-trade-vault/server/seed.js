'use strict';
require('./dep_path').ensurePath();   // resolve deps from ./deps or ./node_modules
/**
 * Demo vault seeder — creates traders, accounts, playbooks, a realistic trade
 * book, journal entries, chat rooms with shared chart analyses and trade cards.
 * Safe to run repeatedly: it exits early if users already exist (use --force to reset).
 */
const bcrypt = require('bcryptjs');
const { db, q, makeAccount } = require('./db');
const engine = require('./marketdata');
const CONFIG = require('./config');
const { computePnl, riskAmount, rMultiple, round } = require('./pnl');
const { writeDemoFiles } = require('./seed_files');

const rand = (() => { let s = 20261004; return () => ((s = (s * 1103515245 + 12345) % 2147483648) / 2147483648); })();
const pick = (arr) => arr[Math.floor(rand() * arr.length)];
const between = (a, b) => a + rand() * (b - a);
const daysAgo = (n, hour = 10) => {
  const d = new Date(); d.setUTCDate(d.getUTCDate() - n); d.setUTCHours(hour, Math.floor(rand() * 59), 0, 0);
  return d.toISOString().slice(0, 19).replace('T', ' ');
};
const dayStr = (n) => { const d = new Date(); d.setUTCDate(d.getUTCDate() - n); return d.toISOString().slice(0, 10); };

const USERS = [
  { username: 'arjunshinde', display_name: 'Arjun Shinde', email: 'arjun.shinde@arjun.trade', admin: 1, color: '#C9A94C', bio: 'Founder of the Arjun desk. Gold, indices and crypto — process over predictions.', country: 'IN', balance: 250000 },
  { username: 'trader', display_name: 'Vikram Rao', email: 'vikram@arjun.trade', color: '#22D3EE', bio: 'Discretionary day trader. Gold + index futures. Process > predictions.', country: 'IN', balance: 100000 },
  { username: 'mentor', display_name: 'Meera Nair', email: 'meera@arjun.trade', color: '#4CAF7D', bio: '15 yrs on the floor. Mentoring the Arjun group since 2019.', country: 'IN', balance: 250000 },
  { username: 'riya', display_name: 'Riya Sharma', email: 'riya@arjun.trade', color: '#5AA2F0', bio: 'Swing trader. Crypto + BTC dominance watcher.', country: 'IN', balance: 50000 },
  { username: 'arjun', display_name: 'Arjun Mehta', email: 'arjun.mehta@arjun.trade', color: '#D96456', bio: 'BankNifty scalper, VWAP & order-flow only.', country: 'IN', balance: 75000 },
];

const PLAYBOOKS = [
  { name: 'London Sweep + Reclaim', color: '#C9A94C', description: 'Wait for the London open sweep of the Asian low, then trade the reclaim back into value with the 15m trend.',
    rules: ['Sweep must take out Asia low/high', 'Reclaim within 3 candles', 'Risk ≤ 1% and stop behind the sweep wick', 'First target = VWAP, runner to swing high'] },
  { name: 'VWAP Rejection Short', color: '#D96456', description: 'Intraday fade when price taps VWAP from below after failing to hold above it.',
    rules: ['Loss of VWAP on 15m close', 'Retest rejects with a lower high', 'Stop above the retest high', 'Trail once 1R hits'] },
  { name: 'Trend Pullback 4H', color: '#4CAF7D', description: 'Buy the first controlled pullback into EMA20 on the 4H inside an established uptrend.',
    rules: ['EMA20 > EMA50 > EMA200 on 4H', 'Pullback holds above EMA50', 'Enter on the invalidation of the pullback candle', 'Let the runner go to prior ATH'] },
  { name: 'Range Fade (Asia)', color: '#5AA2F0', description: 'Fade the edges of the Asian range when the daily ATR is below average.',
    rules: ['Range width < 0.4 × ADR', 'Fade extreme with tight stop', 'Exit at mid-range', 'No trades inside 30 min of news'] },
  { name: 'Breakout Continuation', color: '#A78BFA', description: 'Crypto 1H range breakout with volume confirmation and a retest entry.',
    rules: ['Range drawn from at least 12 candles', 'Volume > 1.5× 20-period average', 'Enter on the retest, not the impulse', 'Invalid on close back inside the range'] },
];

const TAGS = ['A+ setup', 'revenge trade', 'news day', 'chased entry', 'patience paid', 'scaled out', 'stop moved early', 'session open', 'trend day', 'choppy'];
const EMOTIONS = ['calm', 'confident', 'anxious', 'fomo', 'patient', 'frustrated'];
const SETTINGS = ['London', 'New York', 'London / New York overlap', 'Asia'];
const NOTES_GOOD = [
  'Waited for the retest instead of chasing. Entry was textbook, stop behind the wick. Managed to break even the moment momentum stalled.',
  'Bias was right, execution was clean. Took half at 1.5R and trailed the rest under the 15m structure.',
  'Market swept liquidity, took the reclaim, exited at VWAP. No hesitation on the trigger.',
  'Sized correctly for once. Small loss on the first attempt, then the second entry paid for the day.',
];
const NOTES_BAD = [
  'Entered before confirmation because I was bored. Stop was too tight, got wicked out, then price went my way.',
  'Revenge trade straight after the stop-out. Doubled size to get it back — classic mistake.',
  'Chased a candle that was already 1.2 ATR extended. Poor location, no edge at that price.',
  'Moved my stop to break-even too early and got shaken out of a runner.',
];
const CHAT = [
  'Morning all — Asia swept the lows into London open. Watching for a reclaim before the US data.',
  'Careful with the 13:30 print today, spreads widen right before it.',
  'I am flat until the NY open. Range too tight to pay for the risk.',
  'Bias flipped for me, daily closed under the EMA50. Rallies are for selling now.',
  'Anyone else short gold here or am I alone?',
  'Took the sweep + reclaim on EURUSD, 1.2R banked. Keeping the runner over the data.',
  'Great catch on that level yesterday, that pivot held perfectly.',
  'Reminder: journal your entry reason BEFORE the entry, not after the exit.',
  'BankNifty is coiling under VWAP, waiting for the rejection candle.',
  'Volume is thin today, the range is only 0.3 ADR. Fading edges only.',
];

async function runSeed({ force = false } = {}) {
  if (q.one('SELECT COUNT(*) c FROM users').c > 0 && !force) {
    console.log('[seed] users already exist — skipping (use --force to rebuild).');
    return;
  }
  if (force) {
    ['reactions', 'messages', 'group_members', 'groups', 'journal_entries', 'trades', 'playbooks', 'watchlist', 'alerts', 'notifications', 'accounts', 'users'].forEach((t) => db.exec(`DELETE FROM ${t}`));
    db.exec("DELETE FROM sqlite_sequence WHERE name IN ('users','accounts','trades','playbooks','groups','messages','journal_entries','alerts','notifications')");
  }

  // --- warm the quote cache so seeded trades are priced near reality -------
  await Promise.race([engine.refreshQuotes(), new Promise((r) => setTimeout(r, 12000))]);
  const priceOf = (sym) => engine.getQuote(sym)?.price ?? CONFIG.SYMBOL_MAP[sym].base;
  console.log('[seed] quotes ready, seeding vault…');

  /* ---------------------------------------------------------- users */
  const hash = bcrypt.hashSync(CONFIG.DEFAULT_SEED_PASSWORD, 10);
  const ownerHash = bcrypt.hashSync('arjun123', 10);
  const userIds = {};
  USERS.forEach((u) => {
    const info = q.run(`INSERT INTO users (username, email, password_hash, display_name, avatar_color, bio, country, email_verified, is_admin, last_login)
        VALUES (?,?,?,?,?,?,?,1,?,?)`,
      u.username, u.email, u.username === 'arjunshinde' ? ownerHash : hash, u.display_name, u.color, u.bio, u.country,
      u.admin ? 1 : 0, new Date().toISOString());
    userIds[u.username] = info.lastInsertRowid;
    makeAccount(info.lastInsertRowid, 'Vault Paper #1', u.balance);
  });
  const trader = userIds.arjunshinde;               // primary demo vault = Arjun Shinde
  const mentor = userIds.mentor, riya = userIds.riya, arjun = userIds.arjun;

  /* ------------------------------------------------------ playbooks */
  const playbookIds = {};
  Object.entries({ trader, mentor, riya, arjun }).forEach(([uname, uid]) => {
    PLAYBOOKS.forEach((p) => {
      const info = q.run('INSERT INTO playbooks (user_id, name, description, rules, color) VALUES (?,?,?,?,?)',
        uid, p.name, p.description, JSON.stringify(p.rules), p.color);
      playbookIds[`${uname}:${p.name}`] = info.lastInsertRowid;
    });
  });

  /* --------------------------------------------------------- groups */
  const GROUPS = [
    { name: 'Arjun Floor', topic: 'Main room — daily bias, levels and live setups', icon: 'E' },
    { name: 'Gold & FX Desk', topic: 'XAUUSD, EURUSD, GBPUSD — session playbooks', icon: 'G' },
    { name: 'Crypto 24/7', topic: 'BTC, ETH and majors. Breakout continuation setups.', icon: 'C' },
    { name: 'Nifty & BankNifty', topic: 'India session — VWAP scalps and expiry notes', icon: 'N' },
    { name: 'Risk & Psychology', topic: 'Journal reviews, tilt control, process scores', icon: 'R' },
  ];
  const groupIds = {};
  GROUPS.forEach((g) => {
    const info = q.run('INSERT INTO groups (slug, name, topic, icon, created_by) VALUES (?,?,?,?,?)',
      g.name.toLowerCase().replace(/[^a-z0-9]+/g, '-'), g.name, g.topic, g.icon, mentor);
    groupIds[g.name] = info.lastInsertRowid;
  });
  const everyone = [trader, userIds.trader, mentor, riya, arjun];
  const membership = {
    'Arjun Floor': everyone,
    'Gold & FX Desk': [trader, mentor, arjun],
    'Crypto 24/7': [trader, riya, mentor],
    'Nifty & BankNifty': [trader, arjun, mentor],
    'Risk & Psychology': everyone,
  };
  Object.entries(membership).forEach(([name, members]) => {
    members.forEach((uid) => q.run('INSERT OR IGNORE INTO group_members (group_id, user_id, role) VALUES (?,?,?)',
      groupIds[name], uid, uid === mentor ? 'owner' : 'member'));
  });

  /* --------------------------------------------------------- trades */
  const SIM = [
    // symbol, lots/units range, win rate, avg R, typical stop distance in ATR multiples
    { symbol: 'XAUUSD', size: [0.2, 0.6], winRate: 0.58, atr: 9 },
    { symbol: 'EURUSD', size: [0.3, 1.0], winRate: 0.52, atr: 0.0016 },
    { symbol: 'GBPUSD', size: [0.3, 0.8], winRate: 0.48, atr: 0.0019 },
    { symbol: 'NAS100', size: [0.5, 2], winRate: 0.55, atr: 60 },
    { symbol: 'BTCUSD', size: [0.02, 0.15], winRate: 0.51, atr: 900 },
    { symbol: 'ETHUSD', size: [0.2, 1.2], winRate: 0.49, atr: 55 },
    { symbol: 'USOIL', size: [0.2, 0.8], winRate: 0.5, atr: 0.6 },
    { symbol: 'NIFTY50', size: [3, 12], winRate: 0.6, atr: 45 },
    { symbol: 'BANKNIFTY', size: [2, 8], winRate: 0.57, atr: 110 },
    { symbol: 'USDJPY', size: [0.3, 0.9], winRate: 0.53, atr: 0.22 },
    { symbol: 'NVDA', size: [5, 25], winRate: 0.52, atr: 3 },
    { symbol: 'RELIANCE', size: [10, 40], winRate: 0.5, atr: 10 },
  ];
  const owners = [
    { uid: trader, share: 0.42 }, { uid: userIds.trader, share: 0.16 }, { uid: mentor, share: 0.2 },
    { uid: riya, share: 0.12 }, { uid: arjun, share: 0.1 },
  ];
  const playbookNames = PLAYBOOKS.map((p) => p.name);

  const tradeIds = [];
  let day = 45;
  while (day >= 0) {
    const tradesToday = day % 7 === 0 ? Math.floor(between(0, 2)) : Math.floor(between(1, 4));
    for (let i = 0; i < tradesToday; i++) {
      const sim = pick(SIM);
      const owner = pick(owners);
      const uid = owner.uid;
      const uname = USERS.find((u) => userIds[u.username] === uid).username;
      const pbName = pick(playbookNames);
      const acc = q.one('SELECT * FROM accounts WHERE user_id = ? LIMIT 1', uid);
      const base = priceOf(sim.symbol);
      const drift = 1 + between(-0.06, 0.06) * (day / 45 + 0.2);
      const entry = round(base * drift, CONFIG.SYMBOL_MAP[sim.symbol].digits);
      const side = rand() > 0.48 ? 'buy' : 'sell';
      const stopDist = sim.atr * between(0.8, 1.6);
      const stop = round(side === 'buy' ? entry - stopDist : entry + stopDist, CONFIG.SYMBOL_MAP[sim.symbol].digits);
      const qty = round(between(sim.size[0], sim.size[1]), 2);
      const plannedRR = pick([1.5, 2, 2.5, 3]);
      const target = round(side === 'buy' ? entry + stopDist * plannedRR : entry - stopDist * plannedRR, CONFIG.SYMBOL_MAP[sim.symbol].digits);
      const win = rand() < sim.winRate;
      const rOutcome = win ? between(0.7, plannedRR + 0.4) : -between(0.35, 1.05);
      const exit = round(side === 'buy' ? entry + stopDist * rOutcome : entry - stopDist * rOutcome, CONFIG.SYMBOL_MAP[sim.symbol].digits);
      const openedAt = daysAgo(day, Math.floor(between(7, 17)));
      const closedAt = daysAgo(day, Math.min(22, Math.floor(between(8, 21))));
      const risk = riskAmount(sim.symbol, entry, stop, qty);
      const { pnl } = computePnl(sim.symbol, side, entry, exit, qty);
      const tags = [pick(TAGS)];
      if (rand() > 0.6) tags.push(pick(TAGS));
      const notes = pick(win ? NOTES_GOOD : NOTES_BAD);
      const info = q.run(
        `INSERT INTO trades (user_id, account_id, symbol, side, qty, entry_price, exit_price, stop_loss, take_profit,
          status, order_type, opened_at, closed_at, pnl, r_multiple, risk_amount, close_reason, playbook_id, setup_tag,
          tags, emotion, confidence, notes, origin)
         VALUES (?,?,?,?,?,?,?,?,?,'closed','market',?,?,?,?,?,?,?,?,?,?,?,?, 'seed')`,
        uid, acc.id, sim.symbol, side, qty, entry, exit, stop, target, openedAt, closedAt,
        pnl, rMultiple(pnl, risk), risk, win ? (rand() > 0.5 ? 'take profit' : 'manual') : (rand() > 0.4 ? 'stop loss' : 'manual'),
        playbookIds[`${uname}:${pbName}`], pbName, JSON.stringify(tags), pick(EMOTIONS),
        Math.floor(between(2, 6)), notes
      );
      tradeIds.push({ id: info.lastInsertRowid, uid, symbol: sim.symbol, side, entry, qty, stop, target, pnl, openedAt });
    }
    day--;
  }

  // settlement — the seed trades are already closed, so fold the P&L into balances
  q.all("SELECT account_id, SUM(pnl) s FROM trades WHERE status='closed' GROUP BY account_id")
    .forEach((row) => q.run('UPDATE accounts SET balance = start_balance + ? WHERE id = ?', round(row.s, 2), row.account_id));

  /* ---------------------------------------------------- open positions */
  const OPEN = [
    { uid: trader, symbol: 'XAUUSD', side: 'buy', size: 0.4, atr: 9, rr: 2.5 },
    { uid: trader, symbol: 'BTCUSD', side: 'buy', size: 0.08, atr: 900, rr: 3 },
    { uid: riya, symbol: 'ETHUSD', side: 'sell', size: 0.8, atr: 55, rr: 2 },
    { uid: arjun, symbol: 'BANKNIFTY', side: 'buy', size: 4, atr: 110, rr: 1.5 },
    { uid: mentor, symbol: 'EURUSD', side: 'buy', size: 0.6, atr: 0.0016, rr: 2 },
  ];
  const openIds = [];
  OPEN.forEach((o, idx) => {
    const acc = q.one('SELECT * FROM accounts WHERE user_id = ? LIMIT 1', o.uid);
    const price = priceOf(o.symbol);
    const d = CONFIG.SYMBOL_MAP[o.symbol].digits;
    // some positions sit slightly in the money, one is under water
    const offset = (idx % 3 === 2 ? -1 : 1) * o.atr * between(0.2, 0.7);
    const entry = round(o.side === 'buy' ? price - offset : price + offset, d);
    const stop = round(o.side === 'buy' ? entry - o.atr * 1.2 : entry + o.atr * 1.2, d);
    const target = round(o.side === 'buy' ? entry + o.atr * 1.2 * o.rr : entry - o.atr * 1.2 * o.rr, d);
    const risk = riskAmount(o.symbol, entry, stop, o.size);
    const info = q.run(
      `INSERT INTO trades (user_id, account_id, symbol, side, qty, entry_price, stop_loss, take_profit, status,
        order_type, opened_at, risk_amount, playbook_id, setup_tag, tags, emotion, confidence, notes, origin)
       VALUES (?,?,?,?,?,?,?,?,'open','market',?,?,?,?,?,?,?,?,'seed')`,
      o.uid, acc.id, o.symbol, o.side, o.size, entry, stop, target, daysAgo(0, Math.floor(between(3, 9))),
      risk, playbookIds[`${USERS.find((u) => userIds[u.username] === o.uid).username}:${pick(playbookNames)}`],
      'Trend Pullback 4H', JSON.stringify([pick(TAGS)]), 'calm', Math.floor(between(3, 6)),
      'Runner from yesterday, stop trailed to the 4H structure. Letting the plan work.'
    );
    openIds.push({ id: info.lastInsertRowid, ...o, entry, stop, target });
  });

  // two working limit orders
  [{ uid: trader, symbol: 'SOLUSD', side: 'buy', qty: 8, drop: 0.04 }, { uid: riya, symbol: 'NIFTY50', side: 'buy', qty: 6, drop: 0.03 }]
    .forEach((o) => {
      const acc = q.one('SELECT * FROM accounts WHERE user_id = ? LIMIT 1', o.uid);
      const price = priceOf(o.symbol);
      const d = CONFIG.SYMBOL_MAP[o.symbol].digits;
      const entry = round(price * (1 - o.drop), d);
      q.run(`INSERT INTO trades (user_id, account_id, symbol, side, qty, entry_price, stop_loss, status, order_type, opened_at, setup_tag, tags, origin)
             VALUES (?,?,?,?,?,?,?,'pending','limit',?,?,?,'seed')`,
        o.uid, acc.id, o.symbol, o.side, o.qty, entry, round(entry * 0.96, d), daysAgo(0, 8), 'Range Fade (Asia)', JSON.stringify(['patience paid']));
    });

  /* ------------------------------------------------------ journal days */
  for (let d = 30; d >= 0; d--) {
    const trades = q.all("SELECT * FROM trades WHERE user_id = ? AND date(COALESCE(closed_at, opened_at)) = date(?)", trader, dayStr(d));
    const net = trades.filter((t) => t.status === 'closed').reduce((a, t) => a + t.pnl, 0);
    const win = net >= 0;
    q.run(`INSERT INTO journal_entries (user_id, day, session, bias, market_context, plan, mood, discipline, lessons, tomorrow, review_complete)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      trader, dayStr(d), pick(SETTINGS), win ? 'bullish' : 'bearish',
      pick([
        'Dollar soft across the board, gold holding the daily EMA20. Asia left a clean low to sweep.',
        'Index futures gapped into resistance, VWAP rejected twice on the 15m.',
        'Range-bound session, ATR well below average. Nothing to chase today.',
        'Crypto in a tight 1H range with declining volume; waiting for the breakout retest.',
      ]),
      pick([
        'Plan: fade the Asia extreme with a tight stop, add only if VWAP is reclaimed.',
        'Plan: wait for the London sweep, enter on the reclaim, risk 1% and let the runner go.',
        'Plan: no trades before the data print. Two setups pre-marked, execute only one.',
        'Plan: scale into the pullback at EMA20 with stop under the swing low.',
      ]),
      win ? Math.floor(between(3, 5)) : Math.floor(between(1, 4)),
      win ? Math.floor(between(3, 5)) : Math.floor(between(2, 4)),
      net >= 0
        ? 'Followed the process, sized correctly and let winners breathe. Repeat this.'
        : pick(['Broke my rule on the second entry — no confirmation, and I oversized it.', 'Stopped watching the clock and traded into the close. That is when I give it back.', 'Moved the stop out of fear instead of accepting the loss. That is a process break, not bad luck.']),
      'Mark the Asia range before the open and wait for the sweep. No more than two attempts.',
      1
    );
  }
  // second trader keeps a lighter journal so the room feels real
  for (let d = 10; d >= 0; d -= 3) {
    q.run(`INSERT INTO journal_entries (user_id, day, session, bias, market_context, plan, mood, discipline, lessons, tomorrow, review_complete)
           VALUES (?,?,?,?,?,?,?,?,?,?,1)`,
      userIds.trader, dayStr(d), 'New York', pick(['bullish', 'bearish']),
      'Followed the group bias chart — waited for the retest instead of chasing.',
      'One setup only. If the level fails, I am done for the day.', 4, 4,
      'Charts shared in the room save me from over-thinking.', 'Post my levels before the open.');
  }

  // mentor's journal for realism
  for (let d = 14; d >= 0; d -= 2) {
    q.run(`INSERT INTO journal_entries (user_id, day, session, bias, market_context, plan, mood, discipline, lessons, tomorrow, review_complete)
           VALUES (?,?,?,?,?,?,?,?,?,?,1)`,
      mentor, dayStr(d), 'London', pick(['bullish', 'bearish', 'neutral']),
      'Reviewed the group journals — most losers came from trading before the pullback completed.',
      'Only two A+ setups allowed today. Everything else gets journaled, not traded.',
      4, 5, 'Patience is the edge. The market pays for waiting, not for activity.',
      'Keep the level sheet on the desk, mark sweeps the night before.');
  }

  /* ------------------------------------------------------ chat seeding */
  const demoFiles = writeDemoFiles(CONFIG.UPLOAD_DIR);
  const chartFile = demoFiles.find((f) => f.kind === 'image');
  const sheetFile = demoFiles.find((f) => f.kind === 'doc');
  const msgInsert = q.prepare('INSERT INTO messages (room, room_type, user_id, body, kind, payload, symbol, attachments, created_at) VALUES (?,?,?,?,?,?,?,?,?)');
  const fileMsg = (room, uid, symbol, files, body, at) =>
    msgInsert.run(room, room.startsWith('dm:') ? 'dm' : 'group', uid, body,
      files.some((f) => f.kind === 'image') ? 'image' : 'file', '{}', symbol, JSON.stringify(files), at);
  const mkAnalysis = (symbol, tf = '1h') => {
    const candles = engine.synthCandles(symbol, tf, 90);
    const d = CONFIG.SYMBOL_MAP[symbol].digits;
    const last = candles[candles.length - 1].close;
    const swingLow = Math.min(...candles.map((c) => c.low));
    const swingHigh = Math.max(...candles.map((c) => c.high));
    return {
      symbol, tf,
      title: `${symbol} ${tf} — ${pick(['sweep + reclaim', 'VWAP rejection', 'range breakout retest', 'trend pullback'])}`,
      notes: pick([
        'Asia swept into the low, London reclaimed value. Long against the sweep wick with the target at the prior swing high.',
        'Rejected at VWAP after three failed attempts to hold above. Short the retest, stop above the rejection high.',
        'Volume expansion out of the 1H range. Waiting for the retest of the breakout shelf before committing.',
        'Trend is up but price is 2 ATR extended. I want the pullback into EMA20 before touching this.',
      ]),
      bias: pick(['bullish', 'bearish', 'neutral']),
      levels: { entry: round(last, d), stop: round(pick([swingLow, last - Math.abs(swingHigh - swingLow) * 0.15]), d), target: round(swingHigh, d) },
      indicators: { rsi14: round(between(35, 68), 1), atr14: round(Math.abs(swingHigh - swingLow) / 14, d) },
      snapshot: candles.map((c) => [c.time, c.open, c.high, c.low, c.close]),
      markers: [{ time: candles[candles.length - 8].time, position: 'belowBar', color: '#4CAF7D', shape: 'arrowUp', text: 'entry' }],
    };
  };

  // room history — last 6 days of conversation
  for (let d = 6; d >= 0; d--) {
    const perRoom = d === 0 ? 6 : 3 + Math.floor(rand() * 4);
    for (let i = 0; i < perRoom; i++) {
      const gname = pick(GROUPS).name;
      const gid = groupIds[gname];
      const uid = pick(everyone);
      const at = daysAgo(d, Math.floor(between(6, 20)));
      const roll = rand();
      if (roll > 0.72) {
        const symbol = gname.includes('Crypto') ? pick(['BTCUSD', 'ETHUSD', 'SOLUSD'])
          : gname.includes('Gold') ? pick(['XAUUSD', 'EURUSD', 'GBPUSD'])
            : gname.includes('Nifty') ? pick(['NIFTY50', 'BANKNIFTY'])
              : pick(['XAUUSD', 'BTCUSD', 'NAS100', 'EURUSD']);
        const tf = pick(['15m', '1h', '4h']);
        const payload = mkAnalysis(symbol, tf);
        msgInsert.run(`g:${gid}`, 'group', uid, `${symbol} ${tf} — ${payload.bias} bias, levels marked on the chart.`, 'analysis', JSON.stringify(payload), symbol, '[]', at);
      } else if (roll > 0.62 && tradeIds.length) {
        const t = pick(tradeIds.slice(-40));
        const trade = q.one('SELECT * FROM trades WHERE id = ?', t.id);
        msgInsert.run(`g:${gid}`, 'group', t.uid, `${trade.side.toUpperCase()} ${trade.symbol} ${trade.pnl >= 0 ? '+' : ''}$${trade.pnl.toFixed(0)} — ${trade.pnl >= 0 ? 'plan followed' : 'cut it early'}.`,
          'trade', JSON.stringify({ trade, message: '' }), trade.symbol, '[]', at);
      } else {
        msgInsert.run(`g:${gid}`, 'group', uid, pick(CHAT), 'text', '{}', null, '[]', at);
      }
    }
  }

  // a live conversation in Arjun Floor + DMs
  msgInsert.run('g:' + groupIds['Arjun Floor'], 'group', mentor,
    'New week, same rule: two A+ setups or nothing. Post your levels here before the London open.',
    'text', '{}', null, '[]', daysAgo(0, 5));
  msgInsert.run('g:' + groupIds['Arjun Floor'], 'group', trader,
    'XAUUSD 1H — sweep of the Asia low then reclaim. Long bias while we hold above VWAP.',
    'analysis', JSON.stringify(mkAnalysis('XAUUSD', '1h')), 'XAUUSD', '[]', daysAgo(0, 6));
  msgInsert.run('g:' + groupIds['Gold & FX Desk'], 'group', arjun,
    'EURUSD rejected VWAP three times, shorting the retest with a stop above the rejection high.',
    'analysis', JSON.stringify(mkAnalysis('EURUSD', '15m')), 'EURUSD', '[]', daysAgo(0, 7));
  msgInsert.run('g:' + groupIds['Crypto 24/7'], 'group', riya,
    'BTC 4H range breakout with volume — waiting for the retest of the shelf before adding.',
    'analysis', JSON.stringify(mkAnalysis('BTCUSD', '4h')), 'BTCUSD', '[]', daysAgo(0, 8));

  // ── attachments: a chart snapshot and a level sheet, shared like a real desk
  fileMsg('g:' + groupIds['Arjun Floor'], trader, 'XAUUSD', [chartFile],
    'Marked the 4H gold chart before the open — sweep of the Asia low, reclaim, then the level sheet below.', daysAgo(0, 6));
  fileMsg('g:' + groupIds['Arjun Floor'], trader, null, [sheetFile],
    'Level sheet for today: entry, stop, target and R for each setup. Copy it into your own ticket.', daysAgo(0, 6));
  fileMsg('g:' + groupIds['Gold & FX Desk'], mentor, 'XAUUSD', [chartFile, sheetFile],
    'Chart plus the levels I am working from. Watch the 4,124 stop level — it is the line in the sand.', daysAgo(1, 9));
  fileMsg('g:' + groupIds['Crypto 24/7'], riya, 'BTCUSD', [chartFile],
    'BTC 4H structure for reference — same sweep pattern, different instrument.', daysAgo(2, 14));

  const dmPairs = [[trader, mentor], [trader, riya], [arjun, mentor], [riya, arjun]];
  dmPairs.forEach(([a, b], i) => {
    const room = `dm:${Math.min(a, b)}:${Math.max(a, b)}`;
    msgInsert.run(room, 'dm', a, pick(['Hey, can you look at my EURUSD entry from today?', 'Thanks for the journal review — the sizing note helped.', 'Do you still like gold here or is it too extended?']), 'text', '{}', null, '[]', daysAgo(i, 11));
    msgInsert.run(room, 'dm', b, pick(['Looks fine, but your stop is inside the noise. Move it behind the wick.', 'Yes — extended, wait for the pullback into EMA20.', 'Post it in the Floor room so everyone can see the level.']), 'text', '{}', null, '[]', daysAgo(i, 12));
    if (i === 0) fileMsg(room, b, 'XAUUSD', [chartFile], 'Here is the chart I promised — the stop belongs behind that wick.', daysAgo(i, 12));
  });

  /* ----------------------------------------------- watchlist + extras */
  ['XAUUSD', 'EURUSD', 'BTCUSD', 'NAS100', 'NIFTY50', 'BANKNIFTY', 'USOIL'].forEach((s, i) =>
    q.run('INSERT OR IGNORE INTO watchlist (user_id, symbol, sort) VALUES (?,?,?)', trader, s, i));
  ['BTCUSD', 'ETHUSD', 'SOLUSD', 'XAUUSD'].forEach((s, i) =>
    q.run('INSERT OR IGNORE INTO watchlist (user_id, symbol, sort) VALUES (?,?,?)', riya, s, i));

  q.run('INSERT INTO alerts (user_id, symbol, condition, price, note) VALUES (?,?,?,?,?)', trader, 'XAUUSD', 'above', round(priceOf('XAUUSD') * 1.01, 2), 'Range high break, watch for continuation');
  q.run('INSERT INTO alerts (user_id, symbol, condition, price, note) VALUES (?,?,?,?,?)', trader, 'BTCUSD', 'below', round(priceOf('BTCUSD') * 0.97, 2), 'Range low — invalidates the breakout idea');

  q.run('INSERT INTO notifications (user_id, kind, title, body) VALUES (?,?,?,?)', trader, 'info', 'Welcome to your vault, Arjun', 'Seeded with 45 days of trades, journal entries and room history. Password: arjun123');
  q.run('INSERT INTO notifications (user_id, kind, title, body) VALUES (?,?,?,?)', userIds.trader, 'info', 'Welcome to Arjun', 'Demo vault seeded with 45 days of trades, journal entries and room history.');
  q.run('INSERT INTO notifications (user_id, kind, title, body) VALUES (?,?,?,?)', trader, 'message', 'Meera Nair posted in Arjun Floor', 'New week, same rule: two A+ setups or nothing.');

  // mark every seeded message as read for its recipients so unread counts start clean
  q.all(`SELECT room, MAX(id) AS lastId FROM messages GROUP BY room`).forEach((r) => {
    q.all('SELECT id FROM users').forEach((u) => {
      q.run(`INSERT OR IGNORE INTO room_reads (user_id, room, last_read_id) VALUES (?,?,?)`, u.id, r.room, r.lastId);
    });
  });

  const counts = {
    users: q.one('SELECT COUNT(*) c FROM users').c,
    attachments: q.one("SELECT COUNT(*) c FROM messages WHERE attachments != '[]'").c,
    trades: q.one('SELECT COUNT(*) c FROM trades').c,
    open: q.one("SELECT COUNT(*) c FROM trades WHERE status='open'").c,
    journal: q.one('SELECT COUNT(*) c FROM journal_entries').c,
    groups: q.one('SELECT COUNT(*) c FROM groups').c,
    messages: q.one('SELECT COUNT(*) c FROM messages').c,
    analyses: q.one("SELECT COUNT(*) c FROM messages WHERE kind='analysis'").c,
  };
  console.log('[seed] done →', counts);
  return counts;
}

if (require.main === module) {
  runSeed({ force: process.argv.includes('--force') })
    .then(() => { engine.stop(); process.exit(0); })
    .catch((e) => { console.error(e); process.exit(1); });
}

module.exports = { runSeed };
