'use strict';
/**
 * Market data engine.
 *
 *  • Crypto ......... OKX public REST (candles + tickers)
 *  • FX / Metals / Indices / Stocks ... Yahoo Finance chart API
 *  • Every symbol also has an offline synthetic fallback so the terminal keeps
 *    working with zero internet (clearly flagged as source:"sim").
 *
 * Also computes indicators, market sessions and news headlines.
 */
const EventEmitter = require('events');
const CONFIG = require('./config');
const { SYMBOLS, SYMBOL_MAP, TIMEFRAMES } = CONFIG;

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36';

/* Free, key-less public fallbacks (see public-apis list):
   crypto  → Kraken OHLC/Ticker
   metals  → gold-api.com
   FX spot → open.er-api.com                                  */
const KRAKEN_PAIR = {
  BTCUSD: 'XBTUSD', ETHUSD: 'ETHUSD', SOLUSD: 'SOLUSD', XRPUSD: 'XRPUSD',
  BNBUSD: 'BNBUSD', DOGEUSD: 'XDGUSD', ADAUSD: 'ADAUSD',
};
const KRAKEN_INTERVAL = { '1m': 1, '5m': 5, '15m': 15, '30m': 30, '1h': 60, '4h': 240, '1d': 1440, '1w': 10080 };
const ER_API_PAIRS = {   // symbol → how to derive it from a USD-based rate table
  EURUSD: (r) => 1 / r.EUR, GBPUSD: (r) => 1 / r.GBP, AUDUSD: (r) => 1 / r.AUD,
  USDJPY: (r) => r.JPY, USDINR: (r) => r.INR, USDCAD: (r) => r.CAD, USDCHF: (r) => r.CHF,
};

const OKX_BAR = { '1m': '1m', '5m': '5m', '15m': '15m', '30m': '30m', '1h': '1H', '4h': '4H', '1d': '1D', '1w': '1W' };
const YF_TF = { '1m': { i: '1m', r: '5d' }, '5m': { i: '5m', r: '1mo' }, '15m': { i: '15m', r: '1mo' }, '30m': { i: '30m', r: '1mo' }, '1h': { i: '60m', r: '3mo' }, '1d': { i: '1d', r: '5y' }, '1w': { i: '1wk', r: '5y' } };

const FOREX_HOLIDAY_BASES = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'NZD', 'CAD', 'CHF'];

/* ------------------------------------------------------------------ utils */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const round = (v, d) => (v == null ? v : Math.round(v * 10 ** d) / 10 ** d);
const digitsOf = (sym) => (SYMBOL_MAP[sym]?.digits ?? 2);
const nowSec = () => Math.floor(Date.now() / 1000);

function hash(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return (h >>> 0);
}
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ---------------------------------------------------------------- engine */
class MarketEngine extends EventEmitter {
  constructor() {
    super();
    this.quotes = new Map();      // symbol -> quote
    this.candles = new Map();     // `${symbol}|${tf}` -> { candles, at, source }
    this.news = new Map();        // symbol -> { at, items }
    this.status = { ok: 0, fail: 0, lastError: null, lastSync: null, online: true, backoff: {} };
    this.backoff = { yahoo: 0, okx: 0 };     // provider → epoch ms until we may retry
    this.cursor = 0;                          // rotation cursor for the quote loop
    this.timer = null;
  }

  meta(symbol) {
    const m = SYMBOL_MAP[symbol];
    if (!m) return null;
    return { symbol: m.symbol, name: m.name, class: m.klass, currency: m.currency, digits: m.digits, tick: m.tick };
  }

  listSymbols() {
    return SYMBOLS.map((s) => {
      const qt = this.quotes.get(s.symbol);
      return {
        ...this.meta(s.symbol),
        price: qt?.price ?? s.base,
        change: qt?.change ?? 0,
        changePct: qt?.changePct ?? 0,
        high24h: qt?.high24h ?? null,
        low24h: qt?.low24h ?? null,
        source: qt?.source ?? 'seed',
        ts: qt?.ts ?? null,
      };
    });
  }

  getQuote(symbol) {
    const s = SYMBOL_MAP[symbol];
    if (!s) return null;
    return this.quotes.get(symbol) || {
      symbol, price: s.base, change: 0, changePct: 0, prevClose: s.base,
      high24h: s.base, low24h: s.base, ts: nowSec(), source: 'seed',
    };
  }

  /* ------------------------------------------------------------ network */
  async getJson(url, timeout = 9000) {
    const ctl = new AbortController();
    const t = setTimeout(() => ctl.abort(), timeout);
    try {
      const res = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'application/json,text/plain,*/*' }, signal: ctl.signal });
      if (res.status === 429 || res.status === 418) throw new Error('rate limited (' + res.status + ')');
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return await res.json();
    } finally { clearTimeout(t); }
  }

  /* ---------------------------------------------------------- synthetic */
  synthCandles(symbol, tf, count = 500) {
    const s = SYMBOL_MAP[symbol];
    const tfMs = TIMEFRAMES[tf]?.ms || 3600e3;
    const rand = mulberry32(hash(symbol + tf));
    const vol = (s.vol || 1) * Math.sqrt(tfMs / 3600e3);
    const now = Math.floor(Date.now() / tfMs) * tfMs;
    let price = s.base * (0.94 + rand() * 0.1);
    const out = [];
    for (let i = count - 1; i >= 0; i--) {
      const ts = now - i * tfMs;
      const drift = (rand() - 0.5) * vol * 2;
      const o = price;
      const c = Math.max(o * 0.5, o + drift);
      const h = Math.max(o, c) + rand() * vol * 0.6;
      const l = Math.min(o, c) - rand() * vol * 0.6;
      const v = Math.round(1000 + rand() * 9000);
      out.push({ time: Math.floor(ts / 1000), open: round(o, s.digits + 1), high: round(h, s.digits + 1), low: round(l, s.digits + 1), close: round(c, s.digits + 1), volume: v });
      price = c;
    }
    return out;
  }

  aggregate(candles, factor) {
    const out = [];
    let bucket = null;
    for (const c of candles) {
      const key = Math.floor(c.time / (TIMEFRAMES['1h'].ms / 1000) / factor);
      if (!bucket || bucket.key !== key) {
        if (bucket) out.push(bucket.bar);
        bucket = { key, bar: { time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume || 0 } };
      } else {
        bucket.bar.high = Math.max(bucket.bar.high, c.high);
        bucket.bar.low = Math.min(bucket.bar.low, c.low);
        bucket.bar.close = c.close;
        bucket.bar.volume += c.volume || 0;
      }
    }
    if (bucket) out.push(bucket.bar);
    return out;
  }

  /* ---------------------------------------------------------- providers */
  async fetchOKX(symbol, tf, limit = 300) {
    const s = SYMBOL_MAP[symbol];
    const bar = OKX_BAR[tf] || '1H';
    const url = `https://www.okx.com/api/v5/market/candles?instId=${s.providerSymbol}&bar=${bar}&limit=${Math.min(limit, 300)}`;
    const j = await this.getJson(url);
    if (j.code !== '0' || !Array.isArray(j.data)) throw new Error('okx ' + (j.msg || 'bad payload'));
    return j.data
      .map((r) => ({ time: Math.floor(Number(r[0]) / 1000), open: +r[1], high: +r[2], low: +r[3], close: +r[4], volume: +r[5] }))
      .sort((a, b) => a.time - b.time);
  }

  async fetchYahoo(symbol, tf, limit = 400) {
    const s = SYMBOL_MAP[symbol];
    const conf = YF_TF[tf];
    if (!conf) throw new Error('yahoo: timeframe not supported');
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(s.providerSymbol)}?interval=${conf.i}&range=${conf.r}&includePrePost=false`;
    const j = await this.getJson(url);
    const r = j?.chart?.result?.[0];
    if (!r) throw new Error('yahoo: empty result');
    const ts = r.timestamp || [];
    const qd = r.indicators?.quote?.[0] || {};
    const out = [];
    for (let i = 0; i < ts.length; i++) {
      const o = qd.open?.[i], h = qd.high?.[i], l = qd.low?.[i], c = qd.close?.[i];
      if (o == null || h == null || l == null || c == null) continue;
      out.push({ time: ts[i], open: +o, high: +h, low: +l, close: +c, volume: +(qd.volume?.[i] || 0) });
    }
    if (!out.length) throw new Error('yahoo: no candles');
    out.meta = { price: r.meta?.regularMarketPrice, prevClose: r.meta?.chartPreviousClose || r.meta?.previousClose, currency: r.meta?.currency, name: r.meta?.longName || r.meta?.shortName };
    return out.slice(-limit);
  }

  /** Kraken public OHLC — fallback when OKX is blocked (e.g. by country/IP). */
  async fetchKraken(symbol, tf) {
    const pair = KRAKEN_PAIR[symbol];
    if (!pair) throw new Error('kraken: no pair');
    const interval = KRAKEN_INTERVAL[tf] || 60;
    const j = await this.getJson(`https://api.kraken.com/0/public/OHLC?pair=${pair}&interval=${interval}`);
    if (j.error?.length) throw new Error('kraken: ' + j.error[0]);
    const key = Object.keys(j.result || {}).find((k) => k !== 'last');
    const rows = j.result?.[key];
    if (!rows?.length) throw new Error('kraken: no candles');
    return rows.map((r) => ({ time: Number(r[0]), open: +r[1], high: +r[2], low: +r[3], close: +r[4], volume: +r[6] }))
      .sort((a, b) => a.time - b.time);
  }

  async fetchKrakenQuote(symbol) {
    const pair = KRAKEN_PAIR[symbol];
    if (!pair) throw new Error('kraken: no pair');
    const j = await this.getJson(`https://api.kraken.com/0/public/Ticker?pair=${pair}`);
    const key = Object.keys(j.result || {})[0];
    const t = j.result?.[key];
    if (!t) throw new Error('kraken: empty ticker');
    const price = +t.c[0];
    return { price, prevClose: +t.o, high24h: +t.h[1], low24h: +t.l[1] };
  }

  /** gold-api.com — free spot for XAU/XAG, no key. */
  async fetchMetalQuote(symbol) {
    const code = { XAUUSD: 'XAU', XAGUSD: 'XAG' }[symbol];
    if (!code) throw new Error('metals: unsupported');
    const j = await this.getJson(`https://api.gold-api.com/price/${code}`);
    if (!j || !Number.isFinite(+j.price)) throw new Error('metals: bad payload');
    return { price: +j.price };
  }

  /** open.er-api.com — free FX rate table, no key. Spot only (not intraday). */
  async fetchFxQuote(symbol) {
    const derive = ER_API_PAIRS[symbol];
    if (!derive) throw new Error('fx: unsupported');
    if (!this._fxTable || Date.now() - this._fxTable.at > 30 * 60e3) {
      const j = await this.getJson('https://open.er-api.com/v6/latest/USD');
      if (j.result !== 'success' || !j.rates) throw new Error('fx: bad payload');
      this._fxTable = { at: Date.now(), rates: j.rates };
    }
    const price = derive(this._fxTable.rates);
    if (!Number.isFinite(price)) throw new Error('fx: bad rate');
    return { price };
  }

  /** Second-source quote used only when the primary provider fails. */
  async fetchFallbackQuote(symbol) {
    const meta = SYMBOL_MAP[symbol] || {};
    if (meta.provider === 'okx') return this.fetchKrakenQuote(symbol);
    if (symbol === 'XAUUSD' || symbol === 'XAGUSD') return this.fetchMetalQuote(symbol);
    if (ER_API_PAIRS[symbol]) return this.fetchFxQuote(symbol);
    throw new Error('no fallback provider');
  }

  async fetchYahooQuote(symbol) {
    const s = SYMBOL_MAP[symbol];
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(s.providerSymbol)}?interval=5m&range=1d`;
    const j = await this.getJson(url);
    const r = j?.chart?.result?.[0];
    if (!r) throw new Error('yahoo quote: empty');
    const m = r.meta || {};
    const qd = r.indicators?.quote?.[0] || {};
    const closes = (qd.close || []).filter((v) => v != null);
    const highs = (qd.high || []).filter((v) => v != null);
    const lows = (qd.low || []).filter((v) => v != null);
    const price = m.regularMarketPrice ?? closes[closes.length - 1];
    const prevClose = m.chartPreviousClose ?? m.previousClose ?? closes[0];
    return {
      price, prevClose,
      high24h: highs.length ? Math.max(...highs) : price,
      low24h: lows.length ? Math.min(...lows) : price,
      name: m.longName || m.shortName || s.name,
    };
  }

  async fetchOKXQuote(symbol) {
    const s = SYMBOL_MAP[symbol];
    const j = await this.getJson(`https://www.okx.com/api/v5/market/ticker?instId=${s.providerSymbol}`);
    const d = j?.data?.[0];
    if (!d) throw new Error('okx quote: empty');
    return { price: +d.last, prevClose: +d.open24h, high24h: +d.high24h, low24h: +d.low24h };
  }

  noteBackoff(provider, ms = 60e3) {
    const until = Date.now() + ms;
    this.backoff[provider] = Math.max(this.backoff[provider] || 0, until);
    this.status.backoff[provider] = new Date(until).toISOString().slice(11, 19);
    if (provider === 'yahoo') this.status.online = true;
  }
  inBackoff(provider) { return (this.backoff[provider] || 0) > Date.now(); }

  /* --------------------------------------------------------- public API */
  async getCandles(symbol, tf, { force = false } = {}) {
    tf = String(tf || '1h').toLowerCase();
    const s = SYMBOL_MAP[symbol];
    if (!s) throw new Error('unknown symbol ' + symbol);
    const conf = TIMEFRAMES[tf];
    if (!conf) throw new Error('unknown timeframe ' + tf);
    const key = `${symbol}|${tf}`;
    const hit = this.candles.get(key);
    if (!force && hit && Date.now() - hit.at < conf.ttl) return { ...hit, cached: true };

    let candles = null, source = 'live';
    if (this.inBackoff(s.provider) && hit && hit.candles && hit.candles.length > 10) {
      return { ...hit, at: Date.now(), cached: true, stale: true, source: hit.source === 'live' ? 'cached' : hit.source };
    }
    try {
      if (s.provider === 'okx') {
        try {
          if (!conf.aggregate) candles = await this.fetchOKX(symbol, tf);
          else candles = this.aggregate(await this.fetchOKX(symbol, '1h', 300), conf.aggregate);
        } catch (primaryErr) {
          // OKX blocked (region/IP) → Kraken carries the crypto book
          this.status.lastError = `okx ${symbol}: ${primaryErr.message} → kraken`;
          if (!conf.aggregate) candles = await this.fetchKraken(symbol, tf);
          else candles = this.aggregate(await this.fetchKraken(symbol, '1h'), conf.aggregate);
          source = 'fallback';
        }
      } else if (!conf.aggregate) candles = await this.fetchYahoo(symbol, tf);
      else candles = this.aggregate(await this.fetchYahoo(symbol, '1h', 400), conf.aggregate);
      this.status.ok++; this.status.lastSync = new Date().toISOString(); this.status.online = true;
    } catch (err) {
      this.status.fail++; this.status.lastError = `${symbol} ${tf}: ${err.message}`;
      if (err.message.includes('rate limited')) this.noteBackoff(s.provider);
      if (err.message.includes('fetch failed') || err.message.includes('aborted') || err.message.includes('ENOTFOUND')) this.status.online = false;
      if (hit && hit.candles && hit.candles.length > 10) {          // stale beats fake
        return { ...hit, at: Date.now(), cached: true, stale: true, source: hit.source === 'live' ? 'cached' : hit.source };
      }
      candles = this.synthCandles(symbol, tf);
      source = 'sim';
    }
    if (!candles || !candles.length) { candles = this.synthCandles(symbol, tf); source = 'sim'; }

    const rec = { candles, at: Date.now(), source, symbol, tf };
    this.candles.set(key, rec);
    return rec;
  }

  /** Merge live quote into the newest candle so charts animate in real time. */
  applyLiveToCandles(symbol, tf, price) {
    const rec = this.candles.get(`${symbol}|${tf}`);
    if (!rec || !rec.candles.length) return null;
    const ms = TIMEFRAMES[tf].ms;
    const bucket = Math.floor(Date.now() / ms) * Math.floor(ms / 1000);
    const last = rec.candles[rec.candles.length - 1];
    if (bucket <= last.time) {
      last.close = price; last.high = Math.max(last.high, price); last.low = Math.min(last.low, price);
    } else {
      rec.candles.push({ time: bucket, open: price, high: price, low: price, close: price, volume: 0 });
      if (rec.candles.length > 1200) rec.candles.shift();
    }
    return last;
  }

  /** One rotation of the quote loop: crypto every tick, the rest in batches. */
  nextBatch(size = 9) {
    const crypto = SYMBOLS.filter((s) => s.provider === 'okx');
    const others = SYMBOLS.filter((s) => s.provider !== 'okx');
    const out = [...crypto];
    for (let i = 0; i < Math.min(size, others.length); i++) out.push(others[(this.cursor + i) % others.length]);
    this.cursor = (this.cursor + size) % others.length;
    return out;
  }

  async refreshQuotes(symbols = null) {
    const list = symbols ? symbols.map((x) => SYMBOL_MAP[x]).filter(Boolean) : this.nextBatch();
    let updated = 0;
    for (const s of list) {
      if (this.inBackoff(s.provider)) { this.walkQuote(s); continue; }
      let usedFallback = false;
      try {
        let raw;
        try {
          raw = s.provider === 'okx' ? await this.fetchOKXQuote(s.symbol) : await this.fetchYahooQuote(s.symbol);
        } catch (primaryErr) {
          this.status.lastError = `${s.symbol}: ${primaryErr.message} → fallback`;
          raw = await this.fetchFallbackQuote(s.symbol);
          usedFallback = true;
        }
        const price = raw.price;
        if (!Number.isFinite(price)) throw new Error('bad price');
        const prevClose = Number.isFinite(raw.prevClose) ? raw.prevClose : price;
        const change = price - prevClose;
        const prev = this.quotes.get(s.symbol);
        const quote = {
          symbol: s.symbol, price: round(price, s.digits), prevClose: round(prevClose, s.digits),
          change: round(change, s.digits), changePct: prevClose ? round((change / prevClose) * 100, 3) : 0,
          high24h: round(raw.high24h ?? prev?.high24h ?? price, s.digits),
          low24h: round(raw.low24h ?? prev?.low24h ?? price, s.digits),
          digits: s.digits, ts: nowSec(), source: usedFallback ? 'fallback' : 'live', tick: s.tick,
        };
        this.quotes.set(s.symbol, quote);
        this.status.ok++;
        updated++;
      } catch (err) {
        this.status.fail++;
        this.status.lastError = `${s.symbol}: ${err.message}`;
        if (err.message.includes('rate limited')) this.noteBackoff(s.provider);
        if (err.message.includes('fetch failed') || err.message.includes('aborted') || err.message.includes('ENOTFOUND')) this.status.online = false;
        this.walkQuote(s);
      }
      await sleep(150); // be polite to public endpoints
    }
    return updated;
  }

  /** Offline / rate-limited: derive a realistic walk from the last known price. */
  walkQuote(s) {
    const prev = this.quotes.get(s.symbol) || { symbol: s.symbol, price: s.base, prevClose: s.base, high24h: s.base, low24h: s.base, digits: s.digits };
    const r = mulberry32(hash(s.symbol + Math.floor(Date.now() / 5000)));
    const step = (r() - 0.5) * (s.vol || 1) * 0.55 * (prev.source === 'sim' ? 1 : 0.4);
    const price = round(Math.max(0.00001, prev.price + step), s.digits);
    const prevClose = prev.prevClose || s.base;
    this.quotes.set(s.symbol, {
      ...prev, symbol: s.symbol, price, change: round(price - prevClose, s.digits),
      changePct: round(((price - prevClose) / prevClose) * 100, 3),
      high24h: round(Math.max(prev.high24h || price, price), s.digits),
      low24h: round(Math.min(prev.low24h || price, price), s.digits),
      digits: s.digits, ts: nowSec(), source: prev.source === 'live' ? 'live' : 'sim',
    });
  }

  /* ------------------------------------------------------------- news */
  async fetchNews(symbol) {
    const s = SYMBOL_MAP[symbol] || { providerSymbol: 'BTC-USD' };
    const key = symbol || 'market';
    const hit = this.news.get(key);
    if (hit && Date.now() - hit.at < 10 * 60e3) return hit.items;
    const ticker = s.provider === 'okx' ? (s.providerSymbol || 'BTC-USD').replace('-', '-') : (s.providerSymbol || 'SPY');
    const url = `https://feeds.finance.yahoo.com/rss/2.0/headline?s=${encodeURIComponent(ticker)}&region=US&lang=en-US`;
    let items = [];
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 9000);
      const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: ctl.signal });
      clearTimeout(t);
      const xml = await res.text();
      const blocks = xml.split('<item>').slice(1, 16);
      items = blocks.map((b) => {
        const pick = (tag) => {
          const m = b.match(new RegExp(`<${tag}>([\\s\\S]*?)</${tag}>`));
          return m ? m[1].replace(/<!\[CDATA\[|\]\]>/g, '').trim() : '';
        };
        return { title: pick('title'), link: pick('link'), pubDate: pick('pubDate'), source: pick('source') };
      }).filter((x) => x.title);
    } catch (e) {
      items = [
        { title: 'Live news feed unavailable offline — headlines resume when the server can reach the internet.', link: '', pubDate: new Date().toUTCString(), source: 'system' },
      ];
    }
    this.news.set(key, { at: Date.now(), items });
    return items;
  }

  /* --------------------------------------------------------- sessions */
  marketStatus() {
    const now = new Date();
    const utcH = now.getUTCHours() + now.getUTCMinutes() / 60;
    const day = now.getUTCDay(); // 0 Sun
    const sessions = [
      { name: 'Sydney', open: 21, close: 6, color: '#5AA2F0' },
      { name: 'Tokyo', open: 0, close: 9, color: '#8B7BF0' },
      { name: 'London', open: 7, close: 16, color: '#C9A94C' },
      { name: 'New York', open: 12.5, close: 21, color: '#4CAF7D' },
    ].map((s) => {
      const overnight = s.close < s.open;
      const inSession = overnight ? (utcH >= s.open || utcH < s.close) : (utcH >= s.open && utcH < s.close);
      return { ...s, open: inSession, closed: !inSession };
    });
    const goldOpen = !(day === 6 || (day === 5 && utcH >= 21));
    return { utc: now.toISOString(), sessions, goldOpen, weekend: day === 6 || day === 0 };
  }

  /** Indicative weekly economic calendar (pattern based, sample feed). */
  economicCalendar() {
    const out = [];
    const now = new Date();
    const start = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate()));
    const add = (dayOffset, hourUTC, impact, country, title) => {
      const d = new Date(start.getTime() + dayOffset * 86400e3 + hourUTC * 3600e3);
      out.push({ time: d.toISOString(), impact, country, title, source: 'indicative' });
    };
    for (let i = 0; i < 7; i++) {
      const d = new Date(start.getTime() + i * 86400e3);
      const dow = d.getUTCDay();
      if (dow === 1) add(i, 14, 'medium', 'US', 'ISM Manufacturing PMI');
      if (dow === 2) add(i, 9, 'medium', 'EU', 'Eurozone Flash CPI (sample)');
      if (dow === 3) add(i, 14.5, 'high', 'US', 'EIA Crude Oil Inventories');
      if (dow === 4) add(i, 12, 'high', 'EU', 'ECB Rate Decision');
      if (dow === 4) add(i, 12.5, 'high', 'US', 'Initial Jobless Claims');
      if (dow === 5) {
        const week = Math.ceil(d.getUTCDate() / 7);
        if (week === 1) add(i, 12.5, 'high', 'US', 'US Non-Farm Payrolls (NFP)');
        add(i, 14, 'medium', 'US', 'University of Michigan Sentiment');
      }
      add(i, 13.5, 'low', 'IN', 'India: RBI / bond market notes (indicative)');
    }
    return out.sort((a, b) => a.time.localeCompare(b.time));
  }

  /* -------------------------------------------------------- indicators */
  ema(values, period) {
    const k = 2 / (period + 1);
    const out = []; let prev = null;
    values.forEach((v, i) => {
      prev = i === 0 ? v : v * k + prev * (1 - k);
      out.push(prev);
    });
    return out;
  }
  sma(values, period) {
    const out = [];
    let sum = 0;
    values.forEach((v, i) => {
      sum += v;
      if (i >= period) sum -= values[i - period];
      out.push(i >= period - 1 ? sum / period : null);
    });
    return out;
  }
  rsi(values, period = 14) {
    const out = new Array(values.length).fill(null);
    let gain = 0, loss = 0;
    for (let i = 1; i <= period && i < values.length; i++) {
      const d = values[i] - values[i - 1];
      if (d >= 0) gain += d; else loss -= d;
    }
    gain /= period; loss /= period;
    out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
    for (let i = period + 1; i < values.length; i++) {
      const d = values[i] - values[i - 1];
      gain = (gain * (period - 1) + Math.max(d, 0)) / period;
      loss = (loss * (period - 1) + Math.max(-d, 0)) / period;
      out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
    }
    return out;
  }
  macd(values, fast = 12, slow = 26, signal = 9) {
    const ef = this.ema(values, fast), es = this.ema(values, slow);
    const macdLine = values.map((_, i) => ef[i] - es[i]);
    const sig = this.ema(macdLine, signal);
    return { macd: macdLine, signal: sig, hist: macdLine.map((v, i) => v - sig[i]) };
  }
  atr(candles, period = 14) {
    const tr = candles.map((c, i) => {
      if (i === 0) return c.high - c.low;
      const pc = candles[i - 1].close;
      return Math.max(c.high - c.low, Math.abs(c.high - pc), Math.abs(c.low - pc));
    });
    return this.sma(tr, period);
  }
  bollinger(values, period = 20, mult = 2) {
    const mid = this.sma(values, period);
    const up = [], dn = [];
    values.forEach((_, i) => {
      if (i < period - 1) { up.push(null); dn.push(null); return; }
      const slice = values.slice(i - period + 1, i + 1);
      const m = mid[i];
      const sd = Math.sqrt(slice.reduce((a, v) => a + (v - m) ** 2, 0) / period);
      up.push(m + mult * sd); dn.push(m - mult * sd);
    });
    return { mid, upper: up, lower: dn };
  }
  vwap(candles) {
    let pv = 0, vv = 0;
    const out = [];
    let day = null;
    candles.forEach((c) => {
      const d = new Date(c.time * 1000).getUTCDate();
      if (d !== day) { day = d; pv = 0; vv = 0; }
      const tp = (c.high + c.low + c.close) / 3;
      pv += tp * (c.volume || 1); vv += (c.volume || 1);
      out.push(pv / vv);
    });
    return out;
  }
  pivots(prevBar) {
    const { high: h, low: l, close: c } = prevBar;
    const p = (h + l + c) / 3;
    return {
      P: p, R1: 2 * p - l, S1: 2 * p - h,
      R2: p + (h - l), S2: p - (h - l),
      R3: h + 2 * (p - l), S3: l - 2 * (h - p),
    };
  }

  /** Full indicator pack for a symbol (used by the AI analysis + indicators API). */
  async indicatorPack(symbol, tf = '1h') {
    tf = String(tf).toLowerCase();
    const { candles } = await this.getCandles(symbol, tf);
    const closes = candles.map((c) => c.close);
    const d = digitsOf(symbol);
    const ema20 = this.ema(closes, 20), ema50 = this.ema(closes, 50), ema200 = this.ema(closes, 200);
    const rsi = this.rsi(closes, 14);
    const macd = this.macd(closes);
    const atr = this.atr(candles, 14);
    const bb = this.bollinger(closes, 20, 2);
    const vwap = this.vwap(candles);
    const i = closes.length - 1;
    const swingHigh = Math.max(...candles.slice(-120).map((c) => c.high));
    const swingLow = Math.min(...candles.slice(-120).map((c) => c.low));
    const dayBar = { high: Math.max(...candles.slice(-24).map((c) => c.high)), low: Math.min(...candles.slice(-24).map((c) => c.low)), close: closes[i] };
    const trend = ema20[i] > ema50[i] && ema50[i] > ema200[i] ? 'uptrend'
      : ema20[i] < ema50[i] && ema50[i] < ema200[i] ? 'downtrend' : 'range';
    return {
      symbol, tf, price: round(closes[i], d),
      ema: { ema20: round(ema20[i], d), ema50: round(ema50[i], d), ema200: round(ema200[i], d) },
      rsi14: round(rsi[i], 2),
      macd: { macd: round(macd.macd[i], d + 1), signal: round(macd.signal[i], d + 1), hist: round(macd.hist[i], d + 1) },
      atr14: round(atr[i] ?? 0, d),
      bollinger: { upper: round(bb.upper[i], d), mid: round(bb.mid[i], d), lower: round(bb.lower[i], d) },
      vwap: round(vwap[i], d),
      pivots: Object.fromEntries(Object.entries(this.pivots(dayBar)).map(([k, v]) => [k, round(v, d)])),
      swingHigh: round(swingHigh, d), swingLow: round(swingLow, d),
      trend,
      ts: Date.now(),
    };
  }

  /* --------------------------------------------------------------- loop */
  start() {
    const tick = async () => {
      try {
        const n = await this.refreshQuotes();
        this.emit('quotes', this.listSymbols());
        // animate the cached last candle for every open chart
        for (const [key] of this.candles) {
          const [sym, tf] = key.split('|');
          const q = this.quotes.get(sym);
          if (q) this.applyLiveToCandles(sym, tf, q.price);
        }
        this.emit('tick', { updated: n, status: this.status });
      } catch (e) {
        this.status.lastError = e.message;
      }
    };
    tick();
    this.timer = setInterval(tick, CONFIG.TICK_MS);
    if (this.timer.unref) this.timer.unref();
  }
  stop() { if (this.timer) clearInterval(this.timer); }
}

module.exports = new MarketEngine();
