'use strict';
/**
 * Mailer — real SMTP when configured, otherwise a developer-friendly outbox.
 *
 *   SMTP_HOST / SMTP_PORT / SMTP_USER / SMTP_PASS / MAIL_FROM
 *
 * Without SMTP everything still works: the message is written to the console AND
 * to the `emails` table, and the API returns the action link in development so
 * verification / password reset can be tested end to end.
 */
const CONFIG = require('./config');
const { q } = require('./db');

let transport = null;
if (CONFIG.SMTP.host) {
  try {
    const nodemailer = require('nodemailer');
    transport = nodemailer.createTransport({
      host: CONFIG.SMTP.host,
      port: CONFIG.SMTP.port,
      secure: CONFIG.SMTP.secure,
      auth: CONFIG.SMTP.user ? { user: CONFIG.SMTP.user, pass: CONFIG.SMTP.pass } : undefined,
    });
  } catch (e) {
    console.error('[mail] nodemailer unavailable:', e.message);
  }
}

const from = CONFIG.SMTP.from || `${CONFIG.APP_NAME} <no-reply@${(() => { try { return new URL(CONFIG.PUBLIC_URL).hostname; } catch { return 'localhost'; } })()}>`;
const isLive = () => !!transport;

/** Shared HTML shell so every mail looks like it came from the same desk. */
function layout({ title, body, cta, ctaUrl, footer }) {
  return `<!doctype html><html><body style="margin:0;background:#0B0D12;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif">
  <div style="max-width:520px;margin:0 auto;padding:32px 22px;color:#ECE7D9">
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:22px">
      <div style="width:40px;height:40px;border-radius:11px;background:linear-gradient(145deg,#1b1f2a,#0c0e14);border:1px solid #8A7636;color:#C9A94C;font-weight:700;font-size:19px;line-height:40px;text-align:center">A</div>
      <div><div style="font-size:17px;font-weight:600;letter-spacing:.3px">${CONFIG.APP_NAME}</div>
      <div style="font-size:12px;color:#8C92A4">${CONFIG.APP_TAGLINE}</div></div>
    </div>
    <div style="background:#12151D;border:1px solid #232838;border-radius:14px;padding:22px">
      <h2 style="margin:0 0 10px;font-size:19px;font-weight:600">${title}</h2>
      <div style="font-size:14px;line-height:1.65;color:#C9CEDA">${body}</div>
      ${cta ? `<div style="margin:22px 0 6px"><a href="${ctaUrl}" style="display:inline-block;background:linear-gradient(180deg,#D6B657,#B7963C);color:#14161C;text-decoration:none;font-weight:600;padding:11px 20px;border-radius:9px">${cta}</a></div>
      <div style="font-size:12px;color:#8C92A4;word-break:break-all">or paste this link: ${ctaUrl}</div>` : ''}
      ${footer ? `<div style="margin-top:20px;font-size:12px;color:#8C92A4;line-height:1.6">${footer}</div>` : ''}
    </div>
    <div style="margin-top:16px;font-size:11.5px;color:#5F6678">You received this because someone used this address on ${CONFIG.APP_NAME}. If that wasn't you, ignore this email.</div>
  </div></body></html>`;
}

/**
 * Send (or queue) an email. Always resolves — a mail failure must never break
 * sign-up or password reset.
 */
async function send({ to, subject, html, text, kind = 'system', userId = null }) {
  const record = { to, subject, html, kind, userId };
  if (!transport) {
    console.log(`\n[mail:queued] to=${to} kind=${kind}\n  subject: ${subject}\n  (SMTP not configured — see the emails table or settings → email)\n`);
    try {
      q.run('INSERT INTO emails (user_id, to_addr, subject, body, kind, status) VALUES (?,?,?,?,?,?)',
        userId, to, subject, html || text || '', kind, 'queued');
    } catch (e) { /* ignore */ }
    return { queued: true };
  }
  try {
    await transport.sendMail({ from, to, subject, html, text: text || html?.replace(/<[^>]+>/g, ' ') });
    try {
      q.run('INSERT INTO emails (user_id, to_addr, subject, body, kind, status) VALUES (?,?,?,?,?,?)',
        userId, to, subject, html || text || '', kind, 'sent');
    } catch (e) { /* ignore */ }
    return { sent: true };
  } catch (e) {
    console.error('[mail] send failed:', e.message);
    try {
      q.run('INSERT INTO emails (user_id, to_addr, subject, body, kind, status, error) VALUES (?,?,?,?,?,?,?)',
        userId, to, subject, html || text || '', kind, 'failed', e.message);
    } catch (err) { /* ignore */ }
    return { error: e.message };
  }
}

const link = (path, token) => `${CONFIG.PUBLIC_URL}${path}?token=${encodeURIComponent(token)}`;

async function sendVerification(user, token) {
  const url = link('/verify-email', token);
  return send({
    to: user.email, userId: user.id, kind: 'verify',
    subject: `Confirm your ${CONFIG.APP_NAME} email`,
    html: layout({
      title: 'Confirm your email',
      body: `Hi ${user.display_name || user.username}, confirm this address to finish setting up your ${CONFIG.APP_NAME} vault. The link is valid for 24 hours.`,
      cta: 'Confirm email', ctaUrl: url,
      footer: 'Once confirmed you can sign in with either your username or this email address.',
    }),
  });
}

async function sendPasswordReset(user, token) {
  const url = link('/reset-password', token);
  return send({
    to: user.email, userId: user.id, kind: 'reset',
    subject: `Reset your ${CONFIG.APP_NAME} password`,
    html: layout({
      title: 'Reset your password',
      body: `Hi ${user.display_name || user.username}, use the button below to choose a new password. The link expires in 60 minutes and can only be used once.`,
      cta: 'Choose a new password', ctaUrl: url,
      footer: 'If you did not request this, you can safely ignore it — your password stays unchanged.',
    }),
  });
}

async function sendWelcome(user) {
  return send({
    to: user.email, userId: user.id, kind: 'welcome',
    subject: `Welcome to ${CONFIG.APP_NAME}, ${user.display_name || user.username}`,
    html: layout({
      title: 'Your vault is ready',
      body: `You can now chart 33 markets, share analyses into rooms, and journal every session. Open the terminal to place your first paper trade.`,
      cta: `Open ${CONFIG.APP_NAME}`, ctaUrl: CONFIG.PUBLIC_URL,
    }),
  });
}

module.exports = { send, sendVerification, sendPasswordReset, sendWelcome, isLive, layout };
