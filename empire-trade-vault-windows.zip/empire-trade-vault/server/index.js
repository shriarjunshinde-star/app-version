'use strict';
require('./dep_path').ensurePath();   // resolve deps from ./deps or ./node_modules
/**
 * Arjun — API + realtime server.
 *
 *  REST      /api/auth        register / login / profile
 *  REST      /api/market      symbols, quotes, candles, indicators, news, calendar, alerts
 *  REST      /api/trades      accounts, order engine, stats, playbooks, risk
 *  REST      /api/journal     daily trading journal
 *  REST      /api/social      groups, messages, sharing analyses + trade cards, DMs
 *  REST      /api/misc        watchlist, notifications, search, technical analysis
 *  Socket.IO quotes, alerts, messages, reactions, typing, presence
 */
const path = require('path');
const http = require('http');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const { Server } = require('socket.io');

const CONFIG = require('./config');
const { q } = require('./db');
const engine = require('./marketdata');
const rt = require('./realtime');
const { verify } = require('./auth');
const { computePnl } = require('./pnl');

const app = express();
app.disable('x-powered-by');
if (CONFIG.TRUST_PROXY) app.set('trust proxy', 1);      // correct client IPs behind a proxy

app.use(helmet({
  contentSecurityPolicy: false,                          // the terminal loads its own charts + socket.io
  crossOriginEmbedderPolicy: false,
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  /* The app is meant to be embedded (chat preview panels, desk dashboards),
     so no X-Frame-Options / frame-ancestors lock-down. Flip CONFIG.ALLOW_IFRAME
     to false to harden a single-origin deployment. */
  frameguard: CONFIG.ALLOW_IFRAME === false ? { action: 'sameorigin' } : false,
}));
app.use(compression());
app.use(express.json({ limit: '8mb' }));                // chart snapshots travel in JSON
app.use(express.urlencoded({ extended: true, limit: '1mb' }));

// ── CORS: allow-list when configured, otherwise reflect the caller ─────────
app.use((req, res, next) => {
  const origin = req.headers.origin;
  const allowed = !CONFIG.ALLOWED_ORIGINS.length || (origin && CONFIG.ALLOWED_ORIGINS.includes(origin));
  if (origin && allowed) {
    res.header('Access-Control-Allow-Origin', origin);
    res.header('Vary', 'Origin');
    res.header('Access-Control-Allow-Credentials', 'true');
  } else if (!origin) {
    res.header('Access-Control-Allow-Origin', '*');
  }
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

// ── global API limiter (generous; auth routes have their own tighter one) ──
app.use('/api', rateLimit({
  windowMs: 60 * 1000,
  max: Number(process.env.RATE_LIMIT_PER_MIN || 600),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests — slow down a moment.' },
}));

// uploaded files (images render, documents download)
app.use('/uploads', require('./upload').staticServer);
app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'], maxAge: CONFIG.IS_PROD ? '1h' : 0 }));

/* public routes first */
app.use('/api/auth', require('./routes/auth'));
app.use('/api/market', require('./routes/market'));
app.use('/api', require('./upload').router);          // POST /api/upload

app.get('/api/health', (req, res) => res.json({
  ok: true,
  app: CONFIG.APP_NAME, owner: CONFIG.OWNER, env: CONFIG.ENV, version: require('../package.json').version,
  uptime: Math.round(process.uptime()),
  startedAt: new Date(Date.now() - process.uptime() * 1000).toISOString(),
  engine: engine.status,
  mail: { configured: require('./mailer').isLive() },
  counts: {
    users: q.one('SELECT COUNT(*) c FROM users').c,
    trades: q.one('SELECT COUNT(*) c FROM trades').c,
    messages: q.one('SELECT COUNT(*) c FROM messages').c,
    attachments: q.one("SELECT COUNT(*) c FROM messages WHERE attachments != '[]'").c,
  },
  users: q.one('SELECT COUNT(*) c FROM users').c,
  trades: q.one('SELECT COUNT(*) c FROM trades').c,
  messages: q.one('SELECT COUNT(*) c FROM messages').c,
  online: rt.onlineUsers().length,
}));

/* everything below requires a token (each router enforces it) */
app.use('/api', require('./routes/trades'));     // /api/trades, /api/accounts, /api/playbooks, /api/risk
app.use('/api/journal', require('./routes/journal'));
app.use('/api/social', require('./routes/social'));
app.use('/api', require('./routes/misc'));       // /api/watchlist, /api/notifications, /api/search, /api/analysis

// SPA fallback (never for API routes)
app.get(/^(?!\/api|\/uploads|\/socket\.io).*/, (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.use((err, req, res, next) => {
  if (err?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: `File too large — the limit is ${CONFIG.MAX_UPLOAD_MB} MB` });
  console.error('[api error]', err.message);
  res.status(err.status || 500).json({ error: err.message });
});

/* --------------------------------------------------------------- server */
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: true },
  maxHttpBufferSize: 8e6,
});
rt.setIO(io);

io.use((socket, next) => {
  const payload = verify(socket.handshake.auth?.token || socket.handshake.query?.token || '');
  if (!payload) return next(new Error('unauthorised'));
  socket.data.userId = payload.id;
  next();
});

io.on('connection', (socket) => {
  const userId = socket.data.userId;
  const user = q.one('SELECT id, username, display_name, avatar_color FROM users WHERE id = ?', userId);
  if (!user) return socket.disconnect(true);
  socket.data.user = user;
  rt.track(userId, socket.id);

  // auto-join every group room the user belongs to
  q.all('SELECT group_id FROM group_members WHERE user_id = ?', userId)
    .forEach((r) => socket.join('g:' + r.group_id));
  socket.join('user:' + userId);
  io.emit('presence', { userId, online: true, user });

  socket.on('room:open', ({ room }) => {
    if (!room) return;
    if (room.startsWith('g:')) {
      const gid = Number(room.slice(2));
      if (q.one('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?', gid, userId)) socket.join(room);
    } else if (room.startsWith('dm:')) {
      if (room.split(':').slice(1).map(Number).includes(userId)) socket.join(room);
    }
  });

  socket.on('chat:send', (msg, ack) => {
    try {
      const room = String(msg?.room || '');
      const allowed = room.startsWith('g:')
        ? !!q.one('SELECT 1 FROM group_members WHERE group_id = ? AND user_id = ?', Number(room.slice(2)), userId)
        : room.startsWith('dm:') && room.split(':').slice(1).map(Number).includes(userId);
      if (!allowed) return ack?.({ error: 'not in room' });
      const info = q.run('INSERT INTO messages (room, room_type, user_id, body) VALUES (?,?,?,?)',
        room, room.startsWith('dm:') ? 'dm' : 'group', userId, String(msg.body || '').slice(0, 4000));
      const full = q.one(`SELECT m.*, u.display_name, u.username, u.avatar_color FROM messages m JOIN users u ON u.id = m.user_id WHERE m.id = ?`, info.lastInsertRowid);
      const out = { ...full, payload: {}, reactions: [] };
      io.to(room).emit('message', out);
      if (room.startsWith('dm:')) room.split(':').slice(1).map(Number).filter((x) => x !== userId).forEach((uid) => rt.emitToUser(uid, 'dm:new', out));
      ack?.({ ok: true, message: out });
    } catch (e) { ack?.({ error: e.message }); }
  });

  socket.on('typing', ({ room, typing }) => socket.to(room).emit('typing', { room, userId, name: user.display_name, typing: !!typing }));
  socket.on('chart:sub', ({ symbol, tf }) => {
    socket.data.chart = { symbol, tf };
  });

  socket.on('disconnect', () => {
    rt.untrack(userId, socket.id);
    if (!rt.isOnline(userId)) io.emit('presence', { userId, online: false });
  });
});

engine.on('tick', ({ status }) => {
  io.emit('market:tick', { quotes: engine.listSymbols(), status, sessions: engine.marketStatus(), ts: Date.now() });
  checkAlerts();
  checkPendingOrders();
});

/* ------------------------------------------------- alert + order monitor */
function checkAlerts() {
  const active = q.all("SELECT * FROM alerts WHERE status = 'active'");
  active.forEach((a) => {
    const price = engine.getQuote(a.symbol)?.price;
    if (!price) return;
    const hit = a.condition === 'above' ? price >= a.price : price <= a.price;
    if (!hit) return;
    q.run("UPDATE alerts SET status='triggered', triggered_at=datetime('now') WHERE id = ?", a.id);
    const payload = { id: a.id, symbol: a.symbol, condition: a.condition, price: a.price, last: price, note: a.note, ts: Date.now() };
    q.run('INSERT INTO notifications (user_id, kind, title, body) VALUES (?,?,?,?)',
      a.user_id, 'alert', `${a.symbol} ${a.condition} ${a.price}`, `Last price ${price}${a.note ? ' — ' + a.note : ''}`);
    rt.emitToUser(a.user_id, 'alert:triggered', payload);
  });
}

function checkPendingOrders() {
  const pending = q.all("SELECT * FROM trades WHERE status = 'pending'");
  pending.forEach((t) => {
    const price = engine.getQuote(t.symbol)?.price;
    if (!price) return;
    const hit = t.side === 'buy' ? price <= t.entry_price : price >= t.entry_price;
    if (!hit) return;
    q.run("UPDATE trades SET status='open', opened_at=datetime('now') WHERE id = ?", t.id);
    const payload = { tradeId: t.id, symbol: t.symbol, side: t.side, entry: t.entry_price, last: price };
    q.run('INSERT INTO notifications (user_id, kind, title, body) VALUES (?,?,?,?)',
      t.user_id, 'order', `${t.symbol} limit filled`, `${t.side.toUpperCase()} ${t.qty} @ ${t.entry_price}`);
    rt.emitToUser(t.user_id, 'order:filled', payload);
  });
}

/* Floating P&L push for open trades (so the dashboard breathes). */
setInterval(() => {
  const rows = q.all("SELECT t.*, u.id AS uid FROM trades t JOIN users u ON u.id = t.user_id WHERE t.status = 'open'");
  const perUser = {};
  rows.forEach((t) => {
    const price = engine.getQuote(t.symbol)?.price;
    if (!price) return;
    const { pnl } = computePnl(t.symbol, t.side, t.entry_price, price, t.qty);
    perUser[t.uid] = perUser[t.uid] || [];
    perUser[t.uid].push({ tradeId: t.id, symbol: t.symbol, side: t.side, entry: t.entry_price, current: price, floating: pnl });
  });
  Object.entries(perUser).forEach(([uid, positions]) => rt.emitToUser(Number(uid), 'positions:update', positions));
}, 5000);

/* ------------------------------------------------------------------ boot */
engine.start();

fs.mkdirSync(CONFIG.UPLOAD_DIR, { recursive: true });
fs.mkdirSync(CONFIG.DATA_DIR, { recursive: true });

/* first boot on a fresh volume (docker / render / fly) seeds the demo desk */
async function boot() {
  const userCount = q.one('SELECT COUNT(*) c FROM users').c;
  const halfBuilt = userCount > 0 && q.one('SELECT COUNT(*) c FROM trades').c === 0;
  if ((userCount === 0 || halfBuilt) && process.env.SEED_ON_EMPTY !== 'false') {
    console.log(`  ${userCount ? 'incomplete' : 'empty'} database — building the demo desk (fetches live prices, ~30-60s)…`);
    try { await require('./seed').runSeed({ force: halfBuilt }); }
    catch (e) { console.warn('  ⚠ seeding skipped:', e.message); }
  }

  CONFIG.problems().forEach((msg) => console.warn('  ⚠ ' + msg));

  server.listen(CONFIG.PORT, CONFIG.HOST, () => {
  console.log(`\n  ${CONFIG.APP_NAME.toUpperCase()}  ·  ${CONFIG.OWNER}  →  ${CONFIG.PUBLIC_URL}`);
    console.log(`  env ${CONFIG.ENV}  ·  API /api/health  ·  ${CONFIG.SYMBOLS.length} markets  ·  realtime: socket.io`);
    console.log(`  storage: ${CONFIG.DB_PATH}`);
    console.log(`  uploads: ${CONFIG.UPLOAD_DIR} (max ${CONFIG.MAX_UPLOAD_MB} MB${CONFIG.ALLOWED_ORIGINS.length ? '' : ', all origins allowed'})`);
    console.log(`  mail:    ${require('./mailer').isLive() ? 'SMTP configured' : 'console outbox (set SMTP_HOST to send real email)'}`);
    console.log(`  sign in: ${q.one("SELECT username FROM users WHERE is_admin = 1")?.username || 'owner'} (owner)  ·  any registered email/username\n`);
  });
}

boot().catch((e) => { console.error('[boot] fatal:', e); process.exit(1); });

/* ── graceful shutdown so containers stop cleanly (SIGTERM from k8s/docker) */
let closing = false;
function shutdown(signal) {
  if (closing) return;
  closing = true;
  console.log(`\n[${signal}] shutting down…`);
  try { engine.stop(); } catch {}
  io.close();
  server.close(() => {
    try { require('./db').db.close(); } catch {}
    console.log('[shutdown] done');
    process.exit(0);
  });
  setTimeout(() => process.exit(0), 8000).unref();
}
['SIGTERM', 'SIGINT'].forEach((sig) => process.on(sig, () => shutdown(sig)));
process.on('unhandledRejection', (err) => console.error('[unhandledRejection]', err?.message || err));
process.on('uncaughtException', (err) => { console.error('[uncaughtException]', err?.message || err); });

module.exports = { app, server, io };
