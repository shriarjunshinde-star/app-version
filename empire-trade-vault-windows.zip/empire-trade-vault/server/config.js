'use strict';
/**
 * Empire Trade Vault — server configuration
 * Symbol universe + timeframe definitions used by the market-data engine.
 */

const TIMEFRAMES = {
  '1m':  { label: '1m',  ms: 60e3,          provider: '1m',  range: '7d',  ttl: 20e3,  sim: 60e3 },
  '5m':  { label: '5m',  ms: 300e3,         provider: '5m',  range: '1mo', ttl: 45e3,  sim: 300e3 },
  '15m': { label: '15m', ms: 900e3,         provider: '15m', range: '1mo', ttl: 60e3,  sim: 900e3 },
  '30m': { label: '30m', ms: 1800e3,        provider: '30m', range: '1mo', ttl: 90e3,  sim: 1800e3 },
  '1h':  { label: '1H',  ms: 3600e3,        provider: '60m', range: '3mo', ttl: 180e3, sim: 3600e3 },
  '4h':  { label: '4H',  ms: 4 * 3600e3,    provider: '60m', range: '1y',  ttl: 300e3, sim: 4 * 3600e3, aggregate: 4 },
  '1d':  { label: '1D',  ms: 86400e3,       provider: '1d',  range: '5y',  ttl: 900e3, sim: 86400e3 },
  '1w':  { label: '1W',  ms: 7 * 86400e3,   provider: '1wk', range: '5y',  ttl: 3600e3, sim: 7 * 86400e3 },
};

// provider: 'okx' (crypto, best quality) | 'yahoo' (everything) | 'sim' (offline fallback)
const SYMBOLS = [
  // ---- FX majors & crosses -------------------------------------------------
  { symbol: 'EURUSD', name: 'Euro / US Dollar',            klass: 'forex', currency: 'USD', digits: 5, tick: 0.00001, provider: 'yahoo', providerSymbol: 'EURUSD=X',  base: 1.1257,  vol: 0.0006, lotSize: 100000 },
  { symbol: 'GBPUSD', name: 'British Pound / US Dollar',   klass: 'forex', currency: 'USD', digits: 5, tick: 0.00001, provider: 'yahoo', providerSymbol: 'GBPUSD=X',  base: 1.3120,  vol: 0.0007, lotSize: 100000 },
  { symbol: 'USDJPY', name: 'US Dollar / Japanese Yen',    klass: 'forex', currency: 'JPY', digits: 3, tick: 0.001,   provider: 'yahoo', providerSymbol: 'USDJPY=X',  base: 152.40,  vol: 0.06,   lotSize: 100000 },
  { symbol: 'AUDUSD', name: 'Australian Dollar / US Dollar', klass: 'forex', currency: 'USD', digits: 5, tick: 0.00001, provider: 'yahoo', providerSymbol: 'AUDUSD=X',  base: 0.6580,  vol: 0.0005, lotSize: 100000 },
  { symbol: 'USDCAD', name: 'US Dollar / Canadian Dollar', klass: 'forex', currency: 'CAD', digits: 5, tick: 0.00001, provider: 'yahoo', providerSymbol: 'USDCAD=X',  base: 1.3900,  vol: 0.0006, lotSize: 100000 },
  { symbol: 'USDCHF', name: 'US Dollar / Swiss Franc',     klass: 'forex', currency: 'CHF', digits: 5, tick: 0.00001, provider: 'yahoo', providerSymbol: 'USDCHF=X',  base: 0.8850,  vol: 0.0005, lotSize: 100000 },
  { symbol: 'USDINR', name: 'US Dollar / Indian Rupee',    klass: 'forex', currency: 'INR', digits: 4, tick: 0.0001,  provider: 'yahoo', providerSymbol: 'USDINR=X',  base: 88.20,   vol: 0.03,   lotSize: 100000 },
  // ---- Metals & energy -----------------------------------------------------
  { symbol: 'XAUUSD', name: 'Gold Spot / US Dollar',       klass: 'metal', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'GC=F', base: 4160, vol: 6, lotSize: 100 },
  { symbol: 'XAGUSD', name: 'Silver Spot / US Dollar',     klass: 'metal', currency: 'USD', digits: 3, tick: 0.001, provider: 'yahoo', providerSymbol: 'SI=F', base: 51.20, vol: 0.12, lotSize: 5000 },
  { symbol: 'USOIL',  name: 'WTI Crude Oil',               klass: 'energy', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'CL=F', base: 62.40, vol: 0.25, lotSize: 1000 },
  { symbol: 'NATGAS', name: 'Natural Gas',                 klass: 'energy', currency: 'USD', digits: 3, tick: 0.001, provider: 'yahoo', providerSymbol: 'NG=F', base: 3.40, vol: 0.03, lotSize: 10000 },
  // ---- Indices -------------------------------------------------------------
  { symbol: 'SPX500', name: 'S&P 500 Index',               klass: 'index', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^GSPC', base: 6720, vol: 8, lotSize: 1 },
  { symbol: 'NAS100', name: 'Nasdaq 100 Index',            klass: 'index', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^NDX', base: 24800, vol: 45, lotSize: 1 },
  { symbol: 'US30',   name: 'Dow Jones 30',                klass: 'index', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^DJI', base: 46800, vol: 60, lotSize: 1 },
  { symbol: 'GER40',  name: 'DAX 40 Index',                klass: 'index', currency: 'EUR', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^GDAXI', base: 24300, vol: 40, lotSize: 1 },
  { symbol: 'UK100',  name: 'FTSE 100 Index',              klass: 'index', currency: 'GBP', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^FTSE', base: 9450, vol: 18, lotSize: 1 },
  { symbol: 'JP225',  name: 'Nikkei 225',                  klass: 'index', currency: 'JPY', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: '^N225', base: 44500, vol: 90, lotSize: 1 },
  { symbol: 'NIFTY50', name: 'Nifty 50 Index',             klass: 'index', currency: 'INR', digits: 2, tick: 0.05, provider: 'yahoo', providerSymbol: '^NSEI', base: 22420, vol: 30, lotSize: 1 },
  { symbol: 'BANKNIFTY', name: 'Nifty Bank Index',         klass: 'index', currency: 'INR', digits: 2, tick: 0.05, provider: 'yahoo', providerSymbol: '^NSEBANK', base: 48200, vol: 80, lotSize: 1 },
  // ---- Crypto --------------------------------------------------------------
  { symbol: 'BTCUSD', name: 'Bitcoin / US Dollar',   klass: 'crypto', currency: 'USD', digits: 2, tick: 0.5,   provider: 'okx', providerSymbol: 'BTC-USDT',  base: 85000, vol: 400,  lotSize: 1 },
  { symbol: 'ETHUSD', name: 'Ethereum / US Dollar',  klass: 'crypto', currency: 'USD', digits: 2, tick: 0.05,  provider: 'okx', providerSymbol: 'ETH-USDT',  base: 2950,  vol: 22,   lotSize: 1 },
  { symbol: 'SOLUSD', name: 'Solana / US Dollar',    klass: 'crypto', currency: 'USD', digits: 3, tick: 0.001, provider: 'okx', providerSymbol: 'SOL-USDT',  base: 152,   vol: 2.4,  lotSize: 1 },
  { symbol: 'XRPUSD', name: 'XRP / US Dollar',       klass: 'crypto', currency: 'USD', digits: 5, tick: 0.0001,provider: 'okx', providerSymbol: 'XRP-USDT',  base: 2.35,  vol: 0.02, lotSize: 1 },
  { symbol: 'BNBUSD', name: 'BNB / US Dollar',       klass: 'crypto', currency: 'USD', digits: 2, tick: 0.01,  provider: 'okx', providerSymbol: 'BNB-USDT',  base: 640,   vol: 6,    lotSize: 1 },
  { symbol: 'DOGEUSD', name: 'Dogecoin / US Dollar', klass: 'crypto', currency: 'USD', digits: 5, tick: 0.00001, provider: 'okx', providerSymbol: 'DOGE-USDT', base: 0.165, vol: 0.004, lotSize: 1 },
  { symbol: 'ADAUSD', name: 'Cardano / US Dollar',   klass: 'crypto', currency: 'USD', digits: 5, tick: 0.0001, provider: 'okx', providerSymbol: 'ADA-USDT',  base: 0.62,  vol: 0.012, lotSize: 1 },
  // ---- Stocks --------------------------------------------------------------
  { symbol: 'AAPL', name: 'Apple Inc.',        klass: 'stock', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'AAPL',  base: 258, vol: 1.6, lotSize: 1 },
  { symbol: 'MSFT', name: 'Microsoft Corp.',   klass: 'stock', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'MSFT',  base: 512, vol: 3.0, lotSize: 1 },
  { symbol: 'NVDA', name: 'NVIDIA Corp.',      klass: 'stock', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'NVDA',  base: 188, vol: 2.2, lotSize: 1 },
  { symbol: 'TSLA', name: 'Tesla Inc.',        klass: 'stock', currency: 'USD', digits: 2, tick: 0.01, provider: 'yahoo', providerSymbol: 'TSLA',  base: 435, vol: 6.5, lotSize: 1 },
  { symbol: 'RELIANCE', name: 'Reliance Industries', klass: 'stock', currency: 'INR', digits: 2, tick: 0.05, provider: 'yahoo', providerSymbol: 'RELIANCE.NS', base: 1167, vol: 9, lotSize: 1 },
  { symbol: 'TCS', name: 'Tata Consultancy Services', klass: 'stock', currency: 'INR', digits: 2, tick: 0.05, provider: 'yahoo', providerSymbol: 'TCS.NS', base: 3200, vol: 22, lotSize: 1 },
  { symbol: 'HDFCBANK', name: 'HDFC Bank',     klass: 'stock', currency: 'INR', digits: 2, tick: 0.05, provider: 'yahoo', providerSymbol: 'HDFCBANK.NS', base: 1950, vol: 14, lotSize: 1 },
];

const SYMBOL_MAP = Object.fromEntries(SYMBOLS.map((s) => [s.symbol, s]));

const EMOJIS = ['\u{1F525}', '\u{1F680}', '\u{1F44D}', '\u{1F440}', '\u{1F4C8}', '\u{1F4C9}', '\u2705', '\u2764\uFE0F'];

const path = require('path');
const ROOT = path.join(__dirname, '..');
const ENV = process.env.NODE_ENV || 'development';
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');

const CONFIG = {
  /* ---- identity ------------------------------------------------------- */
  APP_NAME: process.env.APP_NAME || 'Arjun',
  APP_TAGLINE: 'Trading terminal · chart-analysis messenger · journal',
  OWNER: process.env.OWNER_NAME || 'Arjun Shinde',
  ENV,
  IS_PROD: ENV === 'production',

  /* ---- server --------------------------------------------------------- */
  PORT: Number(process.env.PORT || 3000),
  HOST: process.env.HOST || '0.0.0.0',
  PUBLIC_URL: (process.env.PUBLIC_URL || '').replace(/\/$/, '') || `http://localhost:${process.env.PORT || 3000}`,
  ALLOWED_ORIGINS: (process.env.ALLOWED_ORIGINS || '').split(',').map((x) => x.trim()).filter(Boolean),
  ALLOW_IFRAME: (process.env.ALLOW_IFRAME || 'true') !== 'false',  // embeddable in the preview panel
  TRUST_PROXY: process.env.TRUST_PROXY !== 'false',

  /* ---- storage -------------------------------------------------------- */
  ROOT,
  DATA_DIR,
  DB_PATH: process.env.DB_PATH || path.join(DATA_DIR, 'arjun.db'),
  UPLOAD_DIR: process.env.UPLOAD_DIR || path.join(ROOT, 'uploads'),
  MAX_UPLOAD_MB: Number(process.env.MAX_UPLOAD_MB || 20),

  /* ---- auth ----------------------------------------------------------- */
  JWT_SECRET: process.env.JWT_SECRET || 'change-me-in-production-arjun-dev-secret',
  JWT_EXPIRES: process.env.JWT_EXPIRES || '30d',
  REQUIRE_EMAIL_VERIFICATION: process.env.REQUIRE_EMAIL_VERIFICATION === 'true',
  DEFAULT_SEED_PASSWORD: 'empire123',
  OWNER_SEED_PASSWORD: process.env.OWNER_PASSWORD || 'arjun123',

  /* ---- email: SMTP when configured, otherwise console + `emails` table - */
  SMTP: {
    host: process.env.SMTP_HOST || '',
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === 'true',
    user: process.env.SMTP_USER || '',
    pass: process.env.SMTP_PASS || '',
    from: process.env.MAIL_FROM || '',
  },

  /* ---- market data ---------------------------------------------------- */
  TICK_MS: Number(process.env.TICK_MS || 4000),

  SYMBOLS,
  SYMBOL_MAP,
  TIMEFRAMES,
  EMOJIS,
};

CONFIG.ATTACHMENTS = {
  image: ['.png', '.jpg', '.jpeg', '.gif', '.webp'],
  doc: ['.pdf', '.doc', '.docx', '.xls', '.xlsx', '.csv', '.txt', '.md', '.rtf', '.zip'],
  maxMb: CONFIG.MAX_UPLOAD_MB,
};

/** Production sanity checks — surfaced at boot. */
CONFIG.problems = () => {
  const out = [];
  if (CONFIG.IS_PROD && CONFIG.JWT_SECRET.includes('change-me')) out.push('JWT_SECRET must be a long random value in production');
  if (CONFIG.IS_PROD && !CONFIG.ALLOWED_ORIGINS.length) out.push('ALLOWED_ORIGINS should be set in production (comma separated)');
  if (CONFIG.IS_PROD && !CONFIG.SMTP.host) out.push('SMTP_HOST missing — verification / reset emails will only be logged to the console');
  return out;
};

module.exports = CONFIG;
