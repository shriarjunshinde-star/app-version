'use strict';
/**
 * Cross-platform launcher — used by `npm start` on Windows, macOS and Linux.
 *
 *   node server/boot.js            start the app
 *   node server/boot.js --reset    wipe the database, re-seed, then start
 *   node server/boot.js --seed     re-seed the existing database, then start
 *
 * If dependencies are missing it installs them once and vendors them into
 * ./deps/pkgs (a name that survives snapshotting, unlike node_modules), then boots.
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const depPath = require('./dep_path');

const root = path.join(__dirname, '..');
const args = process.argv.slice(2);
const isWin = process.platform === 'win32';
const log = (m) => console.log((isWin ? '> ' : '▸ ') + m);

function installDeps() {
  log('dependencies not found — installing (one time, ~1-2 min, needs Node 18+)…');
  execFileSync('npm', ['install', '--no-audit', '--no-fund'], { cwd: root, stdio: 'inherit', shell: isWin });
  // vendor the fresh install so later runs never have to install again
  try {
    const src = path.join(root, 'node_modules');
    const dest = path.join(root, 'deps', 'pkgs');
    if (fs.existsSync(src)) {
      fs.mkdirSync(path.join(root, 'deps'), { recursive: true });
      fs.rmSync(dest, { recursive: true, force: true });
      fs.renameSync(src, dest);
      log('dependencies vendored into deps/pkgs');
    }
  } catch (e) {
    log('could not vendor dependencies (' + e.message + ') — using node_modules in place');
  }
}

if (!depPath.ensurePath()) installDeps();
if (!depPath.ensurePath()) {
  console.error('\n✖ Dependencies are still missing. Run "npm install" in this folder, then try again.\n');
  process.exit(1);
}

// optional database reset / reseed before booting
if (args.includes('--reset')) {
  for (const f of ['empire.db', 'empire.db-shm', 'empire.db-wal']) {
    fs.rmSync(path.join(root, 'data', f), { force: true });
  }
  log('database wiped — a fresh demo vault will be seeded on boot');
}
if (args.includes('--reset') || args.includes('--seed')) {
  try { execFileSync(process.execPath, [path.join(root, 'server', 'seed.js'), '--force'], { cwd: root, stdio: 'inherit' }); }
  catch (e) { console.error('seed skipped:', e.message); }
}

require('./index.js');
