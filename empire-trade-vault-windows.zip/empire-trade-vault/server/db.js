'use strict';
/**
 * SQLite database layer: schema, migrations and small helpers.
 * Uses better-sqlite3 (synchronous, fast, single file).
 */
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');
const CONFIG = require('./config');

fs.mkdirSync(path.dirname(CONFIG.DB_PATH), { recursive: true });

const db = new Database(CONFIG.DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  username      TEXT UNIQUE NOT NULL,
  email         TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  display_name  TEXT NOT NULL,
  avatar_color  TEXT DEFAULT '#C9A94C',
  bio           TEXT DEFAULT '',
  country       TEXT DEFAULT '',
  created_at    TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS accounts (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id        INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name           TEXT NOT NULL,
  broker         TEXT DEFAULT 'Empire Paper',
  currency       TEXT DEFAULT 'USD',
  start_balance  REAL DEFAULT 100000,
  balance        REAL DEFAULT 100000,
  leverage       INTEGER DEFAULT 100,
  risk_per_trade REAL DEFAULT 1.0,
  max_daily_loss REAL DEFAULT 3.0,
  is_demo        INTEGER DEFAULT 1,
  created_at     TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS trades (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  account_id      INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  symbol          TEXT NOT NULL,
  side            TEXT NOT NULL CHECK (side IN ('buy','sell')),
  qty             REAL NOT NULL,
  entry_price     REAL NOT NULL,
  exit_price      REAL,
  stop_loss       REAL,
  take_profit     REAL,
  status          TEXT NOT NULL DEFAULT 'open',   -- pending | open | closed | cancelled
  order_type      TEXT DEFAULT 'market',
  opened_at       TEXT DEFAULT (datetime('now')),
  closed_at       TEXT,
  pnl             REAL DEFAULT 0,
  fees            REAL DEFAULT 0,
  r_multiple      REAL,
  risk_amount     REAL,
  close_reason    TEXT,
  playbook_id     INTEGER REFERENCES playbooks(id) ON DELETE SET NULL,
  setup_tag       TEXT,
  tags            TEXT DEFAULT '[]',
  emotion         TEXT,
  confidence      INTEGER,
  notes           TEXT,
  screenshot      TEXT,
  origin          TEXT DEFAULT 'manual',
  source_message  INTEGER,
  created_at      TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_trades_user ON trades(user_id, status);
CREATE INDEX IF NOT EXISTS idx_trades_symbol ON trades(user_id, symbol);

CREATE TABLE IF NOT EXISTS playbooks (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  description TEXT DEFAULT '',
  rules       TEXT DEFAULT '[]',
  color       TEXT DEFAULT '#C9A94C',
  created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS journal_entries (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day              TEXT NOT NULL,              -- YYYY-MM-DD
  session          TEXT DEFAULT 'London',
  bias             TEXT DEFAULT '',
  market_context   TEXT DEFAULT '',
  plan             TEXT DEFAULT '',
  mood             INTEGER DEFAULT 3,
  discipline       INTEGER DEFAULT 3,
  lessons          TEXT DEFAULT '',
  tomorrow         TEXT DEFAULT '',
  process_score    INTEGER,
  review_complete  INTEGER DEFAULT 0,
  net_outcome      REAL DEFAULT 0,
  created_at       TEXT DEFAULT (datetime('now')),
  updated_at       TEXT DEFAULT (datetime('now')),
  UNIQUE (user_id, day)
);

CREATE TABLE IF NOT EXISTS groups (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  slug        TEXT UNIQUE NOT NULL,
  name        TEXT NOT NULL,
  topic       TEXT DEFAULT '',
  icon        TEXT DEFAULT '#',
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  is_private  INTEGER DEFAULT 0,
  created_at  TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS group_members (
  group_id  INTEGER NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
  user_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role      TEXT DEFAULT 'member',
  joined_at TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (group_id, user_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  room       TEXT NOT NULL,                     -- 'g:<id>' | 'dm:<a>:<b>'
  room_type  TEXT NOT NULL DEFAULT 'group',
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body       TEXT DEFAULT '',
  kind       TEXT DEFAULT 'text',               -- text | analysis | trade | system
  payload    TEXT DEFAULT '{}',                 -- JSON (chart snapshot, trade card ...)
  symbol     TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room, id);

CREATE TABLE IF NOT EXISTS reactions (
  message_id INTEGER NOT NULL REFERENCES messages(id) ON DELETE CASCADE,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  emoji      TEXT NOT NULL,
  PRIMARY KEY (message_id, user_id, emoji)
);

CREATE TABLE IF NOT EXISTS watchlist (
  user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol   TEXT NOT NULL,
  sort     INTEGER DEFAULT 0,
  PRIMARY KEY (user_id, symbol)
);

CREATE TABLE IF NOT EXISTS alerts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  symbol       TEXT NOT NULL,
  condition    TEXT NOT NULL DEFAULT 'above',   -- above | below
  price        REAL NOT NULL,
  note         TEXT DEFAULT '',
  status       TEXT DEFAULT 'active',           -- active | triggered | cancelled
  created_at   TEXT DEFAULT (datetime('now')),
  triggered_at TEXT
);

CREATE TABLE IF NOT EXISTS notifications (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT DEFAULT 'info',
  title      TEXT DEFAULT '',
  body       TEXT DEFAULT '',
  read       INTEGER DEFAULT 0,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS candle_cache (
  symbol TEXT NOT NULL,
  tf     TEXT NOT NULL,
  ts     INTEGER NOT NULL,
  o REAL, h REAL, l REAL, c REAL, v REAL,
  PRIMARY KEY (symbol, tf, ts)
);
`);

/* ═══════════════════════════════════════════════════════════════════════════
   migrations — additive, idempotent, safe to run on every boot
   ═══════════════════════════════════════════════════════════════════════════ */
const columns = (table) => db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);

function addColumn(table, name, ddl) {
  if (!columns(table).includes(name)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${ddl}`);
    console.log(`[migrate] ${table}.${name} added`);
  }
}

db.exec(`
CREATE TABLE IF NOT EXISTS emails (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  to_addr    TEXT NOT NULL,
  subject    TEXT NOT NULL,
  body       TEXT,
  kind       TEXT,                       -- verify | reset | welcome | invite
  status     TEXT DEFAULT 'queued',      -- queued (no SMTP) | sent | failed
  error      TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS room_reads (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  room         TEXT NOT NULL,
  last_read_id INTEGER DEFAULT 0,
  updated_at   TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (user_id, room)
);

CREATE TABLE IF NOT EXISTS sessions (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_id   TEXT UNIQUE NOT NULL,
  user_agent TEXT,
  ip         TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  last_seen  TEXT DEFAULT (datetime('now'))
);
`);

// users: email-account fields
addColumn('users', 'email_verified', 'INTEGER DEFAULT 0');
addColumn('users', 'verify_token', 'TEXT');
addColumn('users', 'verify_expires', 'TEXT');
addColumn('users', 'reset_token', 'TEXT');
addColumn('users', 'reset_expires', 'TEXT');
addColumn('users', 'last_login', 'TEXT');
addColumn('users', 'is_admin', 'INTEGER DEFAULT 0');

// messages: attachments + soft delete
addColumn('messages', 'attachments', "TEXT DEFAULT '[]'");
addColumn('messages', 'deleted_at', 'TEXT');

// accounts/trades niceties used by the UI
addColumn('accounts', 'is_default', 'INTEGER DEFAULT 0');
db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_email ON users(email) WHERE email IS NOT NULL").run();

// the owner account is admin, everything else stays a normal user
db.prepare("UPDATE users SET is_admin = 1 WHERE username = 'arjunshinde'").run();

/* ------------------------------------------------------------------ helpers */
const q = {
  one: (sql, ...p) => db.prepare(sql).get(...p),
  all: (sql, ...p) => db.prepare(sql).all(...p),
  run: (sql, ...p) => db.prepare(sql).run(...p),
  exec: (sql) => db.exec(sql),
  prepare: (sql) => db.prepare(sql),
};

function makeAccount(userId, name = 'Vault Paper #1', startBalance = 100000) {
  const info = q.run(
    `INSERT INTO accounts (user_id, name, start_balance, balance) VALUES (?,?,?,?)`,
    userId, name, startBalance, startBalance
  );
  return info.lastInsertRowid;
}

function settings(userId) {
  const acc = q.one('SELECT * FROM accounts WHERE user_id = ? ORDER BY id LIMIT 1', userId);
  return { account: acc };
}

module.exports = { db, q, makeAccount, settings };
