'use strict';
/** Tiny indirection so routes can broadcast without importing socket.io directly. */
let io = null;
const connected = new Map(); // userId -> Set(socketId)

module.exports = {
  setIO(server) { io = server; },
  getIO() { return io; },
  track(userId, socketId) {
    if (!connected.has(userId)) connected.set(userId, new Set());
    connected.get(userId).add(socketId);
  },
  untrack(userId, socketId) {
    connected.get(userId)?.delete(socketId);
    if (connected.get(userId)?.size === 0) connected.delete(userId);
  },
  isOnline(userId) { return connected.has(Number(userId)); },
  onlineUsers() { return [...connected.keys()]; },
  room(roomKey) { return io ? io.to(roomKey) : null; },
  emitToRoom(roomKey, event, payload) { if (io) io.to(roomKey).emit(event, payload); },
  emitToUser(userId, event, payload) {
    const set = connected.get(Number(userId));
    if (io && set) set.forEach((sid) => io.to(sid).emit(event, payload));
  },
  emitAll(event, payload) { if (io) io.emit(event, payload); },
};
