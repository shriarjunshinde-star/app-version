"""Auth-hardening test: sign-in on a normal page, inside a sandboxed iframe
(how the workspace preview renders the app), with broken storage, with a stale
token, and with the API unreachable."""
import os, subprocess, sys

def ensure_browser():
    """Playwright's browser lives in ~/.cache, which sandboxes wipe — reinstall on demand."""
    cache = os.path.expanduser("~/.cache/ms-playwright")
    if not os.path.isdir(cache) or not any(d.startswith("chromium") for d in os.listdir(cache)):
        print("▸ installing headless chromium for the test run…", flush=True)
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)

ensure_browser()
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "playwright"], check=False)
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)
    from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
results = []

def check(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS  " if ok else "FAIL  ") + name + ("  — " + detail if detail else ""), flush=True)

def main():
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--no-sandbox"])

        # ── 1. one-click owner login on a normal page ──────────────────────
        ctx = b.new_context(viewport={"width": 1500, "height": 950})
        pg = ctx.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.on("console", lambda m: errs.append("console: " + m.text) if m.type == "error" else None)
        pg.goto(BASE, wait_until="networkidle")
        pg.wait_for_timeout(1500)
        status = pg.inner_text("#serverStatus")
        check("auth screen shows server status", "online" in status, status)
        pg.click("#btnOwnerLogin")
        pg.wait_for_selector(".app:not(.hidden)", timeout=15000)
        pg.wait_for_timeout(3000)
        who = pg.inner_text("#sideUser")
        check("one-click Arjun Shinde login", "Arjun Shinde" in who, who.replace("\n", " · "))
        kpis = pg.eval_on_selector_all(".kpi .k-val", "e=>e.map(x=>x.textContent)")
        check("dashboard loaded with data", len(kpis) >= 4, str(kpis))
        pg.screenshot(path="tests/auth-01-owner-login.png")
        ctx.close()

        # ── 2. wrong password → clear error ────────────────────────────────
        ctx = b.new_context(); pg = ctx.new_page()
        pg.goto(BASE, wait_until="networkidle"); pg.wait_for_timeout(800)
        pg.fill("#authForm input[name=username]", "arjunshinde")
        pg.fill("#authForm input[name=password]", "wrong-password")
        pg.click("#authSubmit")
        pg.wait_for_timeout(1500)
        msg = pg.inner_text("#authError")
        check("wrong password shows server error", "Invalid" in msg, msg)
        ctx.close()

        # ── 3. chip login (other traders) ──────────────────────────────────
        ctx = b.new_context(); pg = ctx.new_page()
        pg.goto(BASE, wait_until="networkidle"); pg.wait_for_timeout(800)
        pg.click(".chip[data-user='mentor']")
        pg.wait_for_selector(".app:not(.hidden)", timeout=15000); pg.wait_for_timeout(2000)
        check("mentor chip login", "Meera Nair" in pg.inner_text("#sideUser"), pg.inner_text("#sideUser").replace("\n", " · "))
        ctx.close()

        # ── 4. sandboxed iframe with storage BLOCKED (preview conditions) ──
        ctx = b.new_context()
        pg = ctx.new_page()
        errs2 = []
        pg.on("pageerror", lambda e: errs2.append(str(e)))
        frame_doc = f"""
          <!doctype html><html><body style="margin:0">
          <iframe id="f" src="{BASE}" sandbox="allow-scripts"
                  style="width:1440px;height:900px;border:0"></iframe>
          </body></html>"""
        pg.set_content(frame_doc)
        pg.wait_for_timeout(6000)
        frame = pg.frames[1]
        try:
            status = frame.inner_text("#serverStatus", timeout=8000)
        except Exception as e:
            status = "unreachable: " + str(e)[:80]
        check("sandboxed iframe: API reachable + status shown", "online" in status, status)
        try:
            frame.click("#btnOwnerLogin", timeout=8000)
            frame.wait_for_selector(".app:not(.hidden)", timeout=20000)
            ok = "Arjun Shinde" in frame.inner_text("#sideUser")
            check("sandboxed iframe: login works with storage blocked", ok, frame.inner_text("#sideUser").replace("\n", " · ") if ok else "still on auth screen")
            pg.screenshot(path="tests/auth-02-iframe-login.png")
        except Exception as e:
            check("sandboxed iframe: login works with storage blocked", False, str(e)[:120])
        check("sandboxed iframe: no JS errors", not errs2, "; ".join(errs2[:3]))
        ctx.close()

        # ── 5. stale token in storage → clean fallback to sign-in ──────────
        ctx = b.new_context(); pg = ctx.new_page()
        pg.goto(BASE, wait_until="domcontentloaded")
        pg.evaluate("localStorage.setItem('etv_token','garbage.token.value')")
        pg.reload(wait_until="networkidle"); pg.wait_for_timeout(2500)
        visible = pg.is_visible("#authScreen")
        msg = pg.inner_text("#authError")
        check("stale token → sign-in screen with explanation", visible and ("expired" in msg.lower() or msg == ""), msg or "(no error text)")
        pg.click("#btnOwnerLogin"); pg.wait_for_selector(".app:not(.hidden)", timeout=15000)
        check("recovery after stale token", "Arjun Shinde" in pg.inner_text("#sideUser"))
        ctx.close()

        # ── 6. API unreachable → helpful message, no crash ─────────────────
        ctx = b.new_context(); pg = ctx.new_page()
        pg.route("**/api/**", lambda r: r.abort())
        pg.goto(BASE, wait_until="domcontentloaded"); pg.wait_for_timeout(2500)
        s = pg.inner_text("#serverStatus")
        e = pg.inner_text("#authError")
        check("offline API → 'server offline' hint", "offline" in s.lower(), s + " | " + e)
        pg.fill("#authForm input[name=username]", "arjunshinde")
        pg.fill("#authForm input[name=password]", "arjun123")
        pg.click("#authSubmit"); pg.wait_for_timeout(1200)
        e2 = pg.inner_text("#authError")
        check("offline API → friendly error on submit", "cannot reach" in e2.lower(), e2)
        pg.screenshot(path="tests/auth-03-offline.png")
        ctx.close()

        b.close()

    bad = [r for r in results if not r[1]]
    print(f"\n{len(results) - len(bad)}/{len(results)} checks passed")
    return 1 if bad else 0

if __name__ == "__main__":
    sys.exit(main())
