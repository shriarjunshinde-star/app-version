"""Headless smoke test: boots the app in a real browser, logs in, walks every
view, exercises the order ticket / share flow and reports console errors."""
import os, subprocess, sys, time, json

def ensure_browser():
    cache = os.path.expanduser("~/.cache/ms-playwright")
    if not os.path.isdir(cache) or not any(d.startswith("chromium") for d in os.listdir(cache)):
        print("▸ installing headless chromium…", flush=True)
        subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)

ensure_browser()
try:
    from playwright.sync_api import sync_playwright
except ImportError:
    subprocess.run([sys.executable, "-m", "pip", "install", "-q", "playwright"], check=False)
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=False)
    from playwright.sync_api import sync_playwright

BASE = "http://localhost:3000"
VIEWS = ["dashboard", "terminal", "trades", "journal", "analyze", "messenger",
         "rooms", "playbooks", "risk", "watchlist", "alerts", "news", "settings", "api"]

def main():
    errors, failed = [], []
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--no-sandbox"])
        ctx = b.new_context(viewport={"width": 1560, "height": 950})
        page = ctx.new_page()
        page.on("console", lambda m: errors.append(f"[console.{m.type}] {m.text}") if m.type in ("error",) else None)
        page.on("pageerror", lambda e: errors.append(f"[pageerror] {e}"))
        page.on("requestfailed", lambda r: failed.append(f"{r.url} :: {r.failure}"))
        page.on("response", lambda r: print("HTTP", r.status, r.request.method, r.url, flush=True) if r.status >= 400 else None)

        page.goto(BASE, wait_until="networkidle")
        page.wait_for_timeout(1200)
        page.screenshot(path="tests/01-login.png")

        # one-click sign-in as the owner
        page.click("#btnOwnerLogin")
        page.wait_for_selector(".app:not(.hidden)", timeout=20000)
        page.wait_for_timeout(2500)
        page.screenshot(path="tests/02-dashboard.png", full_page=False)
        print("dashboards kpis:", page.eval_on_selector_all(".kpi .k-val", "els => els.map(e=>e.textContent)"))

        for v in VIEWS:
            page.evaluate(f"ETV.go('{v}')")
            page.wait_for_timeout(2200 if v in ("terminal", "messenger", "analyze", "journal") else 1300)
            page.screenshot(path=f"tests/view-{v}.png")
            body = page.inner_text("#viewHost")[:200].replace("\n", " | ")
            print(f"--- {v}: {body[:150]}")

        # chart interactions: change timeframe, toggle indicator, run analysis
        page.evaluate("ETV.go('terminal')")
        page.wait_for_timeout(2500)
        page.click(".tf-row .tf:nth-child(5)")
        page.wait_for_timeout(1500)
        page.click("text=Ask desk for analysis")
        page.wait_for_timeout(2500)
        print("analysis pill:", page.inner_text("#biasPill"))
        page.screenshot(path="tests/03-terminal-analysis.png")

        # place an order through the ticket
        page.fill("#riskOut ~ div input, .ticket-side input", "0.1")
        page.evaluate("""() => { const s=[...document.querySelectorAll('.ticket-side input')];
            s[1].value = (ETV.quote(ETV.state.chart.symbol).price*0.97).toFixed(2);
            s[1].dispatchEvent(new Event('input')); }""")
        page.click(".btn-buy")
        page.wait_for_timeout(1800)
        print("toasts:", page.eval_on_selector_all(".toast .tt", "e=>e.map(x=>x.textContent)"))

        # share the chart into the first room
        page.click("text=Share chart to room")
        page.wait_for_timeout(1500)
        page.screenshot(path="tests/04-share-roompicker.png")
        page.click(".modal .pres")
        page.wait_for_timeout(2000)
        print("share toast:", page.eval_on_selector_all(".toast .tt", "e=>e.map(x=>x.textContent)"))

        # messenger: verify a shared analysis card renders a canvas
        page.evaluate("ETV.go('messenger')")
        page.wait_for_timeout(2600)
        cards = page.eval_on_selector_all(".msg-card", "e=>e.length")
        canvases = page.eval_on_selector_all(".mini-chart canvas", "e=>e.length")
        print("msg cards:", cards, "mini chart canvases:", canvases)
        page.screenshot(path="tests/05-messenger.png")

        # send a chat message
        page.fill(".composer textarea", "Automated smoke test: levels marked on the 1H, watching the retest.")
        page.click(".composer .btn-gold")
        page.wait_for_timeout(1600)

        # journal: type an entry and save
        page.evaluate("ETV.go('journal')")
        page.wait_for_timeout(1800)
        page.fill("textarea >> nth=2", "Smoke test context: London sweep, reclaim in progress.")
        page.click("text=Save entry")
        page.wait_for_timeout(1800)
        page.screenshot(path="tests/06-journal.png")
        print("journal kpis:", page.eval_on_selector_all(".kpi .k-val", "e=>e.map(x=>x.textContent)"))

        # palette
        page.keyboard.press("Control+k")
        page.wait_for_timeout(700)
        page.keyboard.type("gold")
        page.wait_for_timeout(900)
        page.screenshot(path="tests/07-palette.png")
        page.keyboard.press("Escape")

        # responsive check
        page.set_viewport_size({"width": 900, "height": 900})
        page.evaluate("ETV.go('terminal')")
        page.wait_for_timeout(2200)
        page.screenshot(path="tests/08-narrow.png")

        b.close()

    print("\n===== CONSOLE ERRORS =====")
    for e in dict.fromkeys(errors):
        print(" •", e)
    print("===== FAILED REQUESTS =====")
    for f in dict.fromkeys(failed):
        print(" •", f)
    print(f"\nTotals: {len(set(errors))} console/page errors, {len(set(failed))} failed requests")
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(main())
