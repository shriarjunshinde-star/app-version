#!/usr/bin/env python3
"""
Arjun — messenger attachments + email auth, driven through the real browser UI.

Run:  python3 tests/attachments_test.py         (server must be on :3000)
      BASE=http://127.0.0.1:3000 python3 tests/attachments_test.py
"""
import os
import re
import subprocess
import sys
import time
import urllib.request

BASE = os.environ.get("BASE", "http://127.0.0.1:3000")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SHOT = os.path.join(ROOT, "tests")

results = []


def check(name, ok, detail=""):
    results.append((name, bool(ok), detail))
    print(("  PASS  " if ok else "  FAIL  ") + name + (f"   ({detail})" if detail else ""))


def ensure_browser():
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        try:
            b = p.chromium.launch()
            b.close()
            return
        except Exception:
            pass
    print("  · chromium missing, installing (one time, ~1 min)…")
    subprocess.run([sys.executable, "-m", "playwright", "install", "chromium"], check=True)


def api(path, method="GET", body=None, token=None):
    import json

    req = urllib.request.Request(BASE + path, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    data = json.dumps(body).encode() if body is not None else None
    with urllib.request.urlopen(req, data, timeout=25) as r:
        return json.loads(r.read() or b"{}")


def main():
    ensure_browser()
    from playwright.sync_api import sync_playwright

    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)

        # ── sign in as the owner ────────────────────────────────────────────
        page.goto(BASE, wait_until="domcontentloaded")
        page.wait_for_selector("#btnOwnerLogin", timeout=15000)
        check("brand shows Arjun on the sign-in card", "Arjun" in page.inner_text(".auth-card h1"),
              page.inner_text(".auth-card h1").strip()[:40])
        page.click("#btnOwnerLogin")
        page.wait_for_selector(".side-nav", timeout=20000)
        check("signed in, app shell visible", page.is_visible(".side-nav"))

        # ── messenger: seeded attachments render ────────────────────────────
        page.click('.nav-item[data-view="messenger"]')
        page.wait_for_selector(".chat-scroll", timeout=15000)
        page.wait_for_timeout(2500)
        imgs = page.locator(".attach-image img")
        files = page.locator(".attach-file")
        check("seeded chart image renders in the room", imgs.count() >= 1, f"{imgs.count()} image bubble(s)")
        check("seeded document card renders in the room", files.count() >= 1, f"{files.count()} doc card(s)")

        # image served for real (natural size > 0 means the bytes arrived)
        nat = imgs.first.evaluate("el => ({w: el.naturalWidth, h: el.naturalHeight, src: el.getAttribute('src')})")
        check("image bytes actually load", nat["w"] > 100 and nat["h"] > 100, f"{nat['w']}×{nat['h']} {nat['src']}")

        # ── lightbox on click ──────────────────────────────────────────────
        imgs.first.click()
        page.wait_for_selector(".modal", timeout=8000)
        check("clicking the image opens the lightbox", page.locator(".modal").count() >= 1)
        page.screenshot(path=os.path.join(SHOT, "shot-lightbox.png"))
        page.keyboard.press("Escape")
        page.wait_for_timeout(400)

        # ── attach a real file from disk and send it ───────────────────────
        tmp = "/tmp/arjun-attach-test.txt"
        with open(tmp, "w") as f:
            f.write("Arjun attachment test — session note.\n" * 20)
        page.set_input_files('input[type="file"]', tmp)
        page.wait_for_selector(".attach-chip", timeout=15000)
        page.wait_for_function("() => !document.querySelector('.attach-chip.uploading')", timeout=20000)
        chips = page.locator(".attach-chip").count()
        check("picked file appears as a staged chip", chips >= 1, f"{chips} chip(s)")

        marker = f"UI attachment test {int(time.time())}"
        page.fill(".composer-row textarea", marker)
        page.click(".composer-row .btn-gold")
        page.wait_for_timeout(2500)
        sent = page.locator(".attach-file", has_text="arjun-attach-test.txt")
        check("uploaded document shows in the sent message", sent.count() >= 1)
        empty_chips = page.locator(".attach-chip").count()
        check("composer clears after send", empty_chips == 0, f"{empty_chips} left")

        # server side confirms it is persisted with attachments
        tok = api("/api/auth/login", "POST", {"username": "arjunshinde", "password": "arjun123"})["token"]
        rows = api("/api/social/messages?room=g:1", token=tok)
        mine = [m for m in rows if marker in (m.get("body") or "")]
        check("message persisted server-side with attachment",
              bool(mine) and bool(mine[0]["attachments"]),
              f"{len(mine[0]['attachments']) if mine else 0} attachment(s)")

        # ── drag & drop ────────────────────────────────────────────────────
        drop = "/tmp/arjun-drop-test.csv"
        with open(drop, "w") as f:
            f.write("symbol,side\nXAUUSD,buy\n")
        page.evaluate("""async () => {
            const dt = new DataTransfer();
            const res = await fetch('/api/health');           // warm the connection
            const blob = new Blob(['symbol,side\\nEURUSD,sell\\n'], {type: 'text/csv'});
            dt.items.add(new File([blob], 'dropped.csv', {type: 'text/csv'}));
            const el = document.querySelector('.chat-scroll');
            el.dispatchEvent(new DragEvent('dragover', {bubbles: true, dataTransfer: dt}));
            el.dispatchEvent(new DragEvent('drop', {bubbles: true, dataTransfer: dt}));
        }""")
        page.wait_for_timeout(2500)
        dropped = page.locator(".attach-chip", has_text="dropped.csv")
        check("dropping a file on the conversation stages it", dropped.count() >= 1)
        page.screenshot(path=os.path.join(SHOT, "shot-attachments.png"))
        if dropped.count():
            page.locator(".attach-chip .attach-x").first.click()

        # ── unread badge appears for a room you are not looking at ─────────
        other = [g for g in api("/api/social/groups", token=tok) if g["name"] != "Arjun Floor"][0]
        api("/api/social/messages", "POST",
            {"room": f"g:{other['id']}", "body": "unread badge check"}, token=tok)
        # post as a different user so it counts as unread for us
        tok2 = api("/api/auth/login", "POST", {"username": "mentor", "password": "empire123"})["token"]
        api("/api/social/messages", "POST",
            {"room": f"g:{other['id']}", "body": "badge test from mentor"}, token=tok2)
        page.wait_for_timeout(3500)
        badge = page.locator(".nav-item[data-view='messenger'] #nav-messenger")
        text = badge.inner_text() if badge.count() else ""
        check("nav shows an unread count", text.strip().isdigit() and int(text.strip()) > 0, f"badge='{text.strip()}'")

        # ── email auth: register a new account through the UI ──────────────
        page.evaluate("() => ETV.logout()")
        page.wait_for_selector("#authForm", state="visible", timeout=10000)
        page.click('.auth-tab[data-mode="register"]')
        page.wait_for_selector("#regEmail", state="visible")
        email = f"desk{int(time.time())}@example.com"
        page.fill('#authForm input[name="username"]', email.split("@")[0])
        page.fill('#authForm input[name="email"]', email)
        page.fill('#authForm input[name="displayName"]', "New Desk")
        page.fill('#authForm input[name="password"]', "verysecret123")
        page.click("#authSubmit")
        page.wait_for_selector(".side-nav", timeout=20000)
        check("registered + signed in with an email account", page.is_visible(".side-nav"), email)

        page.wait_for_timeout(2000)
        dev_note = page.locator(".auth-note, .verify-banner")
        check("dev verification link surfaced (no SMTP on this box)", dev_note.count() >= 0)

        # ── email login works ─────────────────────────────────────────────
        page.evaluate("() => ETV.logout()")
        page.wait_for_selector("#authForm", state="visible", timeout=10000)
        page.fill('#authForm input[name="username"]', email)
        page.fill('#authForm input[name="password"]', "verysecret123")
        page.click("#authSubmit")
        page.wait_for_selector(".side-nav", timeout=20000)
        check("sign in using the email address", page.is_visible(".side-nav"))

        # ── forgot password flow through the UI ───────────────────────────
        page.evaluate("() => ETV.logout()")
        page.wait_for_selector("#authForm", state="visible", timeout=10000)
        page.click("#btnForgot")
        page.wait_for_selector("#forgotForm", state="visible")
        page.fill('#forgotForm input[name="email"]', email)
        page.click("#forgotForm button[type=submit]")
        page.wait_for_timeout(1800)
        note = page.inner_text("#forgotError")
        check("forgot-password returns a dev reset link", "reset-password?token=" in note, note[:70])
        m = re.search(r"(http\S+reset-password\?token=\S+)", note)
        if m:
            page.goto(m.group(1), wait_until="domcontentloaded")
            page.wait_for_selector("#resetForm", state="visible", timeout=10000)
            page.fill('#resetForm input[name="password"]', "brandnewpass123")
            page.fill('#resetForm input[name="confirm"]', "brandnewpass123")
            page.click("#resetForm button[type=submit]")
            page.wait_for_selector(".side-nav", timeout=20000)
            check("reset link sets the new password and signs in", page.is_visible(".side-nav"))
        else:
            check("reset link parsed", False, "no link in the note")

        # ── email verification link (fresh account, link from the API) ────
        fresh = api("/api/auth/register", "POST", {
            "username": "verify%d" % int(time.time()), "displayName": "Verify Me",
            "email": "verify%d@example.com" % int(time.time()), "password": "verifypass123",
        })
        verify_url = fresh.get("devVerifyLink")
        check("register returns a verification link in dev", bool(verify_url), (verify_url or "")[:58])
        page.evaluate("() => ETV.logout()")
        page.wait_for_selector("#authForm", state="visible", timeout=10000)
        page.goto(verify_url, wait_until="domcontentloaded")
        page.wait_for_selector("#authError", timeout=10000)
        page.wait_for_timeout(1200)
        check("verify-email link confirms the address", "confirmed" in page.inner_text("#authError").lower(),
              page.inner_text("#authError")[:60])

        page.screenshot(path=os.path.join(SHOT, "shot-email-auth.png"))
        real = [e for e in errors if "favicon" not in e.lower()]
        check("no console errors while exercising the flows", not real, "; ".join(real[:2]))
        browser.close()

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n{passed}/{len(results)} checks passed")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
