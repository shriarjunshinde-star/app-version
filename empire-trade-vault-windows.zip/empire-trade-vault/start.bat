@echo off
REM ─────────────────────────────────────────────────────────────
REM  Empire Trade Vault — Windows launcher
REM  Double-click this file, or run:  start.bat
REM  Requires Node.js 18 or newer  (https://nodejs.org)
REM ─────────────────────────────────────────────────────────────
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo   Node.js was not found on this PC.
  echo   Install it from https://nodejs.org  ^(LTS version^) and run this file again.
  echo.
  pause
  exit /b 1
)
echo.
echo   Empire Trade Vault - Arjun Shinde's desk
echo   ----------------------------------------
echo.
node server\boot.js %*
echo.
echo   Server stopped. Press any key to close.
pause >nul
