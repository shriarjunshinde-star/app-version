/* ═══════════════════════════════════════════════════════════════════════
   VIEW · Messenger — rooms, DMs, shared chart analyses and trade cards
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.views.messenger = {
  title: 'Messenger',
  async render(host, params = {}) {
    const { el, fmt, state } = ETV;
    host.innerHTML = '';
    const ui = {
      room: params.room || localStorage.getItem('etv_room') || null,
      groups: [], dms: [], messages: [], members: [], users: [],
      typingTimer: null, lastSenders: {},
    };

    const shell = el('div', { class: 'messenger' });
    host.append(shell);

    /* ------------------------------------------------------------ sidebar */
    const listScroll = el('div', { class: 'ms-scroll' });
    const left = el('div', { class: 'ms-list' },
      el('div', { class: 'ms-head' },
        el('div', { style: { fontSize: '13.5px', fontWeight: '600' }, text: 'Messages' }),
        el('button', { class: 'btn btn-xs btn-gold', text: '+ Room', onclick: newRoomModal })),
      listScroll);
    shell.append(left);

    /* --------------------------------------------------------------- chat */
    const chatScroll = el('div', { class: 'chat-scroll' });
    const chatTitle = el('div', { class: 'ct', text: 'Select a room' });
    const chatSub = el('div', { class: 'cs', text: 'Rooms share full chart analyses, not screenshots.' });
    const typingLine = el('div', { class: 'typing', id: 'typingLine' });
    const composerIn = el('textarea', { placeholder: 'Write to the room…  (Enter to send, Shift+Enter for a new line)' });
    const pendingFiles = [];                       // attachments staged for the next message
    const fileInput = el('input', {
      type: 'file', multiple: 'true', style: { display: 'none' },
      accept: 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.md,.rtf,.zip',
      onchange: (e) => { addFiles([...e.target.files]); e.target.value = ''; },
    });
    const chips = el('div', { class: 'attach-chips' });
    const uploadState = el('span', { class: 'hint', id: 'uploadState' });

    function renderChips() {
      chips.innerHTML = '';
      pendingFiles.forEach((f, i) => chips.append(el('div', { class: 'attach-chip' + (f.uploading ? ' uploading' : '') },
        f.attachment?.kind === 'image'
          ? el('img', { src: f.attachment.url, class: 'attach-thumb', alt: '' })
          : el('span', { class: 'attach-ico', text: (f.attachment?.ext || f.name.split('.').pop() || '?').toUpperCase().slice(0, 4) }),
        el('span', { class: 'attach-meta' },
          el('span', { class: 'an', text: f.attachment?.name || f.name }),
          el('span', { class: 'as', text: f.uploading ? 'uploading…' : (f.attachment?.sizeText || '') })),
        el('button', { class: 'attach-x', text: '×', title: 'Remove', onclick: () => { pendingFiles.splice(i, 1); renderChips(); } }))));
      chips.style.display = pendingFiles.length ? 'flex' : 'none';
    }

    /** Upload files immediately, keep the descriptors as chips until send. */
    async function addFiles(files) {
      const room = ui.room;
      for (const file of files.slice(0, 6)) {
        const entry = { name: file.name, uploading: true };
        pendingFiles.push(entry);
        renderChips();
        try {
          const fd = new FormData();
          fd.append('file', file);
          const res = await fetch('/api/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + ETV.state.token }, body: fd });
          const data = await res.json();
          if (!res.ok) throw new Error(data.error || 'Upload failed');
          entry.attachment = data.files[0];
          entry.uploading = false;
        } catch (e) {
          entry.failed = true;
          ETV.toast('Upload failed', `${file.name}: ${e.message}`, 'bad');
          pendingFiles.splice(pendingFiles.indexOf(entry), 1);
        }
        if (room !== ui.room) break;                // user switched rooms mid-upload
        renderChips();
      }
      updateUploadHint();
    }
    function updateUploadHint() {
      uploadState.textContent = pendingFiles.some((f) => f.uploading)
        ? 'uploading…'
        : pendingFiles.length ? `${pendingFiles.length} file${pendingFiles.length > 1 ? 's' : ''} ready` : '';
    }
    const chat = el('div', { class: 'chat' },
      el('div', { class: 'chat-head' },
        el('div', { class: 'ric', style: { width: '32px', height: '32px', borderRadius: '9px', background: 'var(--surface3)', display: 'grid', placeItems: 'center', fontFamily: 'var(--serif)', color: 'var(--gold)' }, text: '#' }),
        el('div', {}, chatTitle, chatSub),
        el('div', { class: 'spacer' }),
        el('button', { class: 'btn btn-xs', text: 'Share chart', onclick: shareChart }),
        el('button', { class: 'btn btn-xs', text: '+ Members', id: 'btnMembers', onclick: addMembersModal }),
        el('button', { class: 'btn btn-xs', text: 'Leave', id: 'btnLeave', onclick: leaveRoom })),
      chatScroll,
      typingLine,
      el('div', { class: 'composer' },
        el('div', { class: 'composer-tools' },
          el('button', { class: 'btn btn-xs', text: '📎 Attach files', onclick: () => fileInput.click() }),
          el('button', { class: 'btn btn-xs', text: 'Share current chart', onclick: shareChart }),
          el('button', { class: 'btn btn-xs', text: 'Share a trade', onclick: shareTradeModal }),
          el('button', { class: 'btn btn-xs', text: 'Open terminal', onclick: () => ETV.openTerminal(state.chart.symbol, state.chart.tf) }),
          el('span', { class: 'spacer' }),
          uploadState,
          el('span', { class: 'hint', id: 'composerHint', text: '' })),
        chips,
        fileInput,
        el('div', { class: 'composer-row' }, composerIn, el('button', { class: 'btn btn-gold', text: 'Send', onclick: send }))));

    // drop a file anywhere in the conversation to attach it
    chatScroll.addEventListener('dragover', (e) => { e.preventDefault(); chatScroll.classList.add('dropping'); });
    chatScroll.addEventListener('dragleave', () => chatScroll.classList.remove('dropping'));
    chatScroll.addEventListener('drop', (e) => {
      e.preventDefault(); chatScroll.classList.remove('dropping');
      const files = [...(e.dataTransfer?.files || [])];
      if (files.length) addFiles(files);
    });
    shell.append(chat);

    /* ------------------------------------------------------------ members */
    const membersBody = el('div', {});
    const right = el('div', { class: 'msg-members' },
      el('div', { class: 'eyebrow', text: 'In this room' }), membersBody,
      el('div', { style: { marginTop: '16px' } },
        el('div', { class: 'eyebrow', text: 'Traders online' }),
        el('div', { id: 'onlineList' })));
    shell.append(right);

    /* ---------------------------------------------------------- data load */
    async function loadLists() {
      [ui.groups, ui.dms, ui.users] = await Promise.all([
        ETV.api('/social/groups'), ETV.api('/social/dm'), ETV.api('/auth/users'),
      ]);
      if (!ui.room) {
        const first = ui.groups.find((g) => g.joined) || ui.groups[0];
        if (first) ui.room = 'g:' + first.id;
      }
      localStorage.setItem('etv_room', ui.room || '');
      paintLists();
    }

    function paintLists() {
      listScroll.innerHTML = '';
      const mine = ui.groups.filter((g) => g.joined);
      const others = ui.groups.filter((g) => !g.joined);
      listScroll.append(el('div', { class: 'ms-label', text: 'Rooms' }));
      mine.forEach((g) => listScroll.append(roomRow('g:' + g.id, g.icon || '#', g.name, g.topic || `${g.members} members`, g.messageCount)));
      if (others.length) {
        listScroll.append(el('div', { class: 'ms-label', text: 'Public rooms' }));
        others.forEach((g) => listScroll.append(roomRow('g:' + g.id, g.icon || '#', g.name, 'tap to join', g.messageCount, true)));
      }
      listScroll.append(el('div', { class: 'ms-label', text: 'Direct messages' }));
      ui.dms.forEach((d) => listScroll.append(roomRow(d.room, ETV.initials(d.user.display_name), d.user.display_name,
        d.last?.body?.slice(0, 34) || (d.last?.attachments?.length ? '📎 attachment' : 'no messages'), null, false, d.online, d.unread)));
      if (!ui.dms.length) listScroll.append(el('div', { class: 'faint', style: { fontSize: '12px', padding: '6px 10px' }, text: 'No DMs yet — start one from the traders list.' }));
      listScroll.append(el('div', { class: 'ms-label', text: 'Start a DM' }));
      ui.users.slice(0, 8).forEach((u) => listScroll.append(el('button', {
        class: 'room', onclick: () => openDM(u.id),
      }, ETV.avatar(u, 28), el('div', {}, el('div', { class: 'rn', text: u.display_name }), el('div', { class: 'rp', text: '@' + u.username })))));
    }

    function roomRow(room, icon, name, preview, count, needsJoin = false, online, unread = 0) {
      const active = room === ui.room;
      return el('button', {
        class: 'room' + (active ? ' active' : ''),
        onclick: async () => {
          if (needsJoin) await ETV.api(`/social/groups/${room.slice(2)}/join`, { method: 'POST' });
          open(room);
        },
      },
        el('div', { class: 'ric' }, online != null && online ? el('span', { class: 'live-dot' }) : icon),
        el('div', { style: { minWidth: 0 } }, el('div', { class: 'rn', text: name }), el('div', { class: 'rp', text: preview || '' })),
        unread > 0 ? el('span', { class: 'unread-badge', text: unread > 99 ? '99+' : unread })
          : (count != null ? el('span', { class: 'rbadge', text: count }) : null));
    }

    async function open(room) {
      if (ui.room !== room) { pendingFiles.length = 0; renderChips(); updateUploadHint(); }
      ui.room = room;
      localStorage.setItem('etv_room', room);
      ETV.state.socket?.emit('room:open', { room });
      paintLists();
      const isGroup = room.startsWith('g:');
      if (isGroup) {
        const g = ui.groups.find((x) => 'g:' + x.id === room);
        chatTitle.textContent = g?.name || 'Room';
        chatSub.textContent = g?.topic || '';
        document.getElementById('btnMembers').style.display = '';
        document.getElementById('btnLeave').style.display = '';
      } else {
        const d = ui.dms.find((x) => x.room === room);
        const id = room.split(':').slice(1).map(Number).find((x) => x !== state.user.id);
        const u = d?.user || ui.users.find((x) => x.id === id);
        chatTitle.textContent = u?.display_name || 'Direct message';
        chatSub.textContent = '@' + (u?.username || '') + (d?.online ? ' · online' : '');
        document.getElementById('btnMembers').style.display = 'none';
        document.getElementById('btnLeave').style.display = 'none';
      }
      document.getElementById('composerHint').textContent = isGroup ? 'Shared analyses render live in the room' : 'Private conversation';
      await loadMessages();
      await loadMembers();
      markRead();
    }

    async function openDM(userId) {
      const u = ui.users.find((x) => x.id === userId);
      const room = `dm:${Math.min(userId, state.user.id)}:${Math.max(userId, state.user.id)}`;
      if (!ui.dms.find((d) => d.room === room)) ui.dms.unshift({ room, user: u, online: false });
      open(room);
    }

    async function loadMessages() {
      if (!ui.room) return;
      ui.messages = await ETV.api(`/social/messages?room=${encodeURIComponent(ui.room)}&limit=80`);
      paintMessages();
    }

    function markRead() {
      if (!ui.room) return;
      ETV.api('/social/read', { method: 'POST', body: { room: ui.room } }).catch(() => {});
      const g = ui.groups.find((x) => 'g:' + x.id === ui.room);
      if (g) g.unread = 0;
      const d = ui.dms.find((x) => x.room === ui.room);
      if (d) d.unread = 0;
      ETV.emit('unread:changed', {});
    }

    async function loadMembers() {
      membersBody.innerHTML = '';
      document.getElementById('onlineList').innerHTML = '';
      if (ui.room?.startsWith('g:')) {
        ui.members = await ETV.api(`/social/groups/${ui.room.slice(2)}/members`);
        ui.members.forEach((u) => membersBody.append(el('div', { class: 'member' },
          el('span', { class: 'presence' + (u.online ? ' on' : '') }),
          ETV.avatar(u, 24),
          el('div', {}, el('div', { text: u.display_name }),
            el('div', { class: 'faint', style: { fontSize: '11px' }, text: u.role === 'owner' ? 'room owner' : '@' + u.username })),
          el('span', { class: 'spacer' }),
          el('button', { class: 'btn btn-xs', text: 'DM', onclick: () => openDM(u.id) }))));
      }
      const online = ui.users.filter((u) => u.online);
      const list = document.getElementById('onlineList');
      (online.length ? online : ui.users.slice(0, 5)).forEach((u) => list.append(el('div', { class: 'member', style: { cursor: 'pointer' }, onclick: () => openDM(u.id) },
        el('span', { class: 'presence' + (u.online ? ' on' : '') }), ETV.avatar(u, 22), el('span', { text: u.display_name }))));
    }

    /* ----------------------------------------------------------- messages */
    function paintMessages() {
      chatScroll.innerHTML = '';
      let lastDay = '';
      ui.messages.forEach((m) => {
        const day = (m.created_at || '').slice(0, 10);
        if (day !== lastDay) {
          lastDay = day;
          chatScroll.append(el('div', { class: 'day-sep' }, el('span', { text: fmt.day(day) })));
        }
        chatScroll.append(messageNode(m));
      });
      chatScroll.scrollTop = chatScroll.scrollHeight;
    }

    /** Images render inline (click to open full size), documents become cards. */
    function attachmentBlock(a) {
      if (a.kind === 'image') {
        return el('a', {
          class: 'attach-image', href: a.url, target: '_blank', rel: 'noopener',
          title: `${a.name} — ${a.sizeText}`, onclick: (e) => { e.preventDefault(); lightbox(a); },
        },
          el('img', { src: a.url, alt: a.name, loading: 'lazy' }),
          el('span', { class: 'attach-image-meta', text: `${a.name} · ${a.sizeText}` }));
      }
      return el('a', { class: 'attach-file', href: a.url, download: a.name, title: `Download ${a.name}` },
        el('span', { class: 'attach-ico big', text: (a.ext || 'file').toUpperCase().slice(0, 4) }),
        el('span', { class: 'attach-file-meta' },
          el('span', { class: 'an', text: a.name }),
          el('span', { class: 'as', text: `${a.sizeText} · click to download` })),
        el('span', { class: 'attach-dl', text: '⤓' }));
    }

    function lightbox(a) {
      const m = ETV.modal({
        title: a.name, wide: true,
        body: el('div', { style: { textAlign: 'center' } },
          el('img', { src: a.url, alt: a.name, style: { maxWidth: '100%', borderRadius: '10px', border: '1px solid var(--line)' } }),
          el('div', { class: 'hint', style: { marginTop: '10px' }, text: `${a.sizeText} · uploaded ${ETV.fmt.timeAgo(a.uploadedAt)}` })),
        footer: [
          el('a', { class: 'btn', href: a.url, target: '_blank', rel: 'noopener', text: 'Open original' }),
          el('a', { class: 'btn', href: a.url, download: a.name, text: 'Download' }),
        ],
      });
      return m;
    }

    function messageNode(m) {
      const mine = m.user_id === state.user.id;
      const node = el('div', { class: 'msg' + (mine ? ' mine' : ''), dataset: { id: m.id } },
        ETV.avatar({ display_name: m.display_name, avatar_color: m.avatar_color, id: m.user_id }, 30),
        el('div', { class: 'body' },
          el('div', { class: 'msg-head' },
            el('span', { class: 'msg-author', text: m.display_name }),
            el('span', { class: 'msg-time', text: fmt.timeAgo(m.created_at) }),
            m.kind !== 'text' ? el('span', {
              class: 'badge-soft',
              text: { analysis: 'chart analysis', trade: 'trade card', image: 'photo', file: 'document' }[m.kind] || m.kind,
            }) : null),
          m.body ? el('div', { class: 'bubble', text: m.body }) : null,
          (m.attachments || []).length ? el('div', { class: 'attach-list' }, ...m.attachments.map(attachmentBlock)) : null,
          m.kind === 'analysis' ? analysisCard(m) : null,
          m.kind === 'trade' ? tradeCard(m) : null,
          reactionsRow(m),
          el('div', { class: 'msg-actions' },
            ...ETV.state.emojis.slice(0, 6).map((e) => el('button', { class: 'react-btn', text: e, onclick: () => react(m.id, e) })),
            mine ? el('button', { class: 'react-btn', text: 'delete', onclick: async () => { await ETV.api('/social/messages/' + m.id, { method: 'DELETE' }); ui.messages = ui.messages.filter((x) => x.id !== m.id); paintMessages(); } }) : null)));
      return node;
    }

    function reactionsRow(m) {
      const row = el('div', { class: 'reactions' });
      (m.reactions || []).forEach((r) => row.append(el('button', {
        class: 'reaction' + (r.users.includes(state.user.id) ? ' mine' : ''),
        text: `${r.emoji} ${r.count}`, onclick: () => react(m.id, r.emoji),
      })));
      return row;
    }

    async function react(id, emoji) {
      const res = await ETV.api(`/social/messages/${id}/react`, { method: 'POST', body: { emoji } });
      const m = ui.messages.find((x) => x.id === id);
      if (m) { m.reactions = res.reactions; repaintMessage(m); }
    }
    function repaintMessage(m) {
      const old = chatScroll.querySelector(`.msg[data-id="${m.id}"]`);
      if (old) old.replaceWith(messageNode(m));
    }

    /* ------------------------------------------------- analysis chat card */
    function analysisCard(m) {
      const p = m.payload || {};
      const biasCls = p.bias === 'bullish' ? 'green' : p.bias === 'bearish' ? 'red' : '';
      const card = el('div', { class: 'msg-card' },
        el('div', { class: 'msg-card-head' },
          el('b', { text: p.title || `${p.symbol} ${p.tf}` }),
          el('span', { class: 'pill ' + biasCls, text: p.bias || 'neutral' }),
          el('span', { class: 'pill', text: p.tf || '' }),
          el('span', { class: 'spacer' }),
          el('span', { class: 'num', style: { fontSize: '12px' }, text: p.quote ? fmt.price(p.symbol, p.quote.price) : '' })),
        el('div', { class: 'msg-card-body' }, el('div', { class: 'mini-chart', style: { height: '176px' } })),
        p.levels ? el('div', { class: 'levels-strip' },
          levelChip('entry', p.levels.entry, p.symbol), levelChip('stop', p.levels.stop, p.symbol),
          levelChip('target', p.levels.target, p.symbol), levelChip('ATR', p.levels.atr, p.symbol, true),
          p.levels.rsi != null ? el('span', {}, 'RSI ', el('b', { text: p.levels.rsi })) : null) : null,
        p.notes ? el('div', { style: { padding: '10px 13px', fontSize: '12.5px', color: 'var(--text-dim)', lineHeight: '1.6' }, text: p.notes }) : null,
        el('div', { class: 'msg-card-foot' },
          el('button', { class: 'btn btn-xs btn-gold', text: 'Open in terminal', onclick: () => ETV.openTerminal(p.symbol, p.tf) }),
          el('button', { class: 'btn btn-xs', text: 'Copy trade', onclick: () => ETV.orderModal({ symbol: p.symbol, stopLoss: p.levels?.stop, takeProfit: p.levels?.target || p.plan?.target1, notes: p.notes }) }),
          el('button', { class: 'btn btn-xs', text: 'Arm alert', onclick: () => { ETV.openTerminal(p.symbol, p.tf); setTimeout(() => (ETV.terminalAPI?.armAlert ? ETV.terminalAPI.armAlert(p.symbol, p.tf) : ETV.toast('Set the alert from the terminal')), 900); } }),
          el('span', { class: 'spacer' }),
          p.quote ? el('span', { class: 'hint', text: `live ${fmt.price(p.symbol, p.quote.price)} · ${fmt.pct(p.quote.changePct)}` }) : null));
      setTimeout(() => {
        const holder = card.querySelector('.mini-chart');
        if (holder) ETVChart.miniChart(holder, p.snapshot || [], { symbol: p.symbol, height: 176 });
      }, 20);
      return card;
    }
    const levelChip = (l, v, symbol, raw = false) => v == null ? null : el('span', {}, l + ' ', el('b', { text: raw ? v : fmt.price(symbol, v) }));

    function tradeCard(m) {
      const t = m.payload?.trade;
      if (!t) return null;
      const cls = t.pnl >= 0 ? 'green' : 'red';
      const card = el('div', { class: 'msg-card' },
        el('div', { class: 'msg-card-head' },
          el('span', { class: 'pill ' + (t.side === 'buy' ? 'green' : 'red'), text: t.side.toUpperCase() }),
          el('b', { text: t.symbol }),
          el('span', { class: 'pill ' + cls, text: t.status === 'closed' ? fmt.money(t.pnl) : t.status }),
          el('span', { class: 'spacer' }),
          el('span', { class: 'hint', text: t.setup_tag || '' })),
        el('div', { style: { padding: '11px 13px' } },
          el('div', { class: 'grid g3', style: { gap: '8px' } },
            chip('Qty', t.qty), chip('Entry', fmt.price(t.symbol, t.entry_price)),
            chip('Exit', t.exit_price ? fmt.price(t.symbol, t.exit_price) : '—'),
            chip('Stop', fmt.price(t.symbol, t.stop_loss)), chip('Target', fmt.price(t.symbol, t.take_profit)),
            chip('R', t.r_multiple != null ? t.r_multiple + 'R' : '—')),
          t.notes ? el('div', { class: 'hint', style: { marginTop: '9px' }, text: t.notes.slice(0, 220) }) : null),
        el('div', { class: 'msg-card-foot' },
          el('button', { class: 'btn btn-xs btn-gold', text: 'Copy this trade', onclick: () => ETV.orderModal({ symbol: t.symbol, side: t.side, qty: t.qty, stopLoss: t.stop_loss, takeProfit: t.take_profit }) }),
          el('button', { class: 'btn btn-xs', text: 'Open chart', onclick: () => ETV.openTerminal(t.symbol, '1h') })));
      return card;
    }
    const chip = (l, v) => el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '8px', padding: '6px 9px' } },
      el('div', { class: 'k-label', text: l }), el('div', { class: 'num', style: { marginTop: '2px' }, text: v }));

    /* ----------------------------------------------------------- composer */
    async function send() {
      const text = composerIn.value.trim();
      if (pendingFiles.some((f) => f.uploading)) return ETV.toast('Still uploading', 'Give the files a second to finish.', 'bad');
      const attachments = pendingFiles.map((f) => f.attachment).filter(Boolean);
      if ((!text && !attachments.length) || !ui.room) return;
      composerIn.value = '';
      pendingFiles.length = 0;
      renderChips(); updateUploadHint();
      try {
        await ETV.api('/social/messages', { method: 'POST', body: { room: ui.room, body: text, attachments } });
      } catch (e) { ETV.toast('Send failed', e.message, 'bad'); }
    }
    composerIn.addEventListener('paste', (e) => {
      const files = [...(e.clipboardData?.files || [])];
      if (files.length) { e.preventDefault(); addFiles(files); }
    });
    composerIn.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); }
      else {
        state.socket?.emit('typing', { room: ui.room, typing: true });
        clearTimeout(ui.typingTimer);
        ui.typingTimer = setTimeout(() => state.socket?.emit('typing', { room: ui.room, typing: false }), 1400);
      }
    });

    async function shareChart() {
      const pane = ETV.terminalAPI?.pane || { symbol: state.chart.symbol, tf: state.chart.tf };
      const chart = ETV.terminalAPI?.chart || null;
      const analysis = ETV.terminalAPI?.getAnalysis?.() || null;
      if (!ui.room) return ETV.toast('Open a room first', '', 'bad');
      let snap = chart?.snapshot(90);
      let levels = chart?.snapshotLevels() || {};
      if (!snap) {
        const res = await ETV.api(`/market/candles?symbol=${pane.symbol}&tf=${pane.tf}&limit=90`);
        snap = res.candles.map((c) => [c.time, c.open, c.high, c.low, c.close]);
      }
      const note = prompt('Add a note for the room:', analysis ? `${analysis.bias.toUpperCase()} — ${analysis.invalidation}` : '') ;
      if (note === null) return;
      try {
        await ETV.api('/social/share/analysis', {
          method: 'POST',
          body: {
            room: ui.room, symbol: pane.symbol, tf: pane.tf,
            title: `${pane.symbol} ${pane.tf} — ${analysis ? analysis.bias : 'setup'}`,
            notes: note, bias: analysis?.bias || 'neutral',
            levels, indicators: analysis ? { rsi14: analysis.indicators.rsi14, atr14: analysis.indicators.atr14, trend: analysis.trend } : {},
            snapshot: snap, plan: analysis?.plan || null,
          },
        });
        ETV.toast('Chart shared', `Posted to ${chatTitle.textContent}`, 'good');
      } catch (e) { ETV.toast('Share failed', e.message, 'bad'); }
    }

    async function shareTradeModal() {
      const trades = await ETV.api('/trades?status=all&limit=25');
      const list = el('div', { style: { maxHeight: '50vh', overflowY: 'auto' } });
      trades.forEach((t) => list.append(el('button', {
        class: 'pres', style: { width: '100%' },
        onclick: async () => {
          await ETV.api('/social/share/trade', { method: 'POST', body: { room: ui.room, tradeId: t.id } });
          m.close(); ETV.toast('Trade card shared', '', 'good');
        },
      },
        el('div', { class: 'pi', text: t.symbol.slice(0, 2) }),
        el('div', { style: { flex: '1', textAlign: 'left' } }, el('div', { class: 'pt', text: `${t.side.toUpperCase()} ${t.symbol} · ${t.status}` },
          el('div', { class: 'ps', text: `${fmt.price(t.symbol, t.entry_price)} → ${t.exit_price ? fmt.price(t.symbol, t.exit_price) : 'open'}` }))),
        el('div', { class: 'num ' + (t.pnl >= 0 ? 'up' : 'down'), text: t.status === 'closed' ? fmt.money(t.pnl) : '' }))));
      const m = ETV.modal({ title: 'Share a trade card', body: list });
    }

    /* -------------------------------------------------------------- rooms */
    function newRoomModal() {
      const name = el('input', { placeholder: 'Gold Scalphunters' });
      const topic = el('input', { placeholder: 'What is this room about?' });
      const priv = el('input', { type: 'checkbox', style: { width: 'auto' } });
      const m = ETV.modal({
        title: 'Create a room',
        body: [
          el('label', { class: 'fld' }, el('span', { text: 'Room name' }), name),
          el('label', { class: 'fld' }, el('span', { text: 'Topic' }), topic),
          el('label', { class: 'fld row', style: { gap: '8px' } }, priv, el('span', { style: { margin: 0, textTransform: 'none' }, text: 'Private room (invite only)' })),
        ],
        footer: [el('button', {
          class: 'btn btn-gold', text: 'Create', onclick: async () => {
            const g = await ETV.api('/social/groups', { method: 'POST', body: { name: name.value, topic: topic.value, isPrivate: priv.checked, icon: (name.value[0] || '#').toUpperCase() } });
            m.close(); await loadLists(); open('g:' + g.id);
            ETV.toast('Room created', name.value, 'good');
          },
        })],
      });
    }

    function addMembersModal() {
      const list = el('div', { style: { maxHeight: '46vh', overflowY: 'auto' } });
      const ids = new Set(ui.members.map((m) => m.id));
      ui.users.filter((u) => !ids.has(u.id)).forEach((u) => {
        const cb = el('input', { type: 'checkbox', value: u.id, style: { width: 'auto' } });
        list.append(el('label', { class: 'row', style: { padding: '8px 4px', gap: '10px' } }, cb, ETV.avatar(u, 26), el('span', { text: u.display_name })));
      });
      const m = ETV.modal({
        title: 'Add traders to the room',
        body: [list],
        footer: [el('button', {
          class: 'btn btn-gold', text: 'Add selected', onclick: async () => {
            const memberIds = [...list.querySelectorAll('input:checked')].map((i) => Number(i.value));
            if (!memberIds.length) return m.close();
            await ETV.api(`/social/groups/${ui.room.slice(2)}/members`, { method: 'POST', body: { memberIds } });
            m.close(); await loadLists(); loadMembers();
            ETV.toast('Members added', memberIds.length + ' traders', 'good');
          },
        })],
      });
    }

    async function leaveRoom() {
      if (!ui.room?.startsWith('g:')) return;
      if (!(await ETV.confirm('Leave room?', 'You can re-join from the public list at any time.', 'Leave'))) return;
      await ETV.api(`/social/groups/${ui.room.slice(2)}/leave`, { method: 'POST' });
      ui.room = null; await loadLists(); open(ui.room);
    }

    /* ------------------------------------------------------ live wiring */
    const offMsg = ETV.on('message', (m) => {
      if (m.room === ui.room) {
        ui.messages.push(m); chatScroll.append(messageNode(m));
        chatScroll.scrollTop = chatScroll.scrollHeight;
        if (m.user_id !== state.user.id) markRead();
      } else if (m.user_id !== state.user.id) {
        const g = ui.groups.find((x) => 'g:' + x.id === m.room);
        if (g) g.unread = (g.unread || 0) + 1;
        const d = ui.dms.find((x) => x.room === m.room);
        if (d) d.unread = (d.unread || 0) + 1;
        paintLists();
        ETV.emit('unread:changed', {});
      }
    });
    const offDel = ETV.on('message:deleted', ({ id }) => {
      ui.messages = ui.messages.filter((x) => x.id !== id);
      chatScroll.querySelector(`.msg[data-id="${id}"]`)?.remove();
    });
    const offReact = ETV.on('reaction', ({ messageId, reactions }) => {
      const m = ui.messages.find((x) => x.id === messageId);
      if (m) { m.reactions = reactions; repaintMessage(m); }
    });
    const offTyping = ETV.on('typing', ({ room, name, typing }) => {
      if (room !== ui.room) return;
      const line = document.getElementById('typingLine');
      if (line) line.textContent = typing ? `${name} is typing…` : '';
    });
    const offPresence = ETV.on('presence', () => { loadMembers().catch(() => {}); });
    const offDmNew = ETV.on('dm:new', () => loadLists().catch(() => {}));
    const offFocus = ETV.on('room:focus', (room) => open(room));
    const offQuotes = ETV.on('quotes', () => {
      // refresh the live price strip inside shared analysis cards
      chatScroll.querySelectorAll('.msg-card').forEach(() => {});
    });

    await loadLists();
    if (ui.room) await open(ui.room);
    else chatScroll.append(el('div', { class: 'empty', text: 'Create or join a room to start sharing analyses.' }));
    ETV.api('/market/symbols').then(() => {});

    host.addEventListener('etv:leave', () => { offMsg(); offDel(); offReact(); offTyping(); offPresence(); offDmNew(); offFocus(); offQuotes(); }, { once: true });
  },
};
