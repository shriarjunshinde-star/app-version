/* ═══════════════════════════════════════════════════════════════════════
   VIEW · Journal — daily routine, process score, review, history heatmap
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.views.journal = {
  title: 'Journal',
  async render(host, params = {}) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    let day = params.day || new Date().toISOString().slice(0, 10);

    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Process · Vault desk' }), el('div', { class: 'page-title', text: 'Trading journal' })),
      el('div', { class: 'row' },
        el('button', { class: 'btn btn-sm', text: '‹ Previous', onclick: () => shift(-1) }),
        el('button', { class: 'btn btn-sm', id: 'jToday', text: 'Today', onclick: () => { day = new Date().toISOString().slice(0, 10); load(); } }),
        el('button', { class: 'btn btn-sm', text: 'Next ›', onclick: () => shift(1) }),
        el('button', { class: 'btn btn-sm btn-gold', text: 'Save entry', onclick: save }))));

    const dateRow = el('div', { class: 'card', style: { padding: '12px 16px', marginBottom: '14px' } });
    host.append(dateRow);

    const kpiRow = el('div', { class: 'grid g4', style: { marginBottom: '14px' } });
    host.append(kpiRow);

    const grid = el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)' } });
    host.append(grid);
    const formCol = el('div', { class: 'grid', style: { gap: '14px' } });
    const sideCol = el('div', { class: 'grid', style: { gap: '14px' } });
    grid.append(formCol, sideCol);

    const history = el('div', { class: 'card pad0', style: { marginTop: '14px' } });
    host.append(history);

    /* ------------------------------------------------------------- fields */
    const fSession = el('select', {}, ...['London', 'New York', 'London / New York overlap', 'Asia', 'Sydney'].map((s) => el('option', { value: s, text: s })));
    const fBias = el('select', {}, ...['bullish', 'neutral', 'bearish'].map((s) => el('option', { value: s, text: s })));
    const fContext = el('textarea', { placeholder: 'What did the market give you today? Structure, key levels, news, volatility…' });
    const fPlan = el('textarea', { placeholder: 'What is the plan? Setups you are allowed to take, risk, and the level that invalidates the idea.' });
    const fLessons = el('textarea', { placeholder: 'What did you learn — about the market and about yourself?' });
    const fTomorrow = el('textarea', { placeholder: 'One instruction for tomorrow. Make it binary and checkable.' });
    const fMood = el('input', { type: 'range', min: '1', max: '5', value: '3', oninput: (e) => { moodVal.textContent = e.target.value; paintRating(moodRating, +e.target.value); } });
    const fDisc = el('input', { type: 'range', min: '1', max: '5', value: '3', oninput: (e) => { discVal.textContent = e.target.value; paintRating(discRating, +e.target.value); } });
    const moodVal = el('span', { class: 'slider-val', text: '3' });
    const discVal = el('span', { class: 'slider-val', text: '3' });
    const moodRating = el('div', { class: 'rating' });
    const discRating = el('div', { class: 'rating' });
    const paintRating = (node, v) => { node.innerHTML = ''; for (let i = 1; i <= 5; i++) node.append(el('i', { style: { background: i <= v ? (v >= 4 ? 'var(--green)' : v === 3 ? 'var(--gold)' : 'var(--red)') : 'var(--surface3)' } })); };
    paintRating(moodRating, 3); paintRating(discRating, 3);

    const tradeList = el('div', { id: 'jTrades' });

    formCol.append(el('div', { class: 'card' },
      el('div', { class: 'row between', style: { marginBottom: '12px' } },
        el('b', { text: 'Session context' }),
        el('div', { class: 'row', style: { gap: '8px' } },
          el('label', { class: 'fld', style: { margin: 0, width: '150px' } }, el('span', { text: 'Session' }), fSession),
          el('label', { class: 'fld', style: { margin: 0, width: '130px' } }, el('span', { text: 'Bias' }), fBias))),
      el('label', { class: 'fld' }, el('span', { text: 'Market context' }), fContext),
      el('label', { class: 'fld' }, el('span', { text: 'Plan for the day' }), fPlan)),
      el('div', { class: 'card' },
        el('div', { class: 'grid g2', style: { gap: '16px' } },
          el('div', {},
            el('div', { class: 'k-label', text: 'Mood' }),
            el('div', { class: 'slider-row', style: { marginTop: '8px' } }, fMood, moodVal), moodRating),
          el('div', {},
            el('div', { class: 'k-label', text: 'Discipline' }),
            el('div', { class: 'slider-row', style: { marginTop: '8px' } }, fDisc, discVal), discRating)),
        el('div', { style: { height: '14px' } }),
        el('label', { class: 'fld' }, el('span', { text: 'Lessons' }), fLessons),
        el('label', { class: 'fld', style: { marginBottom: 0 } }, el('span', { text: 'Instruction for tomorrow' }), fTomorrow)));

    sideCol.append(el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: "Today's book" }), el('div', { class: 'card-sub', text: 'Every trade you took, reviewed or not' }))),
      tradeList));

    const statsCard = el('div', { class: 'card', id: 'jStats' });
    sideCol.append(statsCard);

    /* --------------------------------------------------------------- load */
    let entry = null;
    async function load() {
      entry = await ETV.api('/journal?day=' + day);
      dateRow.innerHTML = '';
      dateRow.append(el('div', { class: 'row between' },
        el('div', { class: 'row' },
          el('div', {}, el('div', { class: 'k-label', text: 'Journal day' }), el('div', { class: 'serif', style: { fontSize: '20px', marginTop: '4px' }, text: fmt.day(day) })),
          el('span', { class: 'pill gold', text: entry.session || '—' }),
          day === new Date().toISOString().slice(0, 10) ? el('span', { class: 'pill green', text: 'today' }) : null),
        el('div', { class: 'row' },
          el('div', { style: { textAlign: 'right' } },
            el('div', { class: 'k-label', text: 'Net outcome' }),
            el('div', { class: 'num ' + (entry.net_outcome >= 0 ? 'up' : 'down'), style: { fontSize: '18px' }, text: fmt.money(entry.net_outcome) })))));

      kpiRow.innerHTML = '';
      const kpi = (l, v, s, cls = '') => el('div', { class: 'kpi' }, el('div', { class: 'k-label', text: l }), el('div', { class: 'k-val ' + cls, text: v }), el('div', { class: 'k-sub', text: s }));
      kpiRow.append(
        kpi('Process score', entry.processScore + '%', 'plan · context · stops · review', entry.processScore >= 70 ? 'up' : entry.processScore >= 40 ? '' : 'down'),
        kpi('Review complete', entry.reviewComplete + '%', `${entry.tradeCount} trades on the book`),
        kpi('Win rate', entry.winRate == null ? '—' : entry.winRate + '%', `${entry.wins} of ${entry.closedCount} closed`),
        kpi('Net outcome', fmt.money(entry.net_outcome), `${entry.tradeCount} trades`, entry.net_outcome >= 0 ? 'up' : 'down'));

      fSession.value = entry.session || 'London';
      fBias.value = entry.bias || 'neutral';
      fContext.value = entry.market_context || '';
      fPlan.value = entry.plan || '';
      fLessons.value = entry.lessons || '';
      fTomorrow.value = entry.tomorrow || '';
      fMood.value = entry.mood || 3; fDisc.value = entry.discipline || 3;
      moodVal.textContent = entry.mood || 3; discVal.textContent = entry.discipline || 3;
      paintRating(moodRating, entry.mood || 3); paintRating(discRating, entry.discipline || 3);

      tradeList.innerHTML = '';
      if (!entry.trades.length) tradeList.append(el('div', { class: 'empty', text: 'No trades logged on this day.' }));
      entry.trades.forEach((t) => tradeList.append(el('div', { class: 'stat-line', style: { padding: '10px 16px' } },
        el('span', {}, el('span', { class: 'pill ' + (t.side === 'buy' ? 'green' : 'red'), text: t.side.toUpperCase() }), ' ', el('b', { style: { marginLeft: '6px' }, text: t.symbol })),
        el('span', { class: 'num ' + (t.pnl >= 0 ? 'up' : 'down'), text: t.status === 'closed' ? fmt.money(t.pnl) + (t.r_multiple != null ? ` · ${t.r_multiple}R` : '') : t.status }))));

      const s = await ETV.api('/journal/stats');
      statsCard.innerHTML = '';
      statsCard.append(el('div', { class: 'card-title', style: { marginBottom: '10px' }, text: 'Journal discipline' }));
      [['Entries written', s.entries], ['Completed entries', s.completedEntries], ['Avg mood', s.avgMood + ' / 5'], ['Avg discipline', s.avgDiscipline + ' / 5'], ['Journaling streak', s.streak + ' days']]
        .forEach(([l, v]) => statsCard.append(el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { text: v }))));
    }

    function shift(d) {
      const dt = new Date(day + 'T00:00:00Z');
      dt.setUTCDate(dt.getUTCDate() + d);
      day = dt.toISOString().slice(0, 10);
      load();
    }

    async function save() {
      await ETV.api('/journal', {
        method: 'PUT',
        body: {
          day, session: fSession.value, bias: fBias.value,
          marketContext: fContext.value, plan: fPlan.value, lessons: fLessons.value,
          tomorrow: fTomorrow.value, mood: Number(fMood.value), discipline: Number(fDisc.value),
        },
      });
      ETV.toast('Journal saved', 'Process score recalculated against your trade book.', 'good');
      await load();
      await paintHistory();
    }

    /* ------------------------------------------------------------ history */
    async function paintHistory() {
      const rows = await ETV.api('/journal/range?days=45');
      history.innerHTML = '';
      history.append(el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Last 45 sessions' }), el('div', { class: 'card-sub', text: 'Green = profitable day · click a cell to open that journal entry' })),
        el('span', { class: 'pill', text: rows.filter((r) => r.pnl > 0).length + ' green' })));
      const wrap = el('div', { class: 'card-body' });
      const heat = el('div', { class: 'journal-heat' });
      rows.slice().reverse().forEach((r) => {
        const cls = 'jcell' + (r.pnl > 0 ? ' win' : r.pnl < 0 ? ' loss' : '') + (r.day === new Date().toISOString().slice(0, 10) ? ' today' : '');
        heat.append(el('div', {
          class: cls, title: `${r.day} · ${fmt.money(r.pnl)} · ${r.trades} trades${r.hasNotes ? ' · journaled' : ''}`,
          text: new Date(r.day + 'T00:00:00Z').getUTCDate(),
          onclick: () => { day = r.day; load(); window.scrollTo({ top: 0, behavior: 'smooth' }); },
        }));
      });
      wrap.append(heat);
      history.append(wrap);
    }

    await load();
    await paintHistory();
  },
};
