/* ═══════════════════════════════════════════════════════════════════════
   VIEWS · Watchlist · News · Calendar · Alerts · Rooms · Settings · API
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};
const { el, fmt } = ETV;

/* ------------------------------------------------------------- Watchlist */
ETV.views.watchlist = {
  title: 'Watchlist',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Workspace' }), el('div', { class: 'page-title', text: 'Watchlist' })),
      el('button', { class: 'btn btn-gold btn-sm', text: '+ Add market', onclick: add })));

    const card = el('div', { class: 'card pad0' });
    host.append(card);

    async function paint() {
      const [rows, all] = await Promise.all([ETV.api('/watchlist'), ETV.api('/market/symbols')]);
      card.innerHTML = '';
      card.append(el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Tracked markets' }), el('div', { class: 'card-sub', text: 'Prices stream live over the socket' })),
        el('span', { class: 'pill gold', text: `${rows.length} markets` })));
      if (!rows.length) card.append(el('div', { class: 'empty', text: 'Watchlist is empty.' }));
      else {
        const tb = el('tbody');
        const t = el('table', {}, el('thead', {}, el('tr', {}, ...['Market', 'Class', 'Last', 'Change', '24H range', 'Feed', ''].map((h) => el('th', { text: h })))), tb);
        rows.forEach((s) => {
          const q = ETV.quote(s.symbol);
          tb.append(el('tr', {},
            el('td', {}, el('b', { text: s.symbol }), el('div', { class: 'faint', style: { fontSize: '11px' }, text: s.name })),
            el('td', { class: 'faint', text: s.class }),
            el('td', { class: 'num' }, el('span', { class: 'live-dot' }), document.createTextNode(fmt.price(s.symbol, q.price))),
            el('td', { class: 'num ' + (q.changePct >= 0 ? 'up' : 'down'), text: fmt.pct(q.changePct) }),
            el('td', { class: 'num faint', text: `${fmt.price(s.symbol, q.low24h)} – ${fmt.price(s.symbol, q.high24h)}` }),
            el('td', {}, el('span', { class: 'pill ' + (q.source === 'live' ? 'green' : 'gold'), text: q.source || '—' })),
            el('td', {}, el('div', { class: 'row' },
              el('button', { class: 'btn btn-xs', text: 'Chart', onclick: () => ETV.openTerminal(s.symbol, '1h') }),
              el('button', { class: 'btn btn-xs', text: 'Order', onclick: () => ETV.orderModal({ symbol: s.symbol }) }),
              el('button', { class: 'btn btn-xs', text: '×', onclick: async () => { await ETV.api('/watchlist/' + s.symbol, { method: 'DELETE' }); paint(); } })))));
        });
        card.append(t);
      }
    }
    function add() {
      const list = el('div', { style: { maxHeight: '54vh', overflowY: 'auto' } });
      ETV.api('/market/symbols').then((all) => {
        all.forEach((s) => list.append(el('button', { class: 'pres', style: { width: '100%' }, onclick: async () => { await ETV.api('/watchlist', { method: 'POST', body: { symbol: s.symbol } }); m.close(); paint(); ETV.toast(s.symbol + ' added'); } },
          el('div', { class: 'pi', text: s.symbol.slice(0, 2) }),
          el('div', { style: { textAlign: 'left', flex: '1' } }, el('div', { class: 'pt', text: s.symbol }), el('div', { class: 'ps', text: s.name })),
          el('div', { class: 'num', text: fmt.price(s.symbol, ETV.quote(s.symbol).price) }))));
      });
      const m = ETV.modal({ title: 'Add to watchlist', body: list });
    }
    await paint();
    const off = ETV.on('quotes', paint);
    host.addEventListener('etv:leave', off, { once: true });
  },
};

/* ------------------------------------------------------------------ News */
ETV.views.news = {
  title: 'News',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Context' }), el('div', { class: 'page-title', text: 'Headlines & calendar' })),
      el('div', { class: 'row' }, el('input', { id: 'newsSym', placeholder: 'filter symbol e.g. XAUUSD', style: { width: '190px' } }), el('button', { class: 'btn btn-sm btn-gold', text: 'Refresh', onclick: () => load(document.getElementById('newsSym').value.toUpperCase()) }))));

    const grid = el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)' } });
    host.append(grid);
    const newsCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Market headlines' }), el('div', { class: 'card-sub', id: 'newsMeta', text: 'Yahoo Finance feed' }))),
      el('div', { id: 'newsBody', style: { padding: '6px 16px 14px' } }));
    const calCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Economic calendar' }), el('div', { class: 'card-sub', text: 'Indicative weekly schedule — confirm times on your broker feed' }))),
      el('div', { id: 'calBody', style: { padding: '6px 16px 14px' } }));
    grid.append(newsCard, calCard);

    async function load(symbol) {
      const body = document.getElementById('newsBody');
      body.innerHTML = '<div class="skeleton" style="height:13px;margin:10px 0"></div><div class="skeleton" style="height:13px;width:70%"></div>';
      const data = await ETV.api('/market/news' + (symbol ? '?symbol=' + symbol : ''));
      document.getElementById('newsMeta').textContent = `${data.items.length} headlines · ${data.symbol} · Yahoo Finance feed`;
      body.innerHTML = '';
      data.items.forEach((i) => body.append(el('div', { class: 'news-item' },
        i.link ? el('a', { href: i.link, target: '_blank', rel: 'noopener', text: i.title }) : el('div', { text: i.title }),
        el('div', { class: 'news-meta', text: `${i.source || 'newswire'} · ${i.pubDate ? fmt.timeAgo(new Date(i.pubDate).toISOString()) : ''}` }))));
    }
    async function loadCal() {
      const data = await ETV.api('/market/calendar');
      const body = document.getElementById('calBody');
      body.innerHTML = '';
      data.events.slice(0, 18).forEach((e) => body.append(el('div', { class: 'cal-item' },
        el('div', { class: 'impact ' + e.impact }),
        el('div', { style: { flex: '1' } }, el('div', { text: e.title }), el('div', { class: 'faint', style: { fontSize: '11px' }, text: `${e.country} · ${fmt.day(e.time)} ${fmt.clock(e.time)} UTC` })),
        el('span', { class: 'badge-soft', text: e.impact }))));
    }
    await Promise.all([load(''), loadCal()]);
  },
};

/* ---------------------------------------------------------------- Alerts */
ETV.views.alerts = {
  title: 'Alerts',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Automation' }), el('div', { class: 'page-title', text: 'Price alerts' })),
      el('button', { class: 'btn btn-gold btn-sm', text: '+ Arm alert', onclick: () => add() })));
    const card = el('div', { class: 'card pad0' });
    host.append(card);

    async function paint() {
      const rows = await ETV.api('/market/alerts');
      card.innerHTML = '';
      card.append(el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Armed & triggered alerts' }), el('div', { class: 'card-sub', text: 'Fired alerts arrive as toast notifications and in your inbox' })),
        el('span', { class: 'pill', text: `${rows.filter((r) => r.status === 'active').length} active` })));
      if (!rows.length) card.append(el('div', { class: 'empty', text: 'No alerts yet.' }));
      else {
        const tb = el('tbody');
        const t = el('table', {}, el('thead', {}, el('tr', {}, ...['Market', 'Condition', 'Price', 'Last', 'Status', 'Note', ''].map((h) => el('th', { text: h })))), tb);
        rows.forEach((a) => {
          const q = ETV.quote(a.symbol);
          tb.append(el('tr', {},
            el('td', {}, el('b', { text: a.symbol })),
            el('td', { text: a.condition }),
            el('td', { class: 'num', text: fmt.price(a.symbol, a.price) }),
            el('td', { class: 'num', text: fmt.price(a.symbol, q.price) }),
            el('td', {}, el('span', { class: 'pill ' + (a.status === 'active' ? 'green' : a.status === 'triggered' ? 'gold' : ''), text: a.status })),
            el('td', { class: 'faint', text: a.note || '—' }),
            el('td', {}, el('div', { class: 'row' },
              el('button', { class: 'btn btn-xs', text: 'Chart', onclick: () => ETV.openTerminal(a.symbol, '15m') }),
              el('button', { class: 'btn btn-xs', text: '×', onclick: async () => { await ETV.api('/market/alerts/' + a.id, { method: 'DELETE' }); paint(); } })))));
        });
        card.append(t);
      }
    }
    function add() {
      const sym = el('select', {}, ...ETV.state.symbols.map((s) => el('option', { value: s.symbol, text: s.symbol })));
      const cond = el('select', {}, el('option', { value: 'above', text: 'above' }), el('option', { value: 'below', text: 'below' }));
      const price = el('input', { type: 'number', step: 'any', value: ETV.quote(sym.value).price });
      const note = el('input', { placeholder: 'note' });
      sym.addEventListener('change', () => { price.value = ETV.quote(sym.value).price; });
      const m = ETV.modal({
        title: 'Arm a price alert',
        body: [
          el('div', { class: 'grid g2', style: { gap: '12px' } },
            el('label', { class: 'fld' }, el('span', { text: 'Market' }), sym),
            el('label', { class: 'fld' }, el('span', { text: 'Condition' }), cond)),
          el('label', { class: 'fld' }, el('span', { text: 'Price' }), price),
          el('label', { class: 'fld' }, el('span', { text: 'Note' }), note),
        ],
        footer: [el('button', {
          class: 'btn btn-gold', text: 'Arm', onclick: async () => {
            await ETV.api('/market/alerts', { method: 'POST', body: { symbol: sym.value, condition: cond.value, price: Number(price.value), note: note.value } });
            m.close(); paint(); ETV.toast('Alert armed', `${sym.value} ${cond.value} ${price.value}`, 'good');
          },
        })],
      });
    }
    await paint();
    const off = ETV.on('alert', paint);
    host.addEventListener('etv:leave', off, { once: true });
  },
};

/* ----------------------------------------------------------- Rooms index */
ETV.views.rooms = {
  title: 'Rooms',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Community' }), el('div', { class: 'page-title', text: 'Trading rooms' })),
      el('div', { class: 'row' },
        el('button', { class: 'btn btn-sm', text: 'Open messenger', onclick: () => ETV.go('messenger') }),
        el('button', { class: 'btn btn-sm btn-gold', text: '+ New room', onclick: () => ETV.go('messenger') }))));
    const grid = el('div', { class: 'grid g2' });
    host.append(grid);
    const tile = (l, v) => el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '9px', padding: '9px 11px' } },
      el('div', { class: 'k-label', text: l }), el('div', { class: 'num', style: { marginTop: '3px' }, text: v }));
    const groups = await ETV.api('/social/groups');
    groups.forEach((g) => grid.append(el('div', { class: 'card' },
      el('div', { class: 'row between', style: { marginBottom: '8px' } },
        el('div', { class: 'row' },
          el('div', { class: 'ric', style: { width: '30px', height: '30px', borderRadius: '9px', background: 'var(--surface3)', display: 'grid', placeItems: 'center', color: 'var(--gold)', fontFamily: 'var(--serif)' }, text: g.icon || '#' }),
          el('b', { text: g.name })),
        el('span', { class: 'pill ' + (g.joined ? 'green' : ''), text: g.joined ? 'member' : 'public' })),
      el('div', { class: 'card-sub', text: g.topic || '' }),
      el('div', { class: 'grid g3', style: { gap: '8px', margin: '12px 0' } },
        tile('Members', g.members), tile('Messages', g.messageCount), tile('Last', g.lastAt ? fmt.timeAgo(g.lastAt) : '—')),
      g.lastBody ? el('div', { class: 'faint', style: { fontSize: '12.5px', marginBottom: '10px' }, text: '“' + g.lastBody.slice(0, 110) + '”' }) : null,
      el('div', { class: 'row', style: { gap: '7px' } },
        el('button', {
          class: 'btn btn-sm btn-gold', text: g.joined ? 'Open room' : 'Join & open', onclick: async () => {
            if (!g.joined) await ETV.api(`/social/groups/${g.id}/join`, { method: 'POST' });
            ETV.go('messenger', { room: 'g:' + g.id });
          },
        }),
        el('button', { class: 'btn btn-sm', text: 'Share chart here', onclick: () => ETV.shareAnalysisModal(ETV.terminalAPI?.pane || { symbol: ETV.state.chart.symbol, tf: ETV.state.chart.tf }, ETV.terminalAPI?.chart, ETV.terminalAPI?.getAnalysis?.()) })))));
  },
};

/* -------------------------------------------------------------- Settings */
ETV.views.settings = {
  title: 'Settings',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' }, el('div', {}, el('div', { class: 'eyebrow', text: 'Account' }), el('div', { class: 'page-title', text: 'Settings & profile' }))));
    const grid = el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1fr) minmax(0,1fr)' } });
    host.append(grid);

    const u = ETV.state.user;
    const name = el('input', { value: u.display_name });
    const bio = el('input', { value: u.bio || '', placeholder: 'Trading style, markets, goals…' });
    const country = el('input', { value: u.country || '', placeholder: 'IN' });
    const color = el('input', { type: 'color', value: u.avatar_color, style: { height: '40px' } });
    grid.append(el('div', { class: 'card' },
      el('div', { class: 'card-title', style: { marginBottom: '12px' }, text: 'Profile' }),
      el('label', { class: 'fld' }, el('span', { text: 'Display name' }), name),
      el('label', { class: 'fld' }, el('span', { text: 'Bio' }), bio),
      el('div', { class: 'grid g2', style: { gap: '12px' } },
        el('label', { class: 'fld' }, el('span', { text: 'Country' }), country),
        el('label', { class: 'fld' }, el('span', { text: 'Avatar colour' }), color)),
      el('button', {
        class: 'btn btn-gold', text: 'Save profile', onclick: async () => {
          const updated = await ETV.api('/auth/me', { method: 'PATCH', body: { displayName: name.value, bio: bio.value, country: country.value, avatarColor: color.value } });
          ETV.state.user = updated;
          ETV.toast('Profile updated', '', 'good');
          location.reload();
        },
      })));

    const accs = await ETV.api('/accounts');
    const accCard = el('div', { class: 'card' },
      el('div', { class: 'card-title', style: { marginBottom: '12px' }, text: 'Trading accounts' }));
    accs.forEach((a) => accCard.append(el('div', { class: 'stat-line' },
      el('span', {}, el('b', { text: a.name }), el('span', { class: 'faint', text: ` · ${a.broker} · ${a.currency}` })),
      el('b', { text: fmt.cash(a.balance) }))));
    const newBal = el('input', { type: 'number', value: 100000, step: '1000' });
    accCard.append(el('div', { style: { height: '12px' } }),
      el('label', { class: 'fld' }, el('span', { text: 'New demo account balance' }), newBal),
      el('button', {
        class: 'btn', text: '+ Create account', onclick: async () => {
          await ETV.api('/accounts', { method: 'POST', body: { name: 'Vault Paper #' + (accs.length + 1), startBalance: Number(newBal.value) } });
          ETV.state.accounts = await ETV.api('/accounts');
          ETV.views.settings.render(host);
          ETV.toast('Account created');
        },
      }),
      el('div', { class: 'hint', style: { marginTop: '12px' }, text: 'Demo accounts are paper-traded on live prices. Every fill, stop and review lands in this vault only.' }));
    grid.append(accCard);

    const sysCard = el('div', { class: 'card', style: { gridColumn: '1 / -1' } },
      el('div', { class: 'card-title', style: { marginBottom: '12px' }, text: 'System' }));
    const health = await fetch('/api/health').then((r) => r.json()).catch(() => ({}));
    [['API status', health.ok ? 'online' : 'offline'], ['Market feeds', (health.engine?.online ? 'reachable' : 'offline — using fallback candles')],
    ['Quotes refreshed', health.engine?.ok ?? 0], ['Feed errors', health.engine?.fail ?? 0],
    ['Traders', health.users], ['Trades stored', health.trades], ['Messages stored', health.messages]]
      .forEach(([l, v]) => sysCard.append(el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { text: v }))));
    if (health.engine?.lastError) sysCard.append(el('div', { class: 'hint', style: { marginTop: '8px' }, text: 'Last feed message: ' + health.engine.lastError }));
    sysCard.append(el('div', { class: 'row', style: { gap: '8px', marginTop: '14px' } },
      el('button', { class: 'btn btn-sm', text: 'Sign out', onclick: () => ETV.logout() }),
      el('button', { class: 'btn btn-sm', text: 'Open API reference', onclick: () => ETV.go('api') })));
    grid.append(sysCard);
  },
};

/* ------------------------------------------------------------ API guide */
ETV.views.api = {
  title: 'API',
  async render(host) {
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' }, el('div', {}, el('div', { class: 'eyebrow', text: 'Under the hood' }), el('div', { class: 'page-title', text: 'REST & realtime API' }))));
    const ROWS = [
      ['GET', '/api/health', 'service + feed status (public)'],
      ['POST', '/api/auth/register', 'create trader: username, password, displayName'],
      ['POST', '/api/auth/login', 'returns { token, user }'],
      ['GET', '/api/market/symbols', '33 markets with live price, change, feed source'],
      ['GET', '/api/market/candles?symbol=BTCUSD&tf=1h', 'OHLCV candles (OKX for crypto, Yahoo for FX/metals/indices/stocks, offline fallback)'],
      ['GET', '/api/market/indicators?symbol=XAUUSD&tf=1h', 'EMA20/50/200, RSI14, MACD, ATR14, Bollinger, VWAP, pivots, swings'],
      ['GET', '/api/market/news?symbol=BTCUSD', 'headline feed'],
      ['GET', '/api/market/calendar', 'indicative weekly economic calendar'],
      ['POST', '/api/trades', 'place an order — auto-sizes from risk % when qty is omitted'],
      ['POST', '/api/trades/:id/close', 'close with exit price + reason'],
      ['GET', '/api/trades/stats', 'equity curve, win rate, profit factor, avg R, drawdown, breakdowns'],
      ['GET', '/api/journal?day=YYYY-MM-DD', 'journal entry with process score computed from the trade book'],
      ['PUT', '/api/journal', 'save bias, plan, context, lessons, mood, discipline'],
      ['POST', '/api/analysis/:symbol', 'rule-based desk note: bias, strength, levels, scenarios'],
      ['GET', '/api/social/groups', 'rooms with membership + last message'],
      ['POST', '/api/social/share/analysis', 'post a chart (symbol, tf, snapshot, levels, bias) into a room or DM'],
      ['POST', '/api/social/share/trade', 'post a trade card into a room or DM'],
      ['POST', '/api/social/messages', 'plain message; reactions via /react'],
      ['GET', '/api/watchlist', 'per-trader watchlist'],
      ['POST', '/api/market/alerts', 'arm a price alert — server pushes on trigger'],
    ];
    const card = el('div', { class: 'card pad0' });
    card.append(el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Endpoints' }), el('div', { class: 'card-sub', text: 'All non-public routes expect Authorization: Bearer <token>' }))));
    ROWS.forEach(([m, path, desc]) => card.append(el('div', { class: 'api-row', style: { padding: '9px 16px' } },
      el('span', { class: 'method ' + (m === 'GET' ? 'get' : m === 'POST' ? 'post' : m === 'PATCH' ? 'patch' : 'del'), text: m }),
      el('code', { class: 'api', text: path }),
      el('span', { class: 'faint', style: { fontSize: '12px' }, text: desc }))));
    host.append(card);

    const rt = el('div', { class: 'card', style: { marginTop: '14px' } },
      el('div', { class: 'card-title', style: { marginBottom: '10px' }, text: 'Socket.IO events' }));
    [['server → client', 'market:tick', 'bundled quotes + session state every few seconds'],
    ['server → client', 'message / reaction / message:deleted', 'room activity'],
    ['server → client', 'positions:update', 'floating P&L for your open trades'],
    ['server → client', 'alert:triggered / order:filled', 'automation events'],
    ['client → server', 'chat:send / typing / room:open', 'composer + presence'],
    ].forEach(([dir, ev, desc]) => rt.append(el('div', { class: 'api-row' },
      el('span', { class: 'method ' + (dir.startsWith('server') ? 'get' : 'post'), text: dir }),
      el('code', { class: 'api', text: ev }), el('span', { class: 'faint', style: { fontSize: '12px' }, text: desc }))));
    rt.append(el('div', { class: 'hint', style: { marginTop: '12px' }, text: 'Demo logins: trader / mentor / riya / arjun — password empire123.' }));
    host.append(rt);
  },
};
