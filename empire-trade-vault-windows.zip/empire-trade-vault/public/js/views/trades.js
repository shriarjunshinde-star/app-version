/* ═══════════════════════════════════════════════════════════════════════
   VIEWS · Trades (blotter + detail) · Playbooks · Risk management
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.views.trades = {
  title: 'Trades',
  async render(host) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    const filters = { status: 'closed', symbol: '', playbook: '', tag: '', search: '', from: '', to: '' };

    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Evidence' }), el('div', { class: 'page-title', text: 'Trade blotter' })),
      el('div', { class: 'row' },
        el('button', { class: 'btn btn-sm', text: 'Export CSV', onclick: exportCsv }),
        el('button', { class: 'btn btn-sm btn-gold', text: 'New order', onclick: () => ETV.orderModal() }))));

    const openWrap = el('div', { class: 'grid', style: { gap: '12px', marginBottom: '14px' } });
    host.append(openWrap);

    const filtBar = el('div', { class: 'card', style: { padding: '11px 13px', marginBottom: '12px' } });
    host.append(filtBar);

    const tableCard = el('div', { class: 'card pad0' });
    host.append(tableCard);

    /* ----------------------------------------------------- open positions */
    async function paintOpen() {
      const stats = await ETV.api('/trades/stats');
      openWrap.innerHTML = '';
      const positions = stats.openTrades;
      const card = el('div', { class: 'card pad0' },
        el('div', { class: 'card-head' },
          el('div', {}, el('div', { class: 'card-title', text: 'Open positions & working orders' }),
            el('div', { class: 'card-sub', text: 'Live floating P&L · click a row to manage it' })),
          el('span', { class: 'pill ' + (stats.totals.floating >= 0 ? 'green' : 'red'), text: `${positions.length} open · ${fmt.money(stats.totals.floating)}` })));
      if (!positions.length) card.append(el('div', { class: 'empty', text: 'Flat — no live exposure.' }));
      else {
        const tb = el('tbody');
        const t = el('table', {}, el('thead', {}, el('tr', {}, ...['Symbol', 'Side', 'Qty', 'Entry', 'Last', 'Stop', 'Target', 'R risk', 'Floating', ''].map((h) => el('th', { text: h })))), tb);
        positions.forEach((p) => {
          const rNow = p.risk_amount ? p.floating / p.risk_amount : null;
          tb.append(el('tr', {},
            el('td', {}, el('b', { text: p.symbol })),
            el('td', {}, el('span', { class: 'pill ' + (p.side === 'buy' ? 'green' : 'red'), text: p.side.toUpperCase() })),
            el('td', { class: 'num', text: p.qty }),
            el('td', { class: 'num', text: fmt.price(p.symbol, p.entry_price) }),
            el('td', { class: 'num', html: `<span class="live-dot"></span>${fmt.price(p.symbol, p.currentPrice)}` }),
            el('td', { class: 'num faint', text: fmt.price(p.symbol, p.stop_loss) }),
            el('td', { class: 'num faint', text: fmt.price(p.symbol, p.take_profit) }),
            el('td', { class: 'num', text: rNow != null ? (rNow > 0 ? '+' : '') + rNow.toFixed(2) + 'R' : '—' }),
            el('td', { class: 'num ' + (p.floating >= 0 ? 'up' : 'down'), text: fmt.money(p.floating) }),
            el('td', {}, el('div', { class: 'row' },
              el('button', { class: 'btn btn-xs', text: 'Chart', onclick: () => ETV.openTerminal(p.symbol, '15m') }),
              el('button', { class: 'btn btn-xs btn-gold', text: 'Close', onclick: () => ETV.closeTradeModal(p) })))));
        });
        card.append(t);
      }
      openWrap.append(card);
    }

    /* -------------------------------------------------------- filter bar */
    function paintFilters() {
      filtBar.innerHTML = '';
      const statusSeg = el('div', { class: 'seg' });
      [['open', 'Open'], ['closed', 'Closed'], ['pending', 'Working'], ['all', 'All']].forEach(([v, l]) =>
        statusSeg.append(el('button', { class: filters.status === v ? 'active' : '', text: l, onclick: () => { filters.status = v; paintFilters(); paintTable(); } })));
      const symIn = el('input', { placeholder: 'symbol (BTCUSD)', value: filters.symbol, style: { width: '150px' }, oninput: (e) => { filters.symbol = e.target.value.toUpperCase(); debounce(); } });
      const searchIn = el('input', { placeholder: 'search notes, tags…', value: filters.search, style: { width: '190px' }, oninput: (e) => { filters.search = e.target.value; debounce(); } });
      const from = el('input', { type: 'date', value: filters.from, style: { width: '150px' }, onchange: (e) => { filters.from = e.target.value; paintTable(); } });
      const to = el('input', { type: 'date', value: filters.to, style: { width: '150px' }, onchange: (e) => { filters.to = e.target.value; paintTable(); } });
      filtBar.append(el('div', { class: 'row wrap' }, statusSeg, symIn, searchIn, el('span', { class: 'faint', text: 'from' }), from, el('span', { class: 'faint', text: 'to' }), to));
      let timer;
      function debounce() { clearTimeout(timer); timer = setTimeout(paintTable, 260); }
    }

    /* ------------------------------------------------------------ table */
    let rowsCache = [];
    async function paintTable() {
      const qs = new URLSearchParams({ status: filters.status === 'all' ? 'all' : filters.status, limit: '400' });
      if (filters.symbol) qs.set('symbol', filters.symbol);
      if (filters.search) qs.set('search', filters.search);
      if (filters.from) qs.set('from', filters.from);
      if (filters.to) qs.set('to', filters.to);
      const rows = await ETV.api('/trades?' + qs.toString());
      rowsCache = rows;
      tableCard.innerHTML = '';
      tableCard.append(el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: `${rows.length} trades` }),
          el('div', { class: 'card-sub', text: filters.status === 'closed' ? `Net ${fmt.money(rows.reduce((a, t) => a + (t.pnl || 0), 0))} · avg R ${(rows.reduce((a, t) => a + (t.r_multiple || 0), 0) / (rows.filter((t) => t.r_multiple != null).length || 1)).toFixed(2)}` : 'Open and working orders' }))));
      if (!rows.length) { tableCard.append(el('div', { class: 'empty', text: 'Nothing matches those filters.' })); return; }
      const tb = el('tbody');
      const t = el('table', {}, el('thead', {}, el('tr', {}, ...['Date', 'Symbol', 'Side', 'Qty', 'Entry', 'Exit', 'R', 'P&L', 'Setup', 'Tags', ''].map((h) => el('th', { text: h })))), tb);
      rows.forEach((r) => {
        const tr = el('tr', { style: { cursor: 'pointer' }, onclick: () => detail(r) },
          el('td', { class: 'faint', text: fmt.short(r.closed_at || r.opened_at) }),
          el('td', {}, el('b', { text: r.symbol })),
          el('td', {}, el('span', { class: 'pill ' + (r.side === 'buy' ? 'green' : 'red'), text: r.side.toUpperCase() })),
          el('td', { class: 'num', text: r.qty }),
          el('td', { class: 'num', text: fmt.price(r.symbol, r.entry_price) }),
          el('td', { class: 'num', text: r.exit_price ? fmt.price(r.symbol, r.exit_price) : '—' }),
          el('td', { class: 'num ' + ((r.r_multiple || 0) >= 0 ? 'up' : 'down'), text: r.r_multiple != null ? (r.r_multiple > 0 ? '+' : '') + r.r_multiple : '—' }),
          el('td', { class: 'num ' + (r.pnl >= 0 ? 'up' : 'down'), text: r.status === 'closed' ? fmt.money(r.pnl) : '—' }),
          el('td', { class: 'faint', text: r.setup_tag || '—' }),
          el('td', {}, ...(r.tags || []).slice(0, 2).map((tg) => el('span', { class: 'tag', text: tg }))),
          el('td', { class: 'faint', text: '›' }));
        tb.append(tr);
      });
      tableCard.append(t);
    }

    /* ----------------------------------------------------------- detail */
    function detail(trade) {
      const body = el('div', {});
      const meta = ETV.state.symbolMap[trade.symbol] || {};
      const statRow = (l, v, cls) => el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { class: cls || '', text: v }));
      body.append(el('div', { class: 'grid g2', style: { gap: '14px' } },
        el('div', {},
          statRow('Market', `${trade.symbol} · ${meta.name || ''}`),
          statRow('Direction', trade.side.toUpperCase()),
          statRow('Quantity', trade.qty),
          statRow('Entry', fmt.price(trade.symbol, trade.entry_price)),
          statRow('Exit', trade.exit_price ? fmt.price(trade.symbol, trade.exit_price) : '—'),
          statRow('Stop / Target', `${fmt.price(trade.symbol, trade.stop_loss)} / ${fmt.price(trade.symbol, trade.take_profit)}`)),
        el('div', {},
          statRow('Opened', trade.opened_at),
          statRow('Closed', trade.closed_at || '—'),
          statRow('Realised P&L', fmt.money(trade.pnl), trade.pnl >= 0 ? 'up' : 'down'),
          statRow('R multiple', trade.r_multiple != null ? trade.r_multiple + 'R' : '—', (trade.r_multiple || 0) >= 0 ? 'up' : 'down'),
          statRow('Risk', fmt.cash(trade.risk_amount || 0)),
          statRow('Origin', trade.origin))));

      const notes = el('textarea', { value: trade.notes || '', placeholder: 'Review: what did you see, what did you do, what will you repeat?' });
      const tagIn = el('input', { value: (trade.tags || []).join(', '), placeholder: 'tags, comma separated' });
      const emotion = el('input', { value: trade.emotion || '', placeholder: 'emotion (calm, fomo, anxious…)' });
      body.append(el('div', { style: { height: '12px' } }),
        el('label', { class: 'fld' }, el('span', { text: 'Review note' }), notes),
        el('div', { class: 'grid g2', style: { gap: '12px' } },
          el('label', { class: 'fld' }, el('span', { text: 'Tags' }), tagIn),
          el('label', { class: 'fld' }, el('span', { text: 'Emotion' }), emotion)));

      const m = ETV.modal({
        title: `${trade.side.toUpperCase()} ${trade.symbol} · ${trade.status}`,
        wide: true,
        body,
        footer: [
          el('button', { class: 'btn btn-ghost', text: 'Delete', onclick: async () => { if (await ETV.confirm('Delete trade?', 'This removes the trade and reverses its P&L from the balance.', 'Delete')) { await ETV.api('/trades/' + trade.id, { method: 'DELETE' }); m.close(); paintOpen(); paintTable(); ETV.toast('Trade deleted'); } } }),
          el('button', { class: 'btn', text: 'Share to room', onclick: () => shareTrade(trade) }),
          el('button', { class: 'btn', text: 'Open chart', onclick: () => { m.close(); ETV.openTerminal(trade.symbol, '1h'); } }),
          trade.status !== 'closed' ? el('button', { class: 'btn btn-gold', text: 'Close position', onclick: () => { m.close(); ETV.closeTradeModal(trade); } }) : null,
          el('button', {
            class: 'btn btn-gold', text: 'Save review', onclick: async () => {
              await ETV.api('/trades/' + trade.id, { method: 'PATCH', body: { notes: notes.value, tags: tagIn.value.split(',').map((s) => s.trim()).filter(Boolean), emotion: emotion.value } });
              m.close(); paintTable(); ETV.toast('Review saved', 'The journal picks this up automatically.', 'good');
            },
          }),
        ].filter(Boolean),
      });
    }

    async function shareTrade(trade) {
      await ETV.roomPicker(async (room, name) => {
        await ETV.api('/social/share/trade', { method: 'POST', body: { room, tradeId: trade.id, message: `${trade.side.toUpperCase()} ${trade.symbol} — ${trade.status === 'closed' ? fmt.money(trade.pnl) : 'live'}` } });
        ETV.toast('Trade card shared', `Posted to ${name}`, 'good');
      }, { title: `Share ${trade.symbol} trade` });
    }

    function exportCsv() {
      const cols = ['id', 'symbol', 'side', 'qty', 'entry_price', 'exit_price', 'stop_loss', 'take_profit', 'status', 'opened_at', 'closed_at', 'pnl', 'r_multiple', 'setup_tag', 'notes'];
      const csv = [cols.join(',')].concat(rowsCache.map((r) => cols.map((c) => `"${String(r[c] ?? '').replace(/"/g, '""')}"`).join(','))).join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const a = el('a', { href: URL.createObjectURL(blob), download: 'empire-trades.csv' });
      a.click();
      ETV.toast('CSV exported', `${rowsCache.length} rows`);
    }

    paintFilters();
    await Promise.all([paintOpen(), paintTable()]);
    const off = ETV.on('positions', () => { paintOpen(); if (filters.status !== 'closed') paintTable(); });
    host.addEventListener('etv:leave', off, { once: true });
  },
};

/* ═══════════════════════════════════════════════════════════════════════
   Playbooks
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views.playbooks = {
  title: 'Playbooks',
  async render(host) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Evidence' }), el('div', { class: 'page-title', text: 'Playbooks' })),
      el('button', { class: 'btn btn-gold btn-sm', text: '+ New playbook', onclick: () => editor() })));
    const grid = el('div', { class: 'grid g2' });
    host.append(grid);

    async function paint() {
      const [books, stats] = await Promise.all([ETV.api('/playbooks'), ETV.api('/trades/stats')]);
      const perf = Object.fromEntries(stats.byPlaybook.map((p) => [p.name, p]));
      grid.innerHTML = '';
      books.forEach((b) => {
        const p = perf[b.name] || { trades: 0, pnl: 0, wins: 0 };
        const wr = p.trades ? Math.round((p.wins / p.trades) * 100) : 0;
        grid.append(el('div', { class: 'card' },
          el('div', { class: 'row between', style: { marginBottom: '8px' } },
            el('div', { class: 'row' }, el('span', { style: { width: '10px', height: '10px', borderRadius: '3px', background: b.color } }), el('b', { text: b.name })),
            el('div', { class: 'row' }, el('button', { class: 'btn btn-xs', text: 'Edit', onclick: () => editor(b) }), el('button', { class: 'btn btn-xs', text: '×', onclick: async () => { await ETV.api('/playbooks/' + b.id, { method: 'DELETE' }); paint(); } }))),
          el('div', { class: 'card-sub', style: { marginBottom: '10px' }, text: b.description || '' }),
          el('div', { style: { marginBottom: '12px' } }, ...(b.rules || []).map((r) => el('div', { class: 'reason' }, el('i'), el('span', { text: r })))),
          el('div', { class: 'grid g3', style: { gap: '8px' } },
            tile('Trades', p.trades), tile('Win rate', wr + '%'), tile('Net', fmt.money(p.pnl), p.pnl >= 0 ? 'up' : 'down'))));
      });
      if (!books.length) grid.append(el('div', { class: 'empty', text: 'No playbooks yet — document your first setup.' }));
    }
    const tile = (l, v, cls) => el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '9px', padding: '9px 11px' } },
      el('div', { class: 'k-label', text: l }), el('div', { class: 'num ' + (cls || ''), style: { marginTop: '3px' }, text: v }));

    function editor(b = {}) {
      const name = el('input', { value: b.name || '', placeholder: 'London Sweep + Reclaim' });
      const desc = el('textarea', { value: b.description || '', placeholder: 'When does this setup appear, and why does it work?' });
      const rules = el('textarea', { value: (b.rules || []).join('\n'), placeholder: 'One rule per line' });
      const color = el('input', { type: 'color', value: b.color || '#C9A94C', style: { height: '40px' } });
      const m = ETV.modal({
        title: b.id ? 'Edit playbook' : 'New playbook',
        body: [
          el('label', { class: 'fld' }, el('span', { text: 'Name' }), name),
          el('label', { class: 'fld' }, el('span', { text: 'Description' }), desc),
          el('label', { class: 'fld' }, el('span', { text: 'Rules (one per line)' }), rules),
          el('label', { class: 'fld' }, el('span', { text: 'Colour' }), color),
        ],
        footer: [el('button', {
          class: 'btn btn-gold', text: 'Save', onclick: async () => {
            const payload = { name: name.value, description: desc.value, rules: rules.value.split('\n').map((s) => s.trim()).filter(Boolean), color: color.value };
            if (b.id) await ETV.api('/playbooks/' + b.id, { method: 'PATCH', body: payload });
            else await ETV.api('/playbooks', { method: 'POST', body: payload });
            m.close(); paint(); ETV.toast('Playbook saved');
          },
        })],
      });
    }
    await paint();
  },
};

/* ═══════════════════════════════════════════════════════════════════════
   Risk management
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views.risk = {
  title: 'Risk MGMT',
  async render(host) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Evidence' }), el('div', { class: 'page-title', text: 'Risk management' })),
      el('button', { class: 'btn btn-sm btn-gold', text: 'Position size calculator', onclick: calcModal })));

    const grid = el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.25fr) minmax(0,1fr)' } });
    host.append(grid);
    const left = el('div', { class: 'grid', style: { gap: '14px' } });
    const rightCol = el('div', { class: 'grid', style: { gap: '14px' } });
    grid.append(left, rightCol);

    async function paint() {
      const [risk, stats] = await Promise.all([ETV.api('/risk'), ETV.api('/trades/stats')]);
      left.innerHTML = ''; rightCol.innerHTML = '';
      const acc = risk.account;

      left.append(el('div', { class: 'card pad0' },
        el('div', { class: 'card-head' },
          el('div', {}, el('div', { class: 'card-title', text: 'Account risk profile' }), el('div', { class: 'card-sub', text: `${acc.name} · ${acc.broker} · ${acc.currency}` })),
          el('span', { class: 'pill gold', text: 'live' })),
        el('div', { class: 'card-body' },
          el('div', { class: 'grid g3', style: { gap: '12px' } },
            tile('Balance', fmt.cash(acc.balance)),
            tile('Equity', fmt.cash(stats.totals.equity)),
            tile('Return', fmt.pct(stats.totals.returnPct), stats.totals.returnPct >= 0 ? 'up' : 'down'),
            tile('Risk / trade', fmt.cash(risk.riskPerTradeUsd) + ` (${risk.riskPerTradePct}%)`),
            tile('Max daily loss', fmt.cash(risk.maxDailyLossUsd) + ` (${risk.maxDailyLossPct}%)`),
            tile('Open risk', fmt.cash(risk.openRiskUsd) + ` (${risk.openRiskPct}%)`)),
          el('div', { class: 'eyebrow', style: { marginTop: '16px' }, text: 'Adjust limits' }),
          el('div', { class: 'grid g3', style: { gap: '12px' } },
            field('Risk per trade %', acc.risk_per_trade, (v) => save({ riskPerTrade: v })),
            field('Max daily loss %', acc.max_daily_loss, (v) => save({ maxDailyLoss: v })),
            field('Leverage 1:', acc.leverage, (v) => save({ leverage: v }))))));

      left.append(el('div', { class: 'card pad0' },
        el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Book exposure' }), el('div', { class: 'card-sub', text: 'Notional value of every open position' }))),
        risk.exposure.length ? el('table', {}, el('thead', {}, el('tr', {}, ...['Symbol', 'Side', 'Qty', 'Notional', 'Risk', '% of equity'].map((h) => el('th', { text: h })))),
          el('tbody', {}, ...risk.exposure.map((x) => el('tr', {},
            el('td', {}, el('b', { text: x.symbol })),
            el('td', {}, el('span', { class: 'pill ' + (x.side === 'buy' ? 'green' : 'red'), text: x.side.toUpperCase() })),
            el('td', { class: 'num', text: x.qty }),
            el('td', { class: 'num', text: fmt.cash(x.notional, 0) }),
            el('td', { class: 'num', text: fmt.cash(x.risk || 0) }),
            el('td', { class: 'num', text: stats.totals.equity ? ((x.notional / stats.totals.equity) * 100).toFixed(1) + '%' : '—' })))))
          : el('div', { class: 'empty', text: 'No open exposure.' })));

      const dd = stats.totals.maxDrawdownPct;
      const lossLimit = risk.maxDailyLossUsd ? Math.min(100, (stats.totals.dayLossUsed / risk.maxDailyLossUsd) * 100) : 0;
      rightCol.append(el('div', { class: 'card' },
        el('div', { class: 'card-title', style: { marginBottom: '12px' }, text: 'Guardrails' }),
        meter('Daily loss used', lossLimit, fmt.cash(stats.totals.dayLossUsed) + ' / ' + fmt.cash(risk.maxDailyLossUsd)),
        meter('Max drawdown', Math.min(100, (dd / 10) * 100), dd + '% / 10%'),
        meter('Open risk vs limit', Math.min(100, (risk.openRiskPct / (risk.maxDailyLossPct || 3)) * 100), risk.openRiskPct + '%'),
        el('div', { class: 'hint', style: { marginTop: '12px' }, text: 'The terminal sizes every market order from these numbers, and the dashboard warns you before the daily limit is hit.' })));

      rightCol.append(el('div', { class: 'card' },
        el('div', { class: 'card-title', style: { marginBottom: '10px' }, text: 'Discipline stats' }),
        line('Trades closed', stats.totals.closed),
        line('Avg win / loss', `${fmt.cash(stats.totals.avgWin)} / ${fmt.cash(stats.totals.avgLoss)}`),
        line('Profit factor', stats.totals.profitFactor),
        line('Expectancy', fmt.money(stats.totals.expectancy)),
        line('Best / worst', `${fmt.money(stats.totals.bestTrade)} / ${fmt.money(stats.totals.worstTrade)}`),
        line('Current streak', stats.totals.streak)));
    }

    const tile = (l, v, cls) => el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '10px', padding: '11px 12px' } },
      el('div', { class: 'k-label', text: l }), el('div', { class: 'num ' + (cls || ''), style: { fontSize: '15px', marginTop: '4px' }, text: v }));
    const line = (l, v) => el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { text: v }));
    function meter(label, pct, val) {
      return el('div', { style: { marginBottom: '12px' } },
        el('div', { class: 'row between', style: { fontSize: '12px', marginBottom: '6px' } }, el('span', { class: 'muted', text: label }), el('span', { class: 'num', text: val })),
        el('div', { class: 'bar ' + (pct > 70 ? 'danger' : pct > 35 ? 'warn' : 'ok') }, el('i', { style: { width: pct + '%' } })));
    }
    function field(label, value, onSave) {
      const inp = el('input', { type: 'number', step: 'any', value });
      inp.addEventListener('change', () => onSave(Number(inp.value)));
      return el('label', { class: 'fld', style: { margin: 0 } }, el('span', { text: label }), inp);
    }
    async function save(patch) {
      const acc = ETV.state.accounts[0];
      await ETV.api('/accounts/' + acc.id, { method: 'PATCH', body: patch });
      ETV.state.accounts = await ETV.api('/accounts');
      paint(); ETV.toast('Risk limits updated');
    }

    function calcModal() {
      const symbols = ETV.state.symbols.map((s) => s.symbol);
      const sym = el('select', {}, ...symbols.map((s) => el('option', { value: s, text: s })));
      const entry = el('input', { type: 'number', step: 'any', value: ETV.quote(sym.value).price });
      const stop = el('input', { type: 'number', step: 'any' });
      const riskPct = el('input', { type: 'number', step: '0.1', value: ETV.state.accounts[0]?.risk_per_trade || 1 });
      const out = el('div', { class: 'card', style: { background: '#0E1117' } });
      const calc = () => {
        const balance = ETV.state.accounts[0]?.balance || 100000;
        const riskUsd = balance * (Number(riskPct.value) / 100);
        const size = ETV.sizeForRisk(sym.value, Number(entry.value), Number(stop.value), riskUsd);
        const factor = ETV.unitFactor(sym.value);
        out.innerHTML = '';
        [['Risk budget', fmt.cash(riskUsd)], ['Position size', size + (factor > 1 ? ' lots' : ' units')],
        ['Units', (size * factor).toFixed(2)], ['Notional', fmt.cash(size * factor * Number(entry.value), 0)]]
          .forEach(([l, v]) => out.append(el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { text: v }))));
      };
      sym.addEventListener('change', () => { entry.value = ETV.quote(sym.value).price; calc(); });
      [entry, stop, riskPct].forEach((i) => i.addEventListener('input', calc));
      calc();
      const m = ETV.modal({
        title: 'Position size calculator',
        body: [el('label', { class: 'fld' }, el('span', { text: 'Market' }), sym),
          el('div', { class: 'grid g2', style: { gap: '12px' } },
            el('label', { class: 'fld' }, el('span', { text: 'Entry' }), entry),
            el('label', { class: 'fld' }, el('span', { text: 'Stop loss' }), stop)),
          el('label', { class: 'fld' }, el('span', { text: 'Risk % of balance' }), riskPct), out],
        footer: [el('button', { class: 'btn btn-gold', text: 'Send to order ticket', onclick: () => { m.close(); ETV.orderModal({ symbol: sym.value, stopLoss: Number(stop.value) }); } })],
      });
    }

    await paint();
  },
};
