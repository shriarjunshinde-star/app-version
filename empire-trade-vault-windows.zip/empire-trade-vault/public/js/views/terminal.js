/* ═══════════════════════════════════════════════════════════════════════
   VIEW · Terminal — charts, indicators, drawing tools, order ticket,
   AI desk note and one-tap sharing into any room.
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.symbolPicker = function symbolPicker(onPick) {
  const { el } = ETV;
  const search = el('input', { placeholder: 'Search 33 markets — gold, BTC, Nifty, EURUSD…', autofocus: 'true' });
  const list = el('div', { style: { maxHeight: '52vh', overflowY: 'auto' } });
  const m = ETV.modal({ title: 'Select market', wide: true, body: [search, list] });
  const render = (q = '') => {
    list.innerHTML = '';
    const groups = {};
    ETV.state.symbols
      .filter((s) => !q || s.symbol.toLowerCase().includes(q.toLowerCase()) || s.name.toLowerCase().includes(q.toLowerCase()))
      .forEach((s) => { (groups[s.class] = groups[s.class] || []).push(s); });
    Object.entries(groups).forEach(([klass, items]) => {
      list.append(el('div', { class: 'eyebrow', style: { marginTop: '12px' }, text: klass }));
      items.forEach((s) => {
        const price = ETV.quote(s.symbol);
        list.append(el('button', { class: 'pres', style: { width: '100%' }, onclick: () => { m.close(); onPick(s.symbol); } },
          el('div', { class: 'pi', text: s.symbol.slice(0, 2) }),
          el('div', { style: { flex: '1', textAlign: 'left' } }, el('div', { class: 'pt', text: s.symbol }), el('div', { class: 'ps', text: s.name })),
          el('div', { style: { textAlign: 'right' } },
            el('div', { class: 'num', style: { fontSize: '12.5px' }, text: ETV.fmt.price(s.symbol, price.price) }),
            el('div', { class: 'num ' + (price.changePct >= 0 ? 'up' : 'down'), style: { fontSize: '11px' }, text: ETV.fmt.pct(price.changePct) }))));
      });
    });
    if (!list.children.length) list.append(el('div', { class: 'empty', text: 'No markets match that search.' }));
  };
  search.addEventListener('input', () => render(search.value));
  render('');
  setTimeout(() => search.focus(), 50);
};

ETV.views.terminal = {
  title: 'Terminal',
  async render(host) {
    const { el, fmt, state } = ETV;
    host.innerHTML = '';
    const pane = { symbol: state.chart.symbol, tf: state.chart.tf };
    let chart = null, lastAnalysis = null, markers = [];
    const ticket = { side: 'buy', qty: '', stop: '', target: '', notes: '' };

    const wrap = el('div', { class: 'grid', style: { gap: '14px' } });
    host.append(wrap);

    /* ------------------------------------------------------------ header */
    const head = el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Workspace' }), el('div', { class: 'page-title', text: 'Charting terminal' })));
    wrap.append(head);

    const grid = el('div', { class: 'term-grid' });
    wrap.append(grid);

    const shell = el('div', { class: 'chart-shell' });
    const right = el('div', { class: 'side-stack' });
    grid.append(shell, right);

    /* ------------------------------------------------------- chart header */
    const symBtn = el('button', { class: 'sym-btn', onclick: () => ETV.symbolPicker((s) => { pane.symbol = s; state.chart.symbol = s; localStorage.setItem('etv_symbol', s); fullReload(); }) },
      el('div', {}, el('div', { class: 's', id: 'symName', text: pane.symbol }), el('div', { class: 'n', id: 'symFull', text: state.symbolMap[pane.symbol]?.name || '' })));
    const tfRow = el('div', { class: 'tf-row' });
    state.timeframes.forEach((tf) => tfRow.append(el('button', { class: 'tf ' + (tf === pane.tf ? 'active' : ''), text: state.tfLabels[tf] || tf.toUpperCase(), onclick: (e) => { pane.tf = tf; state.chart.tf = tf; localStorage.setItem('etv_tf', tf); tfRow.querySelectorAll('.tf').forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); chart?.load(pane.symbol, tf).then(drawMarkers); } })));

    const typeSeg = el('div', { class: 'seg' });
    [['candles', 'Candles'], ['heikin', 'HA'], ['bar', 'Bars'], ['line', 'Line'], ['area', 'Area']].forEach(([v, l], i) =>
      typeSeg.append(el('button', { class: i === 0 ? 'active' : '', text: l, onclick: (e) => { typeSeg.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); chart?.setSeriesType(v); } })));

    const indRow = el('div', { class: 'row wrap', style: { gap: '5px' } });
    [['ema20', 'EMA 20'], ['ema50', 'EMA 50'], ['ema200', 'EMA 200'], ['bb', 'Bollinger'], ['vwap', 'VWAP'], ['volume', 'Volume']].forEach(([k, label]) => {
      const active = k === 'volume' || k === 'ema20' || k === 'ema50';
      indRow.append(el('button', { class: 'btn btn-xs ' + (active ? 'btn-gold' : ''), text: label, onclick: (e) => { const on = chart?.toggle(k); e.target.classList.toggle('btn-gold', !!on); } }));
    });

    const chartTop = el('div', { class: 'chart-top' }, symBtn, tfRow, typeSeg, el('div', { class: 'spacer' }), indRow);
    const meta = el('div', { class: 'chart-meta', id: 'chartMeta' });
    const canvasWrap = el('div', { class: 'chart-canvas', id: 'chartCanvas' });
    const legend = el('div', { class: 'ohlc-legend', id: 'chartLegend' });

    // drawing tools
    const tools = el('div', { class: 'chart-tools' });
    const TOOLS = [
      ['cursor', 'Cursor', '<path d="M5 3l14 8-6 2-2 6z"/>'],
      ['level', 'Horizontal level', '<path d="M3 12h18"/>'],
      ['trend', 'Trend line', '<path d="M3 19 21 5"/>'],
      ['measure', 'Measure move', '<path d="M3 21 21 3"/><path d="M14 3h7v7"/>'],
    ];
    TOOLS.forEach(([key, title, path], i) => tools.append(el('button', {
      class: 'tool' + (i === 0 ? ' active' : ''), title, html: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${path}</svg>`,
      onclick: (e) => { tools.querySelectorAll('.tool').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); chart?.setTool(key); },
    })));
    tools.append(el('button', { class: 'tool', title: 'Clear drawings', html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M6 6l12 12M18 6 6 18"/></svg>', onclick: () => { chart?.clearDrawings(); ETV.toast('Drawings cleared'); } }));

    shell.append(chartTop, meta, el('div', { style: { position: 'relative' } }, canvasWrap, legend, tools));
    shell.append(el('div', { class: 'chart-top', style: { borderTop: '1px solid var(--line-soft)', borderBottom: 'none' } },
      el('button', { class: 'btn btn-sm btn-gold', text: 'Ask desk for analysis', onclick: () => runAnalysis(true) }),
      el('button', { class: 'btn btn-sm', text: 'Copy plan', onclick: () => { if (!lastAnalysis) return ETV.toast('Run the analysis first', '', 'bad'); navigator.clipboard?.writeText(planText(lastAnalysis)); ETV.toast('Trade plan copied to clipboard'); } }),
      el('button', { class: 'btn btn-sm', text: 'Share chart to room', onclick: () => ETV.shareAnalysisModal(pane, chart, lastAnalysis) }),
      el('button', { class: 'btn btn-sm', text: 'Set alert', onclick: () => alertModal() })));

    /* ------------------------------------------------------- order ticket */
    const sideSeg = el('div', { class: 'seg', style: { width: '100%' } });
    ['buy', 'sell'].forEach((s) => sideSeg.append(el('button', { class: s === 'buy' ? 'active' : '', text: s === 'buy' ? 'Buy / Long' : 'Sell / Short', style: { flex: '1' }, onclick: (e) => { ticket.side = s; sideSeg.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); paintTicketFooter(); } })));

    const fQty = el('input', { type: 'number', step: 'any', placeholder: 'auto (risk-based)', oninput: (e) => { ticket.qty = e.target.value; paintTicketFooter(); } });
    const fStop = el('input', { type: 'number', step: 'any', placeholder: 'stop loss', oninput: (e) => { ticket.stop = e.target.value; paintTicketFooter(); } });
    const fTarget = el('input', { type: 'number', step: 'any', placeholder: 'take profit' });
    const fNotes = el('input', { placeholder: 'why are you taking this trade?' });
    const riskOut = el('div', { id: 'riskOut' });

    const ticketCard = el('div', { class: 'card' },
      el('div', { class: 'card-head', style: { padding: '0 0 12px', border: 'none' } },
        el('div', {}, el('div', { class: 'card-title', text: 'Order ticket' }), el('div', { class: 'card-sub', id: 'ticketPrice', text: '—' }))),
      sideSeg,
      el('div', { style: { height: '10px' } }),
      el('div', { class: 'ticket-side' },
        el('label', { class: 'fld', style: { margin: 0 } }, el('span', { text: 'Qty (lots/units)' }), fQty),
        el('label', { class: 'fld', style: { margin: 0 } }, el('span', { text: 'Stop loss' }), fStop)),
      el('div', { class: 'ticket-side' },
        el('label', { class: 'fld', style: { margin: 0 } }, el('span', { text: 'Take profit' }), fTarget),
        el('label', { class: 'fld', style: { margin: 0 } }, el('span', { text: 'Setup note' }), fNotes)),
      riskOut,
      el('div', { class: 'row', style: { gap: '7px', marginTop: '4px' } },
        el('button', { class: 'btn btn-buy', style: { flex: '1' }, text: 'Buy', onclick: () => place('buy') }),
        el('button', { class: 'btn btn-sell', style: { flex: '1' }, text: 'Sell', onclick: () => place('sell') })),
      el('div', { class: 'hint', style: { marginTop: '8px' }, text: 'Leave qty empty and the terminal sizes the position so the stop risks your account risk %. Live orders fill at the current price.' }));

    function paintTicketFooter() {
      const price = ETV.quote(pane.symbol).price;
      document.getElementById('ticketPrice').textContent = `${pane.symbol} · last ${fmt.price(pane.symbol, price)}`;
      const stop = Number(ticket.stop);
      const acc = ETV.state.accounts[0];
      const riskUsd = acc ? (acc.balance * (acc.risk_per_trade || 1)) / 100 : 0;
      const perUnit = stop && price ? Math.abs(price - stop) : null;
      const qty = Number(ticket.qty) || null;
      riskOut.innerHTML = '';
      const line = (l, v, cls = '') => el('div', { class: 'risk-line' }, el('span', { class: 'muted', text: l }), el('b', { class: 'num ' + cls, text: v }));
      riskOut.append(line('Account risk budget', fmt.cash(riskUsd)));
      riskOut.append(line('Stop distance', perUnit ? perUnit.toFixed(state.symbolMap[pane.symbol]?.digits ?? 2) + ' pts' : '—'));
      if (!qty && perUnit) {
        const size = ETV.sizeForRisk ? ETV.sizeForRisk(pane.symbol, price, stop, riskUsd) : null;
        riskOut.append(line('Auto size', size ? size : '—', ''));
      }
      riskOut.append(line('Risk on this order', qty && perUnit ? fmt.cash(qty * perUnit * (ETV.unitFactor(pane.symbol) || 1)) : (perUnit ? fmt.cash(riskUsd) : '—'), 'down'));
      riskOut.append(line('Margin @ 1:' + (acc?.leverage || 100), qty && price ? fmt.cash((qty * price * (ETV.unitFactor(pane.symbol) || 1)) / (acc?.leverage || 100)) : '—'));
    }

    async function place(side) {
      ticket.side = side;
      const body = {
        symbol: pane.symbol, side,
        qty: Number(ticket.qty) || undefined,
        stopLoss: Number(ticket.stop) || undefined,
        takeProfit: Number(fTarget.value) || undefined,
        notes: fNotes.value || undefined,
        origin: 'analysis',
      };
      try {
        const res = await ETV.api('/trades', { method: 'POST', body });
        ETV.toast(`${side === 'buy' ? 'Long' : 'Short'} ${pane.symbol} opened`, `${res.trade.qty} @ ${fmt.price(pane.symbol, res.trade.entry_price)} · risk ${fmt.cash(res.trade.risk_amount || 0)}`, 'good');
        chart?.addPriceLine(res.trade.entry_price, { color: side === 'buy' ? '#4CAF7D' : '#D96456', title: side.toUpperCase(), dashed: false });
        if (body.stopLoss) chart?.addPriceLine(body.stopLoss, { color: '#D96456', title: 'SL' });
        if (body.takeProfit) chart?.addPriceLine(body.takeProfit, { color: '#4CAF7D', title: 'TP' });
        ETV.emit('positions', []);
      } catch (e) { ETV.toast('Order rejected', e.message, 'bad'); }
    }

    /* ------------------------------------------------ analysis + share card */
    const analysisCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Desk note' }), el('div', { class: 'card-sub', text: 'Rule-based read of the live indicator pack' })),
        el('span', { class: 'pill', id: 'biasPill', text: 'idle' })),
      el('div', { class: 'card-body', id: 'analysisBody' }, el('div', { class: 'faint', style: { fontSize: '12.5px' }, text: 'Press “Ask desk for analysis” to score the current chart.' })));

    const alertCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Price alerts' }))),
      el('div', { class: 'card-body', id: 'alertBody' }));

    function alertModal() {
      const price = ETV.quote(pane.symbol).price;
      const inp = el('input', { type: 'number', step: 'any', value: price });
      const cond = el('select', {}, el('option', { value: 'above', text: 'Crosses above' }), el('option', { value: 'below', text: 'Crosses below' }));
      const note = el('input', { placeholder: 'note (optional)' });
      const m = ETV.modal({
        title: `Alert · ${pane.symbol}`,
        body: [el('label', { class: 'fld' }, el('span', { text: 'Condition' }), cond), el('label', { class: 'fld' }, el('span', { text: 'Price' }), inp), el('label', { class: 'fld' }, el('span', { text: 'Note' }), note)],
        footer: [
          el('button', { class: 'btn btn-ghost', text: 'Cancel', onclick: () => m.close() }),
          el('button', {
            class: 'btn btn-gold', text: 'Arm alert', onclick: async () => {
              await ETV.api('/market/alerts', { method: 'POST', body: { symbol: pane.symbol, condition: cond.value, price: Number(inp.value), note: note.value } });
              m.close(); ETV.toast('Alert armed', `${pane.symbol} ${cond.value} ${inp.value}`, 'good'); paintAlerts();
            },
          }),
        ],
      });
    }

    async function paintAlerts() {
      const node = document.getElementById('alertBody');
      const alerts = await ETV.api('/market/alerts');
      ETV.state.alerts = alerts;
      node.innerHTML = '';
      const active = alerts.filter((a) => a.status === 'active');
      if (!active.length) node.append(el('div', { class: 'faint', style: { fontSize: '12.5px' }, text: 'No armed alerts.' }));
      active.slice(0, 5).forEach((a) => node.append(el('div', { class: 'stat-line' },
        el('span', {}, `${a.symbol} ${a.condition} ${fmt.price(a.symbol, a.price)}`),
        el('button', { class: 'btn btn-xs', text: '×', onclick: async () => { await ETV.api('/market/alerts/' + a.id, { method: 'DELETE' }); paintAlerts(); } }))));
      node.append(el('div', { style: { marginTop: '9px' } }, el('button', { class: 'btn btn-sm btn-block', text: '+ Arm alert on ' + pane.symbol, onclick: alertModal })));
    }

    function planText(a) {
      return `${a.symbol} ${a.tf} — ${a.bias.toUpperCase()} (${a.strength}% agreement)\n` +
        `Entry ${a.plan.entry} | Stop ${a.plan.stop} | TP1 ${a.plan.target1} | TP2 ${a.plan.target2}\n` +
        `ATR ${a.indicators.atr14} · RSI ${a.indicators.rsi14} · R:R ${a.plan.rr}\n` +
        `Invalidation: ${a.invalidation}\n` + a.reasons.map((r) => '· ' + r).join('\n');
    }

    async function runAnalysis(openModal) {
      const body = document.getElementById('analysisBody');
      body.innerHTML = '<div class="skeleton" style="height:12px;margin-bottom:8px"></div><div class="skeleton" style="height:12px;width:80%"></div>';
      try {
        const a = await ETV.api(`/analysis/${pane.symbol}?tf=${pane.tf}`);
        lastAnalysis = a;
        const pill = document.getElementById('biasPill');
        pill.textContent = `${a.bias} · ${a.strength}%`;
        pill.className = 'pill ' + (a.bias === 'bullish' ? 'green' : a.bias === 'bearish' ? 'red' : '');
        body.innerHTML = '';
        body.append(
          el('div', { class: 'analysis-note', html: escHtml(a.summary) }),
          el('div', { class: 'grid g2', style: { gap: '8px', margin: '12px 0' } },
            planTile('Entry', a.plan.entry), planTile('Stop', a.plan.stop),
            planTile('Target 1', a.plan.target1), planTile('Target 2', a.plan.target2)),
          el('div', {}, ...a.reasons.slice(0, 6).map((r) => el('div', { class: 'reason' }, el('i'), el('span', { text: r })))),
          el('div', { class: 'hint', style: { marginTop: '10px' }, text: a.invalidation }),
          el('div', { class: 'row', style: { gap: '6px', marginTop: '12px', flexWrap: 'wrap' } },
            el('button', { class: 'btn btn-xs btn-gold', text: 'Use in ticket', onclick: () => { fStop.value = a.plan.stop; fTarget.value = a.plan.target1; ticket.stop = a.plan.stop; paintTicketFooter(); } }),
            el('button', { class: 'btn btn-xs', text: 'Mark on chart', onclick: () => { chart?.addPriceLine(a.plan.stop, { color: '#D96456', title: 'AI stop' }); chart?.addPriceLine(a.plan.target1, { color: '#4CAF7D', title: 'AI target' }); chart?.addPriceLine(a.plan.entry, { color: '#C9A94C', title: 'entry', dashed: false }); } }),
            el('button', { class: 'btn btn-xs', text: 'Share to room', onclick: () => ETV.shareAnalysisModal(pane, chart, a) })));
        if (openModal) ETV.toast(`Desk note ready · ${a.bias}`, `${a.strength}% of checks agree on ${a.symbol} ${a.tf}`, 'good');
      } catch (e) { body.textContent = 'Analysis failed: ' + e.message; }
    }
    const planTile = (l, v) => el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '9px', padding: '8px 10px' } },
      el('div', { class: 'k-label', text: l }), el('div', { class: 'num', style: { fontSize: '13.5px', marginTop: '3px' }, text: fmt.price(pane.symbol, v) }));
    const escHtml = (s) => ETV.esc(s);

    /* ----------------------------------------------------------- markers */
    function drawMarkers() {
      if (!chart) return;
      const ms = markers.slice(-12).map((t) => ({
        time: t.time, position: t.side === 'buy' ? 'belowBar' : 'aboveBar',
        color: t.side === 'buy' ? '#4CAF7D' : '#D96456', shape: t.side === 'buy' ? 'arrowUp' : 'arrowDown',
        text: `${t.side === 'buy' ? 'L' : 'S'} ${t.qty}`,
      })).filter((m) => chart.candles.some((c) => c.time === m.time));
      chart.setMarkers(ms);
    }
    async function loadMarkers() {
      try {
        const trades = await ETV.api(`/trades?symbol=${pane.symbol}&limit=60`);
        markers = trades.filter((t) => t.status === 'closed' || t.status === 'open').map((t) => ({
          time: Math.floor(new Date(((t.closed_at || t.opened_at) + 'Z').replace(' ', 'T')).getTime() / 1000),
          side: t.side, qty: t.qty, pnl: t.pnl,
        }));
        drawMarkers();
      } catch { /* ignore */ }
    }

    /* ------------------------------------------------------ legend + meta */
    function setMeta() {
      const q = ETV.quote(pane.symbol);
      meta.innerHTML = '';
      const item = (l, v, cls = '') => el('span', {}, el('span', { class: 'faint', text: l + ' ' }), el('b', { class: cls, text: v }));
      meta.append(
        item('LAST', fmt.price(pane.symbol, q.price), q.changePct >= 0 ? 'up' : 'down'),
        item('CHG', fmt.pct(q.changePct), q.changePct >= 0 ? 'up' : 'down'),
        item('24H H', fmt.price(pane.symbol, q.high24h)),
        item('24H L', fmt.price(pane.symbol, q.low24h)),
        item('FEED', (chart?.source || q.source || '—').toUpperCase(), chart?.source === 'sim' ? 'down' : 'up'),
        el('span', { class: 'pill ' + (q.source === 'live' ? 'green' : 'gold'), text: q.source === 'live' ? 'live data' : 'offline feed' }),
      );
    }
    function setLegend(p) {
      const node = document.getElementById('chartLegend');
      if (!node) return;
      if (!p) { node.innerHTML = ''; return; }
      const c = p.bar || {};
      const d = state.symbolMap[pane.symbol]?.digits ?? 2;
      const up = (c.close ?? 0) >= (c.open ?? 0);
      node.innerHTML = `O <span class="v">${(c.open ?? 0).toFixed(d)}</span> H <span class="v">${(c.high ?? 0).toFixed(d)}</span> L <span class="v">${(c.low ?? 0).toFixed(d)}</span> C <span class="v" style="color:${up ? '#4CAF7D' : '#D96456'}">${(c.close ?? 0).toFixed(d)}</span>`;
    }

    /* --------------------------------------------------------- assemble */
    right.append(ticketCard, analysisCard, alertCard);
    const wlCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Watchlist' }), el('div', { class: 'card-sub', text: 'Tap to load the chart' }))),
      el('div', { id: 'wlBody' }));
    right.append(wlCard);

    async function paintWatchlist() {
      const rows = await ETV.api('/watchlist');
      const body = document.getElementById('wlBody');
      body.innerHTML = '';
      rows.forEach((s) => {
        const q = ETV.quote(s.symbol);
        body.append(el('div', {
          class: 'stat-line', style: { cursor: 'pointer', padding: '9px 16px' },
          onclick: () => { pane.symbol = s.symbol; state.chart.symbol = s.symbol; localStorage.setItem('etv_symbol', s.symbol); fullReload(); },
        },
          el('span', { style: { fontSize: '12.5px' } }, el('b', { text: s.symbol }), el('span', { class: 'faint', style: { marginLeft: '8px', fontSize: '11.5px' }, text: s.class })),
          el('span', { style: { textAlign: 'right' } },
            el('div', { class: 'num', style: { fontSize: '12.5px' }, text: fmt.price(s.symbol, q.price) }),
            el('div', { class: 'num ' + (q.changePct >= 0 ? 'up' : 'down'), style: { fontSize: '11px' }, text: fmt.pct(q.changePct) }))));
      });
    }

    async function fullReload() {
      document.getElementById('symName').textContent = pane.symbol;
      document.getElementById('symFull').textContent = state.symbolMap[pane.symbol]?.name || '';
      setMeta();
      await chart.load(pane.symbol, pane.tf);
      setMeta();
      await loadMarkers();
      runAnalysis(false);
    }

    chart = new ETVChart.ChartPane(canvasWrap, { symbol: pane.symbol, tf: pane.tf, height: 452, interactive: true });
    chart.onLegend = setLegend;
    await fullReload();
    paintAlerts(); paintWatchlist(); paintTicketFooter();

    const offQ = ETV.on('quotes', () => { setMeta(); paintTicketFooter(); });
    const offT = ETV.on('tick', (p) => { const q = ETV.state.quotes[pane.symbol]; if (q) { chart.applyTick(q); setMeta(); } });
    const offP = ETV.on('positions', () => loadMarkers());
    host.addEventListener('etv:leave', () => { offQ(); offT(); offP(); try { chart.destroy(); } catch {} }, { once: true });

    ETV.terminalAPI = { pane, chart, runAnalysis: () => runAnalysis(true), getAnalysis: () => lastAnalysis, alertModal, armAlert: (symbol, tf) => { pane.symbol = symbol; pane.tf = tf; alertModal(); } };
  },
};

/* ═══════════════════════════════════════════════════════════════════════
   Shared modals + position maths used by the terminal, trades and
   messenger views.
   ═══════════════════════════════════════════════════════════════════════ */
const UNIT_FACTOR = { forex: 100000, metal: 100, energy: 1000 };   // lots → units

ETV.unitFactor = (symbol) => {
  const meta = ETV.state.symbolMap[symbol];
  return UNIT_FACTOR[meta?.class] || 1;
};
ETV.sizeForRisk = (symbol, entry, stop, riskUsd) => {
  const diff = Math.abs(entry - stop);
  if (!diff) return 0;
  const factor = ETV.unitFactor(symbol);
  const units = riskUsd / diff;
  return factor > 1 ? +(units / factor).toFixed(2) : +units.toFixed(4);
};

/** Room picker shared by every “share” action. */
ETV.roomPicker = async function (onPick, { title = 'Share to…' } = {}) {
  const { el } = ETV;
  const [groups, dms] = await Promise.all([ETV.api('/social/groups'), ETV.api('/social/dm')]);
  const list = el('div', { style: { maxHeight: '50vh', overflowY: 'auto' } });
  const mine = groups.filter((g) => g.joined);
  list.append(el('div', { class: 'eyebrow', text: 'Rooms you are in' }));
  mine.forEach((g) => list.append(el('button', { class: 'pres', style: { width: '100%' }, onclick: () => { m.close(); onPick('g:' + g.id, g.name); } },
    el('div', { class: 'pi', text: g.icon || '#' }),
    el('div', { style: { flex: '1', textAlign: 'left' } }, el('div', { class: 'pt', text: g.name }), el('div', { class: 'ps', text: `${g.members} members · ${g.topic || ''}`.slice(0, 60) })))));
  const other = groups.filter((g) => !g.joined);
  if (other.length) {
    list.append(el('div', { class: 'eyebrow', text: 'Public rooms — join & share' }));
    other.forEach((g) => list.append(el('button', { class: 'pres', style: { width: '100%' }, onclick: async () => { await ETV.api(`/social/groups/${g.id}/join`, { method: 'POST' }); m.close(); onPick('g:' + g.id, g.name); } },
      el('div', { class: 'pi', text: g.icon || '#' }),
      el('div', { style: { flex: '1', textAlign: 'left' } }, el('div', { class: 'pt', text: g.name }), el('div', { class: 'ps', text: 'join to post' })))));
  }
  if (dms.length) {
    list.append(el('div', { class: 'eyebrow', text: 'Direct messages' }));
    dms.forEach((d) => list.append(el('button', { class: 'pres', style: { width: '100%' }, onclick: () => { m.close(); onPick(d.room, d.user.display_name); } },
      ETV.avatar(d.user, 28),
      el('div', { style: { flex: '1', textAlign: 'left' } }, el('div', { class: 'pt', text: d.user.display_name }), el('div', { class: 'ps', text: '@' + d.user.username })))));
  }
  const m = ETV.modal({ title, body: list });
  return m;
};

/** Share the current chart + analysis (or a raw snapshot) into a room / DM. */
ETV.shareAnalysisModal = async function (pane, chart, analysis) {
  const { el, fmt } = ETV;
  const symbol = pane.symbol;
  const tf = pane.tf;
  const defaultNote = analysis ? `${analysis.bias.toUpperCase()} bias — ${analysis.strength}% agreement. ${analysis.invalidation}` : '';
  const note = el('textarea', { placeholder: 'What is the idea? Levels, trigger, invalidation…', value: defaultNote });
  const title = el('input', { value: `${symbol} ${tf} — ${analysis ? analysis.bias : 'setup'}` });
  const incl = el('input', { type: 'checkbox', checked: 'true', style: { width: 'auto' } });

  // make sure the post carries a real snapshot even if the live chart is mid-reload
  let snapshot = chart && chart.candles && chart.candles.length ? chart.snapshot(90) : null;
  if (!snapshot) {
    try {
      const res = await ETV.api(`/market/candles?symbol=${symbol}&tf=${tf}&limit=90`);
      snapshot = res.candles.map((c) => [c.time, c.open, c.high, c.low, c.close]);
    } catch { snapshot = []; }
  }

  await ETV.roomPicker(async (room, roomName) => {
    const payload = {
      room, symbol, tf,
      title: title.value, notes: note.value,
      bias: analysis ? analysis.bias : 'neutral',
      levels: chart ? chart.snapshotLevels() : {},
      indicators: analysis ? { rsi14: analysis.indicators.rsi14, atr14: analysis.indicators.atr14, ema20: analysis.indicators.ema.ema20, ema50: analysis.indicators.ema.ema50, ema200: analysis.indicators.ema.ema200, trend: analysis.trend } : {},
      snapshot: snapshot || [],
      markers: [],
      plan: analysis ? analysis.plan : null,
      reasons: analysis ? analysis.reasons.slice(0, 5) : [],
    };
    try {
      await ETV.api('/social/share/analysis', { method: 'POST', body: payload });
      ETV.toast('Chart shared', `Posted ${symbol} ${tf} to ${roomName}`, 'good');
      ETV.emit('room:focus', room);
    } catch (e) { ETV.toast('Share failed', e.message, 'bad'); }
  }, { title: `Share ${symbol} ${tf} analysis` });
};

/** Generic new-order modal (topbar, dashboard, messenger “copy trade”). */
ETV.orderModal = function (prefill = {}) {
  const { el, fmt } = ETV;
  const symbols = ETV.state.symbols.map((s) => s.symbol);
  let symbol = prefill.symbol || ETV.state.chart.symbol;
  const priceOf = (s) => ETV.quote(s).price;

  const symSel = el('select', {}, ...symbols.map((s) => el('option', { value: s, selected: s === symbol ? 'true' : null, text: `${s} — ${ETV.state.symbolMap[s].name}` })));
  const sideSel = el('select', {}, el('option', { value: 'buy', text: 'Buy / Long' }), el('option', { value: 'sell', selected: prefill.side === 'sell' ? 'true' : null, text: 'Sell / Short' }));
  const qty = el('input', { type: 'number', step: 'any', placeholder: 'auto (risk based)', value: prefill.qty ?? '' });
  const stop = el('input', { type: 'number', step: 'any', value: prefill.stopLoss ?? priceOf(symbol) });
  const target = el('input', { type: 'number', step: 'any', value: prefill.takeProfit ?? '' });
  const notes = el('input', { placeholder: 'setup note (goes into the journal)', value: prefill.notes || '' });
  const out = el('div', { class: 'card', style: { background: '#0E1117' } });
  const playbooks = el('select', {}, el('option', { value: '', text: '— no playbook —' }));

  ETV.api('/playbooks').then((pbs) => pbs.forEach((p) => playbooks.append(el('option', { value: p.id, text: p.name })))).catch(() => {});

  const calc = () => {
    const p = priceOf(symbol);
    const st = Number(stop.value);
    const q = Number(qty.value) || ETV.sizeForRisk(symbol, p, st, (ETV.state.accounts[0]?.balance || 100000) * ((ETV.state.accounts[0]?.risk_per_trade || 1) / 100));
    const factor = ETV.unitFactor(symbol);
    const risk = Math.abs(p - st) * q * factor;
    out.innerHTML = '';
    [
      ['Last price', fmt.price(symbol, p)],
      ['Est. qty', qty.value ? q : `${q} (auto)`],
      ['Risk if stopped', fmt.cash(risk)],
      ['R:R to target', target.value ? (Math.abs(Number(target.value) - p) / Math.abs(p - st || 1)).toFixed(2) + ' : 1' : '—'],
    ].forEach(([l, v]) => out.append(el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: l }), el('b', { text: v }))));
  };
  symSel.addEventListener('change', () => { symbol = symSel.value; stop.value = priceOf(symbol); calc(); });
  [qty, stop, target].forEach((i) => i.addEventListener('input', calc));
  calc();

  const m = ETV.modal({
    title: 'New order',
    wide: true,
    body: [
      el('div', { class: 'grid g2', style: { gap: '12px' } },
        el('label', { class: 'fld' }, el('span', { text: 'Market' }), symSel),
        el('label', { class: 'fld' }, el('span', { text: 'Direction' }), sideSel),
        el('label', { class: 'fld' }, el('span', { text: 'Quantity (lots/units)' }), qty),
        el('label', { class: 'fld' }, el('span', { text: 'Stop loss' }), stop),
        el('label', { class: 'fld' }, el('span', { text: 'Take profit' }), target),
        el('label', { class: 'fld' }, el('span', { text: 'Playbook' }), playbooks)),
      el('label', { class: 'fld' }, el('span', { text: 'Setup note' }), notes),
      out,
    ],
    footer: [
      el('button', { class: 'btn btn-ghost', text: 'Cancel', onclick: () => m.close() }),
      el('button', {
        class: 'btn btn-gold', text: 'Place order', onclick: async () => {
          try {
            const res = await ETV.api('/trades', {
              method: 'POST',
              body: {
                symbol, side: sideSel.value, qty: Number(qty.value) || undefined,
                stopLoss: Number(stop.value) || undefined, takeProfit: Number(target.value) || undefined,
                notes: notes.value || undefined, playbookId: playbooks.value || undefined, origin: 'manual',
              },
            });
            m.close();
            ETV.toast('Order filled', `${res.trade.side.toUpperCase()} ${res.trade.qty} ${symbol} @ ${fmt.price(symbol, res.trade.entry_price)}`, 'good');
            ETV.emit('positions', []);
            ETV.go('trades');
          } catch (e) { ETV.toast('Rejected', e.message, 'bad'); }
        },
      }),
    ],
  });
};

/** Close a position with a P&L preview. */
ETV.closeTradeModal = function (trade) {
  const { el, fmt } = ETV;
  const price = ETV.quote(trade.symbol).price;
  const exit = el('input', { type: 'number', step: 'any', value: price });
  const reason = el('select', {}, ...['manual', 'take profit', 'stop loss', 'trailing stop', 'news exit', 'end of session'].map((r) => el('option', { value: r, text: r })));
  const notes = el('textarea', { placeholder: 'What did you learn? This note feeds your review.' });
  const out = el('div', { style: { fontFamily: 'var(--mono)', fontSize: '13px' } });

  const calc = () => {
    const ex = Number(exit.value) || price;
    const dir = trade.side === 'buy' ? 1 : -1;
    const factor = ETV.unitFactor(trade.symbol);
    const pnl = (ex - trade.entry_price) * dir * trade.qty * factor;
    const r = trade.risk_amount ? pnl / trade.risk_amount : null;
    out.innerHTML = `<span class="${pnl >= 0 ? 'up' : 'down'}">${fmt.money(pnl)}</span> · ${r != null ? (r >= 0 ? '+' : '') + r.toFixed(2) + 'R' : ''}`;
  };
  exit.addEventListener('input', calc); calc();

  const m = ETV.modal({
    title: `Close ${trade.side.toUpperCase()} ${trade.symbol}`,
    body: [
      el('div', { class: 'grid g2', style: { gap: '12px' } },
        el('label', { class: 'fld' }, el('span', { text: 'Exit price' }), exit),
        el('label', { class: 'fld' }, el('span', { text: 'Reason' }), reason)),
      el('label', { class: 'fld' }, el('span', { text: 'Review note' }), notes),
      el('div', { class: 'stat-line' }, el('span', { class: 'muted', text: 'Booked P&L' }), el('b', {}, out)),
    ],
    footer: [
      el('button', { class: 'btn btn-ghost', text: 'Cancel', onclick: () => m.close() }),
      el('button', {
        class: 'btn btn-gold', text: 'Close position', onclick: async () => {
          try {
            const res = await ETV.api(`/trades/${trade.id}/close`, { method: 'POST', body: { exitPrice: Number(exit.value), reason: reason.value, notes: notes.value } });
            m.close();
            ETV.toast('Position closed', `${fmt.money(res.trade.pnl)} · ${res.trade.r_multiple != null ? res.trade.r_multiple + 'R' : ''}`, res.trade.pnl >= 0 ? 'good' : 'bad');
            ETV.emit('positions', []);
            ETV.emit('trade:closed', res.trade);
            setTimeout(() => ETV.views[ETV.state.view]?.render?.(document.getElementById('viewHost')), 60);
          } catch (e) { ETV.toast('Failed', e.message, 'bad'); }
        },
      }),
    ],
  });
};
