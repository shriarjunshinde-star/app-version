/* ═══════════════════════════════════════════════════════════════════════
   VIEW · Dashboard — equity, P&L, risk, open exposure, alerts
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.views.dashboard = {
  title: 'Dashboard',
  async render(host) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    const wrap = el('div', { class: 'grid', style: { gap: '14px' } });
    host.append(wrap);

    const head = el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Command deck' }), el('div', { class: 'page-title', text: 'Dashboard' })),
      el('div', { class: 'row' },
        el('div', { class: 'pill gold', id: 'dashSource', text: 'feed: —' }),
        el('button', { class: 'btn btn-gold btn-sm', text: 'New order', onclick: () => ETV.orderModal() })));
    wrap.append(head);

    const kpis = el('div', { class: 'grid g4' });
    wrap.append(kpis);

    const midRow = el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.55fr) minmax(0,1fr)' } });
    wrap.append(midRow);

    const lower = el('div', { class: 'grid g2' });
    wrap.append(lower);

    /* ----------------------------------------------------------- KPI cards */
    function paintKpis(stats) {
      const t = stats.totals;
      kpis.innerHTML = '';
      const card = (label, value, sub, cls = '') => el('div', { class: 'kpi ' + cls },
        el('div', { class: 'k-label', text: label }),
        el('div', { class: 'k-val ' + cls, text: value }),
        el('div', { class: 'k-sub', html: sub }));
      kpis.append(
        card('Account equity', fmt.cash(t.equity), `balance ${fmt.cash(t.balance)} · start ${fmt.cash(t.startBalance, 0)}`),
        card("Today's P&L", fmt.money(t.todayPnl), `${t.closed} closed · ${t.open} open positions`, t.todayPnl >= 0 ? 'up' : 'down'),
        card('Win rate', t.winRate + '%', `${t.wins}W / ${t.losses}L · PF ${t.profitFactor}`, ''),
        card('Avg R multiple', (t.avgR > 0 ? '+' : '') + t.avgR + 'R', `expectancy ${fmt.money(t.expectancy)} / trade`, t.avgR >= 0 ? 'up' : 'down'),
      );
      document.getElementById('dashSource').textContent = 'feed: ' + (ETV.state.live.source || '—');
    }

    /* ----------------------------------------------------------- risk card */
    function paintRisk(risk, stats) {
      const t = stats.totals;
      const usedPct = risk.maxDailyLossUsd ? Math.min(100, (t.dayLossUsed / risk.maxDailyLossUsd) * 100) : 0;
      const openPct = Math.min(100, (risk.openRiskPct / (risk.maxDailyLossPct || 3)) * 100);
      const ddPct = Math.min(100, (t.maxDrawdownPct / 10) * 100);
      riskCard.innerHTML = '';
      riskCard.append(
        el('div', { class: 'card-head' },
          el('div', {}, el('div', { class: 'card-title', text: 'Risk control' }), el('div', { class: 'card-sub', text: `Account ${risk.account.name} · leverage 1:${risk.leverage} · ${risk.riskPerTradePct}% per trade` })),
          el('span', { class: 'pill ' + (usedPct > 70 ? 'red' : usedPct > 30 ? 'gold' : 'green'), text: usedPct > 70 ? 'at risk' : 'within limits' })),
        el('div', { class: 'card-body' },
          riskBar('Daily loss used', fmt.cash(t.dayLossUsed), fmt.cash(risk.maxDailyLossUsd), usedPct, usedPct > 70 ? 'danger' : 'warn'),
          el('div', { style: { height: '10px' } }),
          riskBar('Open risk', fmt.cash(risk.openRiskUsd), fmt.cash(risk.maxDailyLossUsd), openPct, openPct > 60 ? 'danger' : 'ok'),
          el('div', { style: { height: '10px' } }),
          riskBar('Max drawdown', t.maxDrawdownPct + '%', '10%', ddPct, ddPct > 50 ? 'danger' : 'ok'),
          el('div', { style: { height: '12px' } }),
          el('div', { class: 'grid g3', style: { gap: '10px' } },
            mini('Risk / trade', fmt.cash(risk.riskPerTradeUsd)),
            mini('Open positions', risk.openPositions),
            mini('Streak', (t.streak > 0 ? '+' : '') + t.streak))));
    }
    function riskBar(label, val, max, pct, cls) {
      return el('div', {},
        el('div', { class: 'row between', style: { fontSize: '12px', marginBottom: '6px' } },
          el('span', { class: 'muted', text: label }), el('span', { class: 'num', text: `${val} / ${max}` })),
        el('div', { class: 'bar ' + cls }, el('i', { style: { width: pct + '%' } })));
    }
    const mini = (l, v) => el('div', {}, el('div', { class: 'k-label', text: l }), el('div', { class: 'num', style: { fontSize: '15px', marginTop: '4px' }, text: v }));

    const riskCard = el('div', { class: 'card pad0' });

    /* ------------------------------------------------------------ charts */
    const equityCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Equity curve' }), el('div', { class: 'card-sub', text: 'Realised balance after every closed trade' })),
        el('div', { class: 'seg', id: 'eqRange' },
          el('button', { class: 'active', text: 'All' }), el('button', { text: '30d' }), el('button', { text: '7d' }))),
      el('div', { id: 'equityChart', style: { height: '236px' } }));

    const dailyCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Daily P&L' }), el('div', { class: 'card-sub', text: 'Green days vs red days — the process scoreboard' })),
        el('div', { class: 'pill', id: 'greenDays', text: '—' })),
      el('div', { id: 'dailyChart', style: { height: '236px' } }));

    midRow.append(equityCard, dailyCard);
    lower.append(riskCard, await this.sessionCard());

    /* ------------------------------------------- open positions + tables */
    const openCard = el('div', { class: 'card pad0' });
    const recentCard = el('div', { class: 'card pad0' });
    wrap.append(el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)' } }, openCard, recentCard));

    /* ----------------------------------------------------------- loaders */
    let chartRange = 'all';
    let equityChart = null, dailyChart = null;

    function drawEquity(curve) {
      const node = document.getElementById('equityChart');
      if (!node) return;
      equityChart?.remove();
      const pts = chartRange === 'all' ? curve : curve.slice(-Math.max(2, chartRange === '30d' ? Math.min(curve.length, curve.length) : curve.length));
      const filtered = chartRange === 'all' ? pts : chartRange === '30d' ? pts.slice(-30) : pts.slice(-7);
      const c = LightweightCharts.createChart(node, {
        height: 236, width: node.clientWidth, autoSize: false,
        layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8C92A4', fontSize: 10, fontFamily: "'SFMono-Regular',Menlo,monospace" },
        grid: { vertLines: { color: 'rgba(35,40,56,.5)' }, horzLines: { color: 'rgba(35,40,56,.5)' } },
        rightPriceScale: { borderColor: '#232838' }, timeScale: { borderColor: '#232838', timeVisible: false },
        crosshair: { mode: 0, vertLine: { color: 'rgba(201,169,76,.4)', labelBackgroundColor: '#C9A94C' }, horzLine: { color: 'rgba(201,169,76,.4)', labelBackgroundColor: '#C9A94C' } },
        handleScale: false,
      });
      const s = c.addAreaSeries({ lineColor: '#C9A94C', topColor: 'rgba(201,169,76,.30)', bottomColor: 'rgba(201,169,76,0)', lineWidth: 2, priceLineVisible: false });
      const data = ETVChart.sanitize(filtered.map((p) => ({
        time: Math.floor(new Date(p.t.replace(' ', 'T') + (p.t.includes('T') ? '' : 'Z')).getTime() / 1000),
        value: p.equity,
      })));
      s.setData(data);
      c.timeScale().fitContent();
      equityChart = c;
    }

    function drawDaily(daily) {
      const node = document.getElementById('dailyChart');
      if (!node) return;
      dailyChart?.remove();
      const c = LightweightCharts.createChart(node, {
        height: 236, width: node.clientWidth,
        layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8C92A4', fontSize: 10, fontFamily: "'SFMono-Regular',Menlo,monospace" },
        grid: { vertLines: { color: 'rgba(35,40,56,.5)' }, horzLines: { color: 'rgba(35,40,56,.5)' } },
        rightPriceScale: { borderColor: '#232838' }, timeScale: { borderColor: '#232838', timeVisible: false },
        crosshair: { mode: 0 }, handleScale: false,
      });
      const bars = ETVChart.sanitize(daily.map((d) => ({ time: Math.floor(new Date(d.day + 'T00:00:00Z').getTime() / 1000), value: d.pnl })));
      const s = c.addHistogramSeries({ priceFormat: { type: 'price', precision: 0, minMove: 1 }, priceLineVisible: false });
      s.setData(bars.map((d) => ({ ...d, color: d.value >= 0 ? 'rgba(76,175,125,.75)' : 'rgba(217,100,86,.75)' })));
      const zero = c.addLineSeries({ color: 'rgba(140,146,164,.45)', lineWidth: 1, lineStyle: 2, priceLineVisible: false, lastValueVisible: false });
      zero.setData(bars.map((d) => ({ time: d.time, value: 0 })));
      c.timeScale().fitContent();
      dailyChart = c;
      const greens = daily.filter((d) => d.pnl > 0).length;
      document.getElementById('greenDays').textContent = `${greens} green / ${daily.length - greens} red`;
    }

    function paintOpen(stats) {
      openCard.innerHTML = '';
      const rows = stats.openTrades;
      openCard.append(
        el('div', { class: 'card-head' },
          el('div', {}, el('div', { class: 'card-title', text: 'Live exposure' }),
            el('div', { class: 'card-sub', text: 'Floating P&L updates with every tick' })),
          el('span', { class: 'pill ' + (stats.totals.floating >= 0 ? 'green' : 'red'), text: `${rows.length} open · ${fmt.money(stats.totals.floating)}` })));
      if (!rows.length) { openCard.append(el('div', { class: 'empty', text: 'Flat. No open positions on this account.' })); return; }
      const tb = el('tbody');
      const t = el('table', {}, el('thead', {}, el('tr', {}, ...['Symbol', 'Side', 'Qty', 'Entry', 'Last', 'SL / TP', 'Floating', ''].map((h) => el('th', { text: h })))), tb);
      rows.forEach((p) => {
        const meta = ETV.state.symbolMap[p.symbol] || {};
        tb.append(el('tr', {},
          el('td', {}, el('b', { text: p.symbol }), el('div', { class: 'faint', style: { fontSize: '11px' }, text: meta.name || '' })),
          el('td', {}, el('span', { class: 'pill ' + (p.side === 'buy' ? 'green' : 'red'), text: p.side.toUpperCase() })),
          el('td', { class: 'num', text: p.qty }),
          el('td', { class: 'num', text: fmt.price(p.symbol, p.entry_price) }),
          el('td', { class: 'num', html: `<span class="live-dot"></span>${fmt.price(p.symbol, p.currentPrice)}` }),
          el('td', { class: 'num faint', text: `${fmt.price(p.symbol, p.stop_loss)} / ${fmt.price(p.symbol, p.take_profit)}` }),
          el('td', { class: 'num ' + (p.floating >= 0 ? 'up' : 'down'), text: fmt.money(p.floating) }),
          el('td', {}, el('div', { class: 'row' },
            el('button', { class: 'btn btn-xs', text: 'Chart', onclick: () => ETV.openTerminal(p.symbol, '15m') }),
            el('button', { class: 'btn btn-xs', text: 'Close', onclick: () => ETV.closeTradeModal(p) })))));
      });
      openCard.append(t);
    }

    async function paintRecent() {
      const trades = await ETV.api('/trades?status=closed&limit=9');
      recentCard.innerHTML = '';
      recentCard.append(el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Latest closes' }), el('div', { class: 'card-sub', text: 'With the note you recorded at the time' })),
        el('button', { class: 'btn btn-xs', text: 'All trades', onclick: () => ETV.go('trades') })));
      if (!trades.length) { recentCard.append(el('div', { class: 'empty', text: 'No closed trades yet.' })); return; }
      trades.forEach((t) => {
        recentCard.append(el('div', { style: { padding: '11px 16px', borderTop: '1px solid var(--line-soft)' } },
          el('div', { class: 'row between' },
            el('div', { class: 'row', style: { gap: '8px' } },
              el('span', { class: 'pill ' + (t.side === 'buy' ? 'green' : 'red'), text: t.side.toUpperCase() }),
              el('b', { style: { fontSize: '13px' }, text: t.symbol }),
              el('span', { class: 'faint', style: { fontSize: '11.5px' }, text: `${t.r_multiple != null ? (t.r_multiple > 0 ? '+' : '') + t.r_multiple + 'R' : ''} · ${fmt.timeAgo(t.closed_at)}` })),
            el('span', { class: 'num ' + (t.pnl >= 0 ? 'up' : 'down'), text: fmt.money(t.pnl) })),
          t.notes ? el('div', { class: 'faint', style: { fontSize: '12px', marginTop: '5px', lineHeight: '1.5' }, text: t.notes.slice(0, 130) + (t.notes.length > 130 ? '…' : '') }) : null));
      });
    }

    /* ------------------------------------------------------------ initial */
    const [stats, risk] = await Promise.all([ETV.api('/trades/stats'), ETV.api('/risk')]);
    paintKpis(stats); paintRisk(risk, stats); paintOpen(stats);
    drawEquity(stats.equityCurve); drawDaily(stats.dailyPnl);
    await paintRecent();

    document.querySelectorAll('#eqRange button').forEach((b) => b.addEventListener('click', () => {
      document.querySelectorAll('#eqRange button').forEach((x) => x.classList.remove('active'));
      b.classList.add('active');
      chartRange = b.textContent.trim().toLowerCase().replace('all', 'all');
      drawEquity(stats.equityCurve);
    }));

    // live repaint hooks — keep the dashboard breathing with the market
    const offT = ETV.on('quotes', async () => {
      const src = document.getElementById('dashSource');
      if (src) src.textContent = 'feed: ' + (ETV.state.live.source || '—');
    });
    const offP = ETV.on('positions', () => { ETV.api('/trades/stats').then((s) => { paintOpen(s); paintKpis(s); }).catch(() => {}); });
    const offA = ETV.on('alert', () => swapSession(stats, risk));
    const offTick = ETV.on('tick', () => swapSession(stats, risk));
    let n = 0;
    function swapSession(s, r) { if (++n % 3 === 0) ETV.api('/trades/stats').then((ns) => paintKpis(ns)).catch(() => {}); }
    host.addEventListener('etv:leave', () => { offT(); offP(); offA(); offTick(); try { equityChart?.remove(); } catch {} try { dailyChart?.remove(); } catch {} }, { once: true });
  },

  async sessionCard() {
    const { el } = ETV;
    const card = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Sessions & alerts' }), el('div', { class: 'card-sub', text: 'Where liquidity is right now' }))),
      el('div', { class: 'card-body', id: 'sessionBody' }));
    try {
      const [sess, cal, alerts] = await Promise.all([ETV.api('/market/sessions'), ETV.api('/market/calendar'), ETV.api('/market/alerts')]);
      const body = card.querySelector('#sessionBody');
      body.innerHTML = '';
      (sess.sessions || []).forEach((s) => {
        body.append(el('div', { class: 'stat-line' },
          el('span', {}, el('span', { style: { display: 'inline-block', width: '7px', height: '7px', borderRadius: '50%', background: s.open ? '#4CAF7D' : '#333B50', marginRight: '8px' } }), s.name),
          el('b', { class: s.open ? 'up' : 'faint', text: s.open ? 'open' : 'closed' })));
      });
      const next = (cal.events || []).filter((e) => new Date(e.time) > new Date()).slice(0, 3);
      body.append(el('div', { class: 'eyebrow', style: { marginTop: '14px' }, text: 'Next events' }));
      if (!next.length) body.append(el('div', { class: 'faint', style: { fontSize: '12px' }, text: 'No scheduled events in the window.' }));
      next.forEach((e) => body.append(el('div', { class: 'cal-item' },
        el('div', { class: 'impact ' + e.impact }),
        el('div', { style: { flex: '1' } },
          el('div', { style: { fontSize: '12.5px' }, text: e.title }),
          el('div', { class: 'faint', style: { fontSize: '11px' }, text: `${e.country} · ${ETV.fmt.day(e.time)} ${ETV.fmt.clock(e.time)} UTC` })))));
      body.append(el('div', { class: 'eyebrow', style: { marginTop: '14px' }, text: 'Active alerts' }));
      if (!alerts.length) body.append(el('div', { class: 'faint', style: { fontSize: '12px' }, text: 'No alerts armed. Add one from the terminal.' }));
      alerts.filter((a) => a.status === 'active').slice(0, 4).forEach((a) => body.append(el('div', { class: 'stat-line' },
        el('span', {}, `${a.symbol} ${a.condition}`),
        el('b', { class: 'num', text: ETV.fmt.price(a.symbol, a.price) }))));
    } catch (e) { card.querySelector('#sessionBody').textContent = 'Session data unavailable.'; }
    return card;
  },
};
