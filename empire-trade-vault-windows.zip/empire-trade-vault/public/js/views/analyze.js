/* ═══════════════════════════════════════════════════════════════════════
   VIEW · Analyze — edge statistics: R distribution, breakdowns, calendar
   ═══════════════════════════════════════════════════════════════════════ */
ETV.views = ETV.views || {};

ETV.views.analyze = {
  title: 'Analyze',
  async render(host) {
    const { el, fmt } = ETV;
    host.innerHTML = '';
    host.append(el('div', { class: 'page-head' },
      el('div', {}, el('div', { class: 'eyebrow', text: 'Performance' }), el('div', { class: 'page-title', text: 'Edge analytics' })),
      el('div', { class: 'row' }, el('span', { class: 'pill', id: 'anRange', text: 'all closed trades' }))));

    const [stats, closed] = await Promise.all([ETV.api('/trades/stats'), ETV.api('/trades?status=closed&limit=1000')]);
    const t = stats.totals;

    const kpis = el('div', { class: 'grid g4', style: { marginBottom: '14px' } });
    const kpi = (l, v, s, cls = '') => el('div', { class: 'kpi' }, el('div', { class: 'k-label', text: l }), el('div', { class: 'k-val ' + cls, text: v }), el('div', { class: 'k-sub', text: s }));
    kpis.append(
      kpi('Win rate', t.winRate + '%', `${t.wins}W / ${t.losses}L`),
      kpi('Profit factor', t.profitFactor, 'gross win ÷ gross loss', t.profitFactor >= 1 ? 'up' : 'down'),
      kpi('Expectancy', fmt.money(t.expectancy), 'average result per trade', t.expectancy >= 0 ? 'up' : 'down'),
      kpi('Max drawdown', t.maxDrawdownPct + '%', `${fmt.cash(t.equity)} equity` , t.maxDrawdownPct > 10 ? 'down' : 'up'));
    host.append(kpis);

    /* ------------------------------------------------------- R histogram */
    const rCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'R-multiple distribution' }), el('div', { class: 'card-sub', text: 'Where your results actually cluster — the shape of the edge' })),
        el('span', { class: 'pill ' + (t.avgR >= 0 ? 'green' : 'red'), text: `avg ${t.avgR}R` })),
      el('div', { id: 'rChart', style: { height: '250px' } }));
    const symCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Performance by market' }), el('div', { class: 'card-sub', text: 'Which instruments pay you and which ones tax you' }))),
      el('div', { id: 'symBody', style: { padding: '12px 16px' } }));
    host.append(el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)', marginBottom: '14px' } }, rCard, symCard));

    /* ---------------------------------------------------- calendar + tags */
    const calCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' },
        el('div', {}, el('div', { class: 'card-title', text: 'Daily P&L calendar' }), el('div', { class: 'card-sub', text: 'Last 45 trading sessions' })),
        el('span', { class: 'pill', id: 'calSummary', text: '—' })),
      el('div', { class: 'card-body' }, el('div', { class: 'heat', id: 'calHeat' })));
    const tagCard = el('div', { class: 'card pad0' },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Tags & behaviours' }), el('div', { class: 'card-sub', text: 'Cost of every habit you label' }))),
      el('div', { id: 'tagBody', style: { padding: '12px 16px' } }));
    host.append(el('div', { class: 'grid', style: { gridTemplateColumns: 'minmax(0,1.3fr) minmax(0,1fr)' } }, calCard, tagCard));

    const habits = el('div', { class: 'card pad0', style: { marginTop: '14px' } },
      el('div', { class: 'card-head' }, el('div', {}, el('div', { class: 'card-title', text: 'Execution quality' }), el('div', { class: 'card-sub', text: 'Emotion, confidence and playbook follow-through' }))),
      el('div', { id: 'habitBody', style: { padding: '12px 16px' } }));
    host.append(habits);

    /* --------------------------------------------------------- R chart */
    const rNode = document.getElementById('rChart');
    const buckets = {};
    closed.forEach((c) => {
      if (c.r_multiple == null) return;
      const b = c.r_multiple >= 3 ? '3R+' : c.r_multiple >= 2 ? '2-3R' : c.r_multiple >= 1 ? '1-2R'
        : c.r_multiple >= 0 ? '0-1R' : c.r_multiple >= -1 ? '-1-0R' : c.r_multiple >= -2 ? '-2--1R' : '<-2R';
      buckets[b] = buckets[b] || { n: 0, sum: 0 };
      buckets[b].n++; buckets[b].sum += c.pnl;
    });
    const order = ['<-2R', '-2--1R', '-1-0R', '0-1R', '1-2R', '2-3R', '3R+'];
    const labels = { '<-2R': '< -2R', '-2--1R': '-2 → -1R', '-1-0R': '-1 → 0R', '0-1R': '0 → 1R', '1-2R': '1 → 2R', '2-3R': '2 → 3R', '3R+': '> 3R' };
    const hist = LightweightCharts.createChart(rNode, {
      height: 250, width: rNode.clientWidth,
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8C92A4', fontSize: 10, fontFamily: "'SFMono-Regular',Menlo,monospace" },
      grid: { vertLines: { color: 'rgba(35,40,56,.5)' }, horzLines: { color: 'rgba(35,40,56,.5)' } },
      rightPriceScale: { borderColor: '#232838' },
      timeScale: { borderColor: '#232838', visible: false },
      crosshair: { mode: 0 }, handleScale: false,
    });
    const hs = hist.addHistogramSeries({ priceLineVisible: false, priceFormat: { type: 'volume' } });
    hs.setData(order.map((k, i) => ({ time: i + 1, value: buckets[k]?.n || 0, color: k.includes('-') && !k.startsWith('0') ? 'rgba(217,100,86,.75)' : 'rgba(76,175,125,.75)' })));
    hist.timeScale().fitContent();

    /* ---------------------------------------------------- symbol & tag bars */
    function bars(node, rows, { valueKey = 'pnl', labelKey = 'symbol', extra }) {
      node.innerHTML = '';
      const max = Math.max(1, ...rows.map((r) => Math.abs(r[valueKey])));
      rows.forEach((r) => {
        const v = r[valueKey];
        const pct = (Math.abs(v) / max) * 50;
        node.append(el('div', { class: 'rbar' },
          el('div', { class: 'rl', text: r[labelKey] + (extra ? ` · ${extra(r)}` : '') }),
          el('div', { class: 'rt' },
            el('i', { style: { left: v >= 0 ? '50%' : `${50 - pct}%`, width: pct + '%', background: v >= 0 ? 'linear-gradient(90deg,#3B9A6C,#4CAF7D)' : 'linear-gradient(90deg,#C35243,#D96456)' } })),
          el('div', { class: 'rv ' + (v >= 0 ? 'up' : 'down'), text: fmt.money(v, 0) })));
      });
      if (!rows.length) node.append(el('div', { class: 'faint', style: { fontSize: '12.5px' }, text: 'Not enough data yet.' }));
    }
    bars(document.getElementById('symBody'), stats.bySymbol.slice(0, 8), { extra: (r) => `${r.trades}t · ${Math.round((r.wins / r.trades) * 100)}%` });
    bars(document.getElementById('tagBody'), stats.byTag.slice(0, 9), { labelKey: 'tag', extra: (r) => `${r.trades}t` });

    /* -------------------------------------------------------- heat calendar */
    const heat = document.getElementById('calHeat');
    const daily = stats.dailyPnl.slice(-45);
    const maxAbs = Math.max(1, ...daily.map((d) => Math.abs(d.pnl)));
    daily.forEach((d) => {
      const intensity = Math.min(1, Math.abs(d.pnl) / maxAbs);
      const col = d.pnl >= 0 ? `rgba(76,175,125,${0.14 + intensity * 0.6})` : `rgba(217,100,86,${0.14 + intensity * 0.6})`;
      heat.append(el('div', { class: 'hcell', style: { background: col, borderColor: 'transparent' }, title: `${d.day} · ${fmt.money(d.pnl)}` },
        el('div', { class: 'hd', text: fmt.short(d.day) }),
        el('div', { class: 'hv', text: (d.pnl >= 0 ? '+' : '') + Math.round(d.pnl) })));
    });
    const green = daily.filter((d) => d.pnl > 0).length;
    document.getElementById('calSummary').textContent = `${green} green / ${daily.length - green} red`;
    document.getElementById('anRange').textContent = `${closed.length} closed trades`;

    /* ------------------------------------------------------------ habits */
    const byEmotion = {};
    closed.forEach((c) => {
      if (!c.emotion) return;
      byEmotion[c.emotion] = byEmotion[c.emotion] || { label: c.emotion, trades: 0, pnl: 0, wins: 0 };
      byEmotion[c.emotion].trades++; byEmotion[c.emotion].pnl += c.pnl;
      if (c.pnl > 0) byEmotion[c.emotion].wins++;
    });
    const hb = document.getElementById('habitBody');
    hb.innerHTML = '';
    const withStops = closed.filter((c) => c.stop_loss).length;
    const withNotes = closed.filter((c) => (c.notes || '').length > 8).length;
    const withPlaybook = closed.filter((c) => c.playbook_id).length;
    hb.append(el('div', { class: 'grid g3', style: { gap: '12px', marginBottom: '14px' } },
      el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '10px', padding: '12px' } },
        el('div', { class: 'k-label', text: 'Trades with a stop attached' }),
        el('div', { class: 'num', style: { fontSize: '17px', marginTop: '5px' }, text: closed.length ? Math.round((withStops / closed.length) * 100) + '%' : '—' })),
      el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '10px', padding: '12px' } },
        el('div', { class: 'k-label', text: 'Trades reviewed in writing' }),
        el('div', { class: 'num', style: { fontSize: '17px', marginTop: '5px' }, text: closed.length ? Math.round((withNotes / closed.length) * 100) + '%' : '—' })),
      el('div', { style: { background: 'var(--surface2)', border: '1px solid var(--line)', borderRadius: '10px', padding: '12px' } },
        el('div', { class: 'k-label', text: 'Trades tied to a playbook' }),
        el('div', { class: 'num', style: { fontSize: '17px', marginTop: '5px' }, text: closed.length ? Math.round((withPlaybook / closed.length) * 100) + '%' : '—' }))));
    hb.append(el('div', { class: 'eyebrow', text: 'Emotion at entry' }));
    bars(hb, Object.values(byEmotion).sort((a, b) => b.trades - a.trades), { labelKey: 'label', extra: (r) => `${r.trades}t · ${Math.round((r.wins / r.trades) * 100)}% win` });
  },
};
