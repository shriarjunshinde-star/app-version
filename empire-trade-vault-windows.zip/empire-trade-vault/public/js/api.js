/* ═══════════════════════════════════════════════════════════════════════
   ETV core: API client, state store, helpers, toasts, modals, sockets
   ═══════════════════════════════════════════════════════════════════════ */
window.ETV = (() => {
  const listeners = {};

  /**
   * localStorage can throw (private mode, sandboxed iframe, blocked cookies).
   * Never let that break the app — fall back to an in-memory store.
   */
  const store = (() => {
    let ok = true;
    try { const k = '__etv_probe__'; window.localStorage.setItem(k, '1'); window.localStorage.removeItem(k); }
    catch { ok = false; }
    const mem = new Map();
    return {
      available: ok,
      get(k) { try { return ok ? window.localStorage.getItem(k) : (mem.get(k) ?? null); } catch { return mem.get(k) ?? null; } },
      set(k, v) { try { ok ? window.localStorage.setItem(k, v) : mem.set(k, v); } catch { mem.set(k, v); } },
      del(k) { try { ok ? window.localStorage.removeItem(k) : mem.delete(k); } catch { mem.delete(k); } },
    };
  })();
  const state = {
    token: store.get('etv_token') || '',
    user: null,
    accounts: [],
    symbols: [],
    symbolMap: {},
    quotes: {},
    timeframes: ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w'],
    tfLabels: {},
    chart: { symbol: store.get('etv_symbol') || 'BTCUSD', tf: store.get('etv_tf') || '1h' },
    socket: null,
    live: { connected: false, source: '—', lastTick: null },
    feed: null,
    alerts: [],
    notifications: [],
    typing: {},
    emojis: ['\u{1F525}', '\u{1F680}', '\u{1F44D}', '\u{1F440}', '\u{1F4C8}', '\u{1F4C9}', '\u2705', '\u2764\uFE0F'],
  };

  /* ------------------------------------------------------------------ api */
  async function api(path, { method = 'GET', body } = {}) {
    let res;
    try {
      res = await fetch('/api' + path, {
      method,
        headers: {
          'Content-Type': 'application/json',
          ...(state.token ? { Authorization: 'Bearer ' + state.token } : {}),
        },
        body: body ? JSON.stringify(body) : undefined,
      });
    } catch (netErr) {
      const e = new Error('Cannot reach the server — is it running? (./start.sh)');
      e.offline = true;
      throw e;
    }
    let data = null;
    try { data = await res.json(); } catch { data = {}; }
    if (!res.ok) {
      if (res.status === 401 && state.user) { logout(); }
      throw new Error(data.error || ('HTTP ' + res.status));
    }
    return data;
  }

  function setToken(t) {
    state.token = t || '';
    if (t) store.set('etv_token', t); else store.del('etv_token');
  }
  function logout() {
    setToken('');
    if (state.socket) { state.socket.disconnect(); state.socket = null; }
    location.reload();
  }

  /* ---------------------------------------------------------------- utils */
  const fmt = {
    money: (v, d = 2) => (v == null ? '—' : (v < 0 ? '-' : v > 0 ? '+' : '') + '$' + Math.abs(+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })),
    cash: (v, d = 2) => (v == null ? '—' : '$' + (+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })),
    pct: (v, d = 2) => (v == null ? '—' : (v > 0 ? '+' : '') + (+v).toFixed(d) + '%'),
    num: (v, d = 2) => (v == null || v === '' ? '—' : (+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d })),
    price(symbol, v) {
      const meta = state.symbolMap[symbol];
      const d = meta?.digits ?? 2;
      return v == null ? '—' : (+v).toLocaleString('en-US', { minimumFractionDigits: d, maximumFractionDigits: d });
    },
    timeAgo(iso) {
      if (!iso) return '';
      const t = new Date((iso.includes('T') ? iso : iso.replace(' ', 'T') + 'Z')).getTime();
      const s = Math.max(1, Math.floor((Date.now() - t) / 1000));
      if (s < 60) return s + 's ago';
      if (s < 3600) return Math.floor(s / 60) + 'm ago';
      if (s < 86400) return Math.floor(s / 3600) + 'h ago';
      if (s < 604800) return Math.floor(s / 86400) + 'd ago';
      return new Date(t).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    },
    clock(iso) { return new Date(iso).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }); },
    day(iso) { return new Date((iso || '').length <= 10 ? iso + 'T00:00:00Z' : iso).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }); },
    short: (iso) => (iso && iso.length <= 10 ? iso : new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
  };

  function el(tag, attrs = {}, ...children) {
    const node = document.createElement(tag);
    Object.entries(attrs || {}).forEach(([k, v]) => {
      if (v == null || v === false) return;
      if (k === 'class') node.className = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'dataset') Object.assign(node.dataset, v);
      else node.setAttribute(k, v);
    });
    children.flat().forEach((c) => c != null && node.append(c.nodeType ? c : document.createTextNode(String(c))));
    return node;
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const initials = (name) => (name || '?').split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  const colorFor = (id) => ['#C9A94C', '#4CAF7D', '#5AA2F0', '#D96456', '#A78BFA', '#22D3EE', '#F472B6', '#F59E0B'][Number(id || 0) % 8];
  const avatar = (user, size = 30) => el('div', {
    class: 'avatar', style: { width: size + 'px', height: size + 'px', background: user?.avatar_color || colorFor(user?.id), fontSize: (size * 0.42) + 'px' },
    title: user?.display_name || '',
  }, initials(user?.display_name || user?.username));

  /* ----------------------------------------------------------- tiny event */
  const on = (n, fn) => { (listeners[n] = listeners[n] || []).push(fn); return () => { listeners[n] = listeners[n].filter((f) => f !== fn); }; };
  const emit = (n, payload) => (listeners[n] || []).forEach((f) => { try { f(payload); } catch (e) { console.error(e); } });

  /* ------------------------------------------------------------- toasts */
  function toast(title, body = '', kind = '') {
    const host = document.getElementById('toastHost');
    if (!host) return;
    const node = el('div', { class: 'toast ' + kind },
      el('div', { class: 'tt', text: title }),
      body ? el('div', { class: 'tb', text: body }) : null);
    host.append(node);
    setTimeout(() => { node.style.transition = 'opacity .3s'; node.style.opacity = '0'; setTimeout(() => node.remove(), 320); }, kind === 'bad' ? 6000 : 4200);
  }

  /* ------------------------------------------------------------- modals */
  const modalStack = [];
  function modal({ title, body, footer, wide = false, onClose }) {
    const close = () => {
      wrap.remove();
      const i = modalStack.indexOf(close);
      if (i >= 0) modalStack.splice(i, 1);
      onClose?.();
    };
    const bd = el('div', { class: 'modal-bg', onclick: close });
    const content = el('div', { class: 'modal-body' }, ...(Array.isArray(body) ? body : [body]));
    const m = el('div', { class: 'modal' + (wide ? ' wide' : '') },
      el('div', { class: 'modal-head' },
        el('div', { class: 'modal-title', text: title }),
        el('button', { class: 'x-btn', onclick: close, html: '&times;' })),
      content,
      footer ? el('div', { class: 'modal-foot' }, ...(Array.isArray(footer) ? footer : [footer])) : null);
    const wrap = el('div', { style: { position: 'absolute', inset: '0' } }, bd, m);
    document.getElementById('modalHost').append(wrap);
    modalStack.push(close);
    return { close, el: m, body: content };
  }

  // Escape always dismisses the top-most dialog
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modalStack.length) modalStack[modalStack.length - 1]();
  });

  const confirmBox = (title, text, confirmLabel = 'Confirm') => new Promise((resolve) => {
    const m = modal({
      title,
      body: el('div', { style: { fontSize: '13.5px', color: 'var(--text-dim)', lineHeight: '1.6' }, text }),
      footer: [
        el('button', { class: 'btn btn-ghost', text: 'Cancel', onclick: () => { m.close(); resolve(false); } }),
        el('button', { class: 'btn btn-gold', text: confirmLabel, onclick: () => { m.close(); resolve(true); } }),
      ],
      onClose: () => resolve(false),
    });
  });

  /* ------------------------------------------------------------ sockets */
  function connect() {
    if (!state.token || state.socket) return;
    const socket = io({ auth: { token: state.token }, transports: ['websocket', 'polling'] });
    state.socket = socket;
    socket.on('connect', () => { state.live.connected = true; emit('live', state.live); });
    socket.on('disconnect', () => { state.live.connected = false; emit('live', state.live); });
    socket.on('market:tick', (payload) => {
      payload.quotes.forEach((q) => { state.quotes[q.symbol] = q; });
      state.live.lastTick = payload.ts;
      state.live.source = payload.quotes[0]?.source || 'live';
      state.live.sessions = payload.sessions;
      emit('tick', payload);
      emit('quotes');
    });
    socket.on('message', (m) => emit('message', m));
    socket.on('message:deleted', (m) => emit('message:deleted', m));
    socket.on('reaction', (r) => emit('reaction', r));
    socket.on('typing', (t) => emit('typing', t));
    socket.on('presence', (p) => emit('presence', p));
    socket.on('positions:update', (p) => emit('positions', p));
    socket.on('alert:triggered', (a) => { toast(`⚡ ${a.symbol} ${a.condition} ${a.price}`, `Last ${a.last}${a.note ? ' — ' + a.note : ''}`, 'good'); emit('alert', a); });
    socket.on('order:filled', (o) => { toast(`Limit filled · ${o.symbol}`, `${o.side.toUpperCase()} @ ${o.entry}`, 'good'); emit('order', o); });
    socket.on('dm:new', (m) => emit('dm:new', m));
    state.socket = socket;
  }

  /** Is the backend alive? Used by the auth screen and the settings page. */
  async function health() {
    try {
      const r = await fetch('/api/health', { cache: 'no-store' });
      if (!r.ok) return { ok: false, reason: 'HTTP ' + r.status };
      const j = await r.json();
      return { ok: true, ...j };
    } catch (e) { return { ok: false, reason: 'server unreachable' }; }
  }

  /* --------------------------------------------------------------- boot */
  async function boot() {
    const health = await fetch('/api/health').then((r) => r.json()).catch(() => null);
    if (health) state.live.source = health.engine.online ? 'live' : 'offline';
    const idx = await api('/market/symbols');
    state.symbols = idx.symbols;
    state.symbolMap = Object.fromEntries(idx.symbols.map((s) => [s.symbol, s]));
    idx.symbols.forEach((s) => { if (!state.quotes[s.symbol]) state.quotes[s.symbol] = s; });
    state.timeframes = (idx.timeframes || []).map((t) => (typeof t === 'string' ? t : t.key));
    state.tfLabels = Object.fromEntries((idx.timeframes || [])
      .filter((t) => typeof t !== 'string').map((t) => [t.key, t.label]));
    return idx;
  }

  return {
    api, state, fmt, el, esc, initials, avatar, colorFor, on, emit, toast, modal, confirm: confirmBox,
    connect, boot, setToken, logout, store, health,
    quote: (s) => state.quotes[s] || { symbol: s, price: null, changePct: 0, source: '—' },
    go: (view, params) => emit('navigate', { view, params }),
    openTerminal: (symbol, tf) => { if (symbol) state.chart.symbol = symbol; if (tf) state.chart.tf = tf; emit('navigate', { view: 'terminal' }); },
    setQuote: (q) => { state.quotes[q.symbol] = q; emit('quotes'); },
  };
})();
