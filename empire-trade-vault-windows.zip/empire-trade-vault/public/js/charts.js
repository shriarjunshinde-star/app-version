/* ═══════════════════════════════════════════════════════════════════════
   Chart engine — wrapper around TradingView Lightweight Charts v4
   candlestick / bar / line / area / heikin-ashi series, indicators,
   drawing tools (trend line, level, measure) and shareable snapshots.
   ═══════════════════════════════════════════════════════════════════════ */
window.ETVChart = (() => {
  const LC = window.LightweightCharts;
  const THEME = {
    layout: { background: { type: 'solid', color: 'transparent' }, textColor: '#8C92A4', fontSize: 11, fontFamily: "'SFMono-Regular',Menlo,Consolas,monospace" },
    grid: { vertLines: { color: 'rgba(35,40,56,.55)' }, horzLines: { color: 'rgba(35,40,56,.55)' } },
    rightPriceScale: { borderColor: '#232838', scaleMargins: { top: 0.08, bottom: 0.24 } },
    timeScale: { borderColor: '#232838', timeVisible: true, secondsVisible: false, rightOffset: 4 },
    crosshair: {
      mode: 0,
      vertLine: { color: 'rgba(201,169,76,.5)', width: 1, style: 2, labelBackgroundColor: '#C9A94C' },
      horzLine: { color: 'rgba(201,169,76,.5)', width: 1, style: 2, labelBackgroundColor: '#C9A94C' },
    },
    handleScale: { axisPressedMouseMove: { time: true, price: false } },
    autoSize: false,
  };
  const COLORS = { up: '#4CAF7D', down: '#D96456', ema20: '#5AA2F0', ema50: '#C9A94C', ema200: '#A78BFA', bb: '#A78BFA', vwap: '#22D3EE' };
  const panes = new Set();

  if (!LC) console.warn('[charts] lightweight-charts failed to load');

  function toHeikinAshi(candles) {
    const out = [];
    let prev = null;
    candles.forEach((c) => {
      const close = (c.open + c.high + c.low + c.close) / 4;
      const open = prev ? (prev.open + prev.close) / 2 : (c.open + c.close) / 2;
      out.push({ time: c.time, open, high: Math.max(c.high, open, close), low: Math.min(c.low, open, close), close });
      prev = out[out.length - 1];
    });
    return out;
  }

  class ChartPane {
    constructor(container, opts = {}) {
      this.container = container;
      this.opts = Object.assign({ symbol: 'BTCUSD', tf: '1h', height: 452, mini: false, interactive: true, volume: true }, opts);
      this.indicators = Object.assign({ volume: true, ema20: true, ema50: true, ema200: false, bb: false, vwap: false }, opts.indicators || {});
      this.seriesType = opts.seriesType || 'candles';
      this.candles = [];
      this.drawings = { lines: [], trend: [], marks: [] };
      this.tool = 'cursor';
      this.pendingPoint = null;
      this.build();
      panes.add(this);
    }

    build() {
      const meta = ETV.state.symbolMap[this.opts.symbol] || { digits: 2 };
      this.digits = meta.digits ?? 2;
      this.chart = LC.createChart(this.container, Object.assign({}, THEME, {
        height: this.opts.height,
        width: this.container.clientWidth || 600,
        handleScroll: this.opts.interactive,
        handleScale: this.opts.interactive,
        timeScale: Object.assign({}, THEME.timeScale, { visible: !this.opts.mini, timeVisible: !this.opts.mini }),
        rightPriceScale: Object.assign({}, THEME.rightPriceScale, { visible: !this.opts.mini }),
        crosshair: Object.assign({}, THEME.crosshair, { horzLine: Object.assign({}, THEME.crosshair.horzLine, { visible: !this.opts.mini }) }),
        localization: { priceFormatter: (p) => p.toFixed(this.digits) },
      }));
      if (this.opts.mini) { const ps = this.chart.priceScale('right'); ps.applyOptions({ visible: false }); }
      this.mainSeries = this.addMainSeries();
      this.volumeSeries = this.chart.addHistogramSeries({ priceFormat: { type: 'volume' }, priceScaleId: 'vol', color: 'rgba(140,146,164,.35)' });
      this.chart.priceScale('vol').applyOptions({ scaleMargins: { top: 0.84, bottom: 0 }, visible: false });
      this.overlays = {};
      this.legend = null;
      if (this.opts.interactive) this.attachInteractions();
      this.ro = new ResizeObserver(() => this.resize());
      this.ro.observe(this.container);
      return this;
    }

    addMainSeries() {
      const common = { priceLineVisible: !this.opts.mini, lastValueVisible: !this.opts.mini };
      switch (this.seriesType) {
        case 'bar':
          return this.chart.addBarSeries({ upColor: COLORS.up, downColor: COLORS.down, thinBars: true, ...common });
        case 'line':
          return this.chart.addLineSeries({ color: '#C9A94C', lineWidth: 2, priceLineVisible: true, ...common });
        case 'area':
          return this.chart.addAreaSeries({ lineColor: '#C9A94C', topColor: 'rgba(201,169,76,.35)', bottomColor: 'rgba(201,169,76,0)', lineWidth: 2, ...common });
        default:
          return this.chart.addCandlestickSeries({
            upColor: COLORS.up, downColor: COLORS.down, borderVisible: false,
            wickUpColor: COLORS.up, wickDownColor: COLORS.down, ...common,
          });
      }
    }

    setSeriesType(type) {
      if (this.destroyed || type === this.seriesType) return;
      this.seriesType = type;
      this.chart.removeSeries(this.mainSeries);
      this.mainSeries = this.addMainSeries();
      this.render();
    }

    resize() {
      if (this.destroyed) return;
      const w = this.container.clientWidth;
      if (w) this.chart.applyOptions({ width: w, height: this.opts.height });
      if (this.legend) this.legend.style.maxWidth = Math.max(120, w - 90) + 'px';
    }

    async load(symbol, tf, attempt = 0) {
      if (this.destroyed) return [];
      if (symbol) this.opts.symbol = symbol;
      if (tf) this.opts.tf = tf;
      const meta = ETV.state.symbolMap[this.opts.symbol];
      this.digits = meta?.digits ?? 2;
      this.chart.applyOptions({
        localization: { priceFormatter: (p) => p.toFixed(this.digits) },
        timeScale: { timeVisible: this.opts.tf !== '1d' && this.opts.tf !== '1w' },
      });
      try {
        const res = await ETV.api(`/market/candles?symbol=${this.opts.symbol}&tf=${this.opts.tf}&limit=420`);
        this.candles = res.candles;
        this.source = res.source;
        this.indicatorsData = null;
        if (!this.opts.mini) {
          ETV.api(`/market/indicators?symbol=${this.opts.symbol}&tf=${this.opts.tf}`).then((p) => { this.indicatorPack = p; this.render(); }).catch(() => {});
        }
      } catch (e) {
        if (attempt < 2 && !this.destroyed) {           // transient network hiccup: retry quietly
          await new Promise((r) => setTimeout(r, 700));
          if (!this.destroyed) return this.load(this.opts.symbol, this.opts.tf, attempt + 1);
        }
        this.candles = [];
        if (!this.destroyed) ETV.toast('Chart unavailable', e.message, 'bad');
      }
      this.render();
      return this.candles;
    }

    setData(candles, { source } = {}) {
      this.candles = candles || [];
      this.source = source || 'shared';
      this.render();
    }

    render() {
      if (this.destroyed) return;
      if (!this.candles.length) return;
      const data = this.seriesType === 'heikin' ? toHeikinAshi(this.candles) : this.candles;
      if (this.seriesType === 'line' || this.seriesType === 'area') {
        this.mainSeries.setData(data.map((c) => ({ time: c.time, value: c.close })));
      } else {
        this.mainSeries.setData(data);
      }
      // volume
      if (this.opts.volume && this.volumeSeries) {
        this.volumeSeries.setData(this.candles.map((c) => ({
          time: c.time, value: c.volume || 0,
          color: (c.close >= c.open ? 'rgba(76,175,125,.35)' : 'rgba(217,100,86,.32)'),
        })));
      }
      this.applyIndicators();
      this.chart.timeScale().fitContent();
      this.chart.timeScale().applyOptions({ rightOffset: 5 });
    }

    /* ------------------------------------------------------- indicators */
    applyIndicators() {
      if (this.destroyed) return;
      const closes = this.candles.map((c) => c.close);
      const addLine = (key, values, color, width = 1.5) => {
        if (!this.overlays[key]) {
          this.overlays[key] = this.chart.addLineSeries({ color, lineWidth: width, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
        }
        this.overlays[key].setData(this.candles.map((c, i) => ({ time: c.time, value: values[i] })).filter((x) => x.value != null));
      };
      const remove = (key) => { if (this.overlays[key]) { this.chart.removeSeries(this.overlays[key]); delete this.overlays[key]; } };

      const ema = (p) => {
        const k = 2 / (p + 1); let prev = null;
        return closes.map((v, i) => { prev = i === 0 ? v : v * k + prev * (1 - k); return prev; });
      };
      this.indicators.ema20 ? addLine('ema20', ema(20), COLORS.ema20, 1.4) : remove('ema20');
      this.indicators.ema50 ? addLine('ema50', ema(50), COLORS.ema50, 1.4) : remove('ema50');
      this.indicators.ema200 ? addLine('ema200', ema(200), COLORS.ema200, 1.6) : remove('ema200');

      // Bollinger
      if (this.indicators.bb) {
        const p = 20, mult = 2, mid = [];
        let sum = 0;
        const up = [], dn = [];
        closes.forEach((v, i) => {
          sum += v; if (i >= p) sum -= closes[i - p];
          if (i >= p - 1) {
            const m = sum / p;
            const slice = closes.slice(i - p + 1, i + 1);
            const sd = Math.sqrt(slice.reduce((a, x) => a + (x - m) ** 2, 0) / p);
            mid.push(m); up.push(m + mult * sd); dn.push(m - mult * sd);
          } else { mid.push(null); up.push(null); dn.push(null); }
        });
        addLine('bbUp', up, 'rgba(167,139,250,.55)', 1);
        addLine('bbDn', dn, 'rgba(167,139,250,.55)', 1);
        addLine('bbMid', mid, 'rgba(167,139,250,.28)', 1);
      } else { ['bbUp', 'bbDn', 'bbMid'].forEach(remove); }

      // VWAP (session-anchored, UTC day)
      if (this.indicators.vwap) {
        let pv = 0, vv = 0, day = null;
        const vals = this.candles.map((c) => {
          const d = new Date(c.time * 1000).getUTCDate();
          if (d !== day) { day = d; pv = 0; vv = 0; }
          const tp = (c.high + c.low + c.close) / 3;
          pv += tp * (c.volume || 1); vv += (c.volume || 1);
          return pv / vv;
        });
        addLine('vwap', vals, '#22D3EE', 1.4);
      } else remove('vwap');
    }

    toggle(key) {
      if (this.destroyed) return false;
      this.indicators[key] = !this.indicators[key];
      if (key === 'volume') this.volumeSeries.applyOptions({ visible: this.indicators.volume });
      else this.applyIndicators();
      return this.indicators[key];
    }

    /* ---------------------------------------------------------- markers */
    setMarkers(markers = []) {
      this.markers = markers;
      if (this.mainSeries.setMarkers) this.mainSeries.setMarkers(markers);
    }

    /* ------------------------------------------------------- live update */
    applyTick(quote) {
      if (this.destroyed || !quote || quote.symbol !== this.opts.symbol || !this.candles.length) return false;
      const ms = { '1m': 60e3, '5m': 300e3, '15m': 900e3, '30m': 1800e3, '1h': 3600e3, '4h': 14400e3, '1d': 86400e3, '1w': 604800e3 }[this.opts.tf] || 3600e3;
      const bucket = Math.floor(Date.now() / ms) * Math.floor(ms / 1000);
      const last = this.candles[this.candles.length - 1];
      let bar;
      if (bucket <= last.time) { last.close = quote.price; last.high = Math.max(last.high, quote.price); last.low = Math.min(last.low, quote.price); bar = last; }
      else { bar = { time: bucket, open: quote.price, high: quote.price, low: quote.price, close: quote.price, volume: 0 }; this.candles.push(bar); }
      if (this.seriesType === 'line' || this.seriesType === 'area') this.mainSeries.update({ time: bar.time, value: bar.close });
      else this.mainSeries.update(bar);
      if (this.volumeSeries) this.volumeSeries.update({ time: bar.time, value: bar.volume || 0, color: bar.close >= bar.open ? 'rgba(76,175,125,.35)' : 'rgba(217,100,86,.32)' });
      return true;
    }

    /* ------------------------------------------------------- price lines */
    addPriceLine(price, { color = '#C9A94C', title = '', dashed = true, width = 1, id } = {}) {
      if (this.destroyed) return null;
      const line = this.mainSeries.createPriceLine({
        price, color, lineWidth: width, lineStyle: dashed ? 2 : 0, axisLabelVisible: true,
        title: title || price.toFixed(this.digits),
      });
      this.drawings.lines.push({ line, price, id });
      return line;
    }
    clearDrawings() {
      if (this.destroyed) return;
      this.drawings.lines.forEach((l) => { try { this.mainSeries.removePriceLine(l.line); } catch {} });
      this.drawings.trend.forEach((s) => { try { this.chart.removeSeries(s); } catch {} });
      this.drawings.lines = []; this.drawings.trend = [];
      if (this.mainSeries.setMarkers) this.mainSeries.setMarkers(this.markers || []);
      this.pendingPoint = null;
    }

    /* ------------------------------------------------------- interactions */
    attachInteractions() {
      this.tip = document.createElement('div');
      this.tip.className = 'measure-tip';
      this.container.parentElement.append(this.tip);
      this.chart.subscribeCrosshairMove((param) => {
        if (!param.time || !param.point) { if (this.onLegend) this.onLegend(null); return; }
        const bar = param.seriesData.get(this.mainSeries);
        const prev = this.candles.find((c) => c.time === param.time);
        if (this.onLegend) this.onLegend({ time: param.time, bar: bar || prev, point: param.point, price: this.mainSeries.coordinateToPrice(param.point.y) });
      });
      this.chart.subscribeClick((param) => {
        if (this.tool === 'cursor' || !param.point) return;
        const price = this.mainSeries.coordinateToPrice(param.point.y);
        const time = param.time || this.candles[this.candles.length - 1].time;
        if (this.tool === 'level') {
          this.addPriceLine(price, { color: '#C9A94C', title: 'level' });
          ETV.toast('Level added', `Horizontal line at ${price.toFixed(this.digits)}`);
        } else if (this.tool === 'trend' || this.tool === 'measure') {
          if (!this.pendingPoint) { this.pendingPoint = { time, price }; this.tip.style.display = 'block'; }
          else {
            const a = this.pendingPoint, b = { time, price };
            if (this.tool === 'trend') {
              const s = this.chart.addLineSeries({ color: '#E4C868', lineWidth: 1.6, lineStyle: 0, priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false });
              s.setData([{ time: a.time, value: a.price }, { time: b.time, value: b.price }]);
              this.drawings.trend.push(s);
            }
            const diff = b.price - a.price;
            const pct = (diff / a.price) * 100;
            const dir = pct >= 0 ? 'up' : 'down';
            this.tip.innerHTML = `<b style="color:${dir === 'up' ? '#4CAF7D' : '#D96456'}">${pct.toFixed(2)}%</b> · ${diff.toFixed(this.digits)} price · ${a.price.toFixed(this.digits)} → ${b.price.toFixed(this.digits)}`;
            setTimeout(() => { this.tip.style.display = 'none'; this.tip.textContent = ''; }, 4200);
            this.pendingPoint = null;
          }
        }
      });
    }

    setTool(tool) {
      this.tool = tool;
      this.pendingPoint = null;
      this.container.style.cursor = tool === 'cursor' ? '' : 'crosshair';
    }

    /* -------------------------------------------------------- snapshots */
    snapshot(count = 90) {
      return this.candles.slice(-count).map((c) => [c.time, c.open, c.high, c.low, c.close]);
    }
    snapshotLevels() {
      const levels = {};
      const p = this.indicatorPack;
      const last = this.candles[this.candles.length - 1]?.close;
      levels.last = last;
      if (this.drawings.lines.length) {
        levels.userLines = this.drawings.lines.map((l) => +l.price.toFixed(this.digits));
        levels.entry = levels.userLines[0];
      }
      if (p) {
        levels.atr = p.atr14; levels.vwap = p.vwap; levels.rsi = p.rsi14;
        levels.pivot = p.pivots?.P; levels.r1 = p.pivots?.R1; levels.s1 = p.pivots?.S1;
        levels.swingHigh = p.swingHigh; levels.swingLow = p.swingLow;
      }
      if (this.markers?.length) {
        const m = this.markers[this.markers.length - 1];
        levels.markerPrice = null; levels.markerTime = m.time;
      }
      return levels;
    }

    destroy() {
      if (this.destroyed) return;
      this.destroyed = true;
      panes.delete(this);
      try { this.ro?.disconnect(); } catch {}
      try { this.chart.remove(); } catch {}
      try { this.tip?.remove(); } catch {}
    }
  }

  /* --------------------------------------------------------- sparkline */
  function sparkline(container, values, { color = '#4CAF7D', height = 26 } = {}) {
    const c = LC.createChart(container, Object.assign({}, THEME, {
      height, width: container.clientWidth || 74, handleScroll: false, handleScale: false,
      timeScale: { visible: false }, rightPriceScale: { visible: false },
      grid: { vertLines: { visible: false }, horzLines: { visible: false } },
      crosshair: { mode: 2, vertLine: { visible: false }, horzLine: { visible: false } },
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: 'transparent' },
    }));
    const s = c.addAreaSeries({ lineColor: color, topColor: color.replace(')', ',.28)').replace('rgb', 'rgba'), bottomColor: 'rgba(0,0,0,0)', lineWidth: 1.4, priceLineVisible: false, lastValueVisible: false });
    s.setData(values);
    return c;
  }

  /* ------------------------------------------------- mini (shared) chart */
  function miniChart(container, snapshot, { symbol = '', height = 172, color = '#C9A94C' } = {}) {
    if (!LC || !snapshot?.length) { container.innerHTML = '<div class="empty">No chart snapshot</div>'; return null; }
    const digits = ETV.state.symbolMap[symbol]?.digits ?? 2;
    const c = LC.createChart(container, Object.assign({}, THEME, {
      height, width: container.clientWidth || 520, handleScroll: false, handleScale: false,
      timeScale: { visible: false }, rightPriceScale: { visible: false },
      crosshair: { mode: 2, vertLine: { labelVisible: false }, horzLine: { labelVisible: false } },
      layout: { background: { type: 'solid', color: 'transparent' }, textColor: 'transparent', fontSize: 10 },
      localization: { priceFormatter: (p) => p.toFixed(digits) },
    }));
    const candles = snapshot.map(([t, o, h, l, cl]) => ({ time: t, open: o, high: h, low: l, close: cl }));
    const s = c.addCandlestickSeries({ upColor: '#4CAF7D', downColor: '#D96456', borderVisible: false, wickUpColor: '#4CAF7D', wickDownColor: '#D96456', priceLineVisible: true, lastValueVisible: true, priceLineColor: color });
    s.setData(candles);
    c.timeScale().fitContent();
    const ro = new ResizeObserver(() => {
      if (!container.isConnected) { try { ro.disconnect(); c.remove(); } catch {} return; }
      const w = container.clientWidth;
      if (w) { try { c.applyOptions({ width: w }); } catch {} }
    });
    ro.observe(container);
    return c;
  }

  /** Lightweight-charts is strict: times must be ascending + unique, values finite. */
  function sanitize(rows, valueKey = 'value') {
    const seen = new Set();
    return (rows || [])
      .filter((r) => r && Number.isFinite(r.time) && Number.isFinite(
        typeof r[valueKey] === 'number' ? r[valueKey] : r.close))
      .sort((a, b) => a.time - b.time)
      .filter((r) => (seen.has(r.time) ? false : (seen.add(r.time), true)));
  }

  return { ChartPane, miniChart, sparkline, toHeikinAshi, panes, COLORS, sanitize };
})();
