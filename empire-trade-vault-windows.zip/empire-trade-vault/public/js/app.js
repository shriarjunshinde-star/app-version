/* ═══════════════════════════════════════════════════════════════════════
   App shell — auth, navigation, ticker, command palette, live wiring
   ═══════════════════════════════════════════════════════════════════════ */
(() => {
  const { el, fmt, state } = ETV;
  const $ = (id) => document.getElementById(id);

  const NAV = [
    { group: 'Trading' },
    { id: 'dashboard', label: 'Dashboard', icon: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>' },
    { id: 'terminal', label: 'Terminal', icon: '<path d="M4 20V10M12 20V4M20 20v-7"/><path d="M2 20h20"/>' },
    { id: 'trades', label: 'Trades', icon: '<path d="M4 19.5V5a2 2 0 0 1 2-2h12v15H6a2 2 0 0 0-2 2.5Z"/><path d="M4 19.5A2 2 0 0 0 6 21h12"/>' },
    { id: 'journal', label: 'Journal', icon: '<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 9h18M8 2v4M16 2v4M8 14l2.5 2.5L16 11"/>' },
    { id: 'analyze', label: 'Analyze', icon: '<path d="M3 21 9 9l4 6 3-4 5 10z"/>' },
    { group: 'Community' },
    { id: 'messenger', label: 'Messenger', icon: '<path d="M21 12a8 8 0 0 1-8 8H8l-5 3 1.5-4.8A8 8 0 1 1 21 12Z"/>' },
    { id: 'rooms', label: 'Rooms', icon: '<path d="M4 5h16v12H8l-4 3z"/><path d="M8 9h8M8 13h5"/>' },
    { group: 'Evidence' },
    { id: 'playbooks', label: 'Playbooks', icon: '<path d="M4 5a2 2 0 0 1 2-2h11v18H6a2 2 0 0 1-2-2z"/><path d="M8 7h6M8 11h6"/>' },
    { id: 'risk', label: 'Risk MGMT', icon: '<path d="M12 3l8 4v6c0 5-3.5 7.6-8 8-4.5-.4-8-3-8-8V7z"/><path d="M9 12l2 2 4-4"/>' },
    { id: 'watchlist', label: 'Watchlist', icon: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="2.6"/>' },
    { id: 'alerts', label: 'Alerts', icon: '<path d="M18 8a6 6 0 1 0-12 0c0 6-2 7-2 7h16s-2-1-2-7"/><path d="M10.5 20a2 2 0 0 0 3 0"/>' },
    { id: 'news', label: 'News', icon: '<path d="M4 5h16v14H5a1 1 0 0 1-1-1z"/><path d="M7 9h7M7 13h10M7 16h5"/>' },
    { group: 'System' },
    { id: 'settings', label: 'Settings', icon: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>' },
    { id: 'api', label: 'API docs', icon: '<path d="M9 6 3 12l6 6M15 6l6 6-6 6"/>' },
    { id: 'legacy', label: 'Vault demo (v1)', href: '/legacy/empire-trade-vault.html', icon: '<rect x="7" y="2" width="10" height="20" rx="2.4"/><path d="M11 19h2"/>' },
  ];

  /* ═══════════════════════════════════ auth screen */
  const authScreen = $('authScreen');
  const appEl = $('app');
  let mode = 'login';

  /** Live backend check so a dead/offline server is obvious instead of confusing. */
  async function paintServerStatus() {
    const el2 = $('serverStatus');
    if (!el2) return;
    el2.className = 'pill';
    el2.textContent = 'checking server…';
    const h = await ETV.health();
    if (h.ok) {
      el2.className = 'pill green';
      el2.innerHTML = `<span class="live-dot"></span>server online · ${h.symbols ?? 33} markets · ${h.users ?? 0} traders`;
    } else {
      el2.className = 'pill red';
      el2.textContent = 'server offline — run ./start.sh (or npm start)';
      const err = $('authError');
      if (err && !err.textContent) err.textContent = 'The API is not responding: ' + h.reason + '. Start it with ./start.sh in the project folder.';
    }
  }

  /** One click, no typing: enter the owner's demo vault. */
  async function ownerLogin() {
    $('authError').textContent = '';
    const btn = $('btnOwnerLogin');
    btn.disabled = true;
    const original = btn.textContent;
    btn.textContent = 'Signing in…';
    try {
      await doAuth({ username: 'arjunshinde', password: 'arjun123' }, 'login');
    } catch (e) {
      $('authError').textContent = e.message;
    } finally {
      btn.disabled = false;
      btn.textContent = original;
    }
  }

  function showScreen(which) {
    $('authForm').style.display = which === 'login' ? '' : 'none';
    $('forgotForm').style.display = which === 'forgot' ? '' : 'none';
    $('resetForm').style.display = which === 'reset' ? '' : 'none';
    document.querySelector('.auth-tabs').style.display = which === 'login' ? '' : 'none';
    $('authError').textContent = '';
    $('forgotError').textContent = '';
    $('resetError').textContent = '';
  }

  function setMode(next) {
    mode = next;
    document.querySelectorAll('.auth-tab').forEach((x) => x.classList.toggle('active', x.dataset.mode === next));
    const isReg = next === 'register';
    ['regEmail', 'regName', 'regBalance'].forEach((id) => { $(id).style.display = isReg ? '' : 'none'; });
    $('idLabel').textContent = isReg ? 'Username' : 'Email or username';
    $('authForm').username.placeholder = isReg ? 'arjun_trader' : 'you@example.com';
    $('authSubmit').textContent = isReg ? 'Create my account' : 'Sign in';
  }

  document.querySelectorAll('.auth-tab').forEach((t) => t.addEventListener('click', () => setMode(t.dataset.mode)));
  $('btnForgot').addEventListener('click', () => showScreen('forgot'));
  $('btnBackToLogin').addEventListener('click', () => showScreen('login'));

  /* ── verification link handler: /verify-email?token=… ── */
  async function handleVerifyToken(token) {
    showScreen('login');
    const note = $('authError');
    note.className = 'auth-note';
    note.textContent = 'Confirming your email…';
    try {
      const r = await ETV.api('/auth/verify-email', { method: 'POST', body: { token } });
      note.innerHTML = `<b>Email confirmed.</b> ${r.user?.email ? r.user.email : ''} — sign in to continue.`;
      $('authForm').username.value = r.user?.email || r.user?.username || '';
      history.replaceState({}, '', '/');
    } catch (e) {
      note.className = 'auth-error';
      note.textContent = e.message;
    }
  }

  /* ── reset link handler: /reset-password?token=… ── */
  let resetToken = '';
  function handleResetToken(token) {
    resetToken = token;
    showScreen('reset');
    $('resetError').className = 'auth-note';
    $('resetError').textContent = 'Link accepted — choose a new password below.';
  }

  /* ── forgot password submit ── */
  $('forgotForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = e.target.email.value.trim();
    const box = $('forgotError');
    box.className = 'auth-error';
    box.textContent = '';
    try {
      const r = await ETV.api('/auth/forgot-password', { method: 'POST', body: { email } });
      box.className = 'auth-note';
      box.innerHTML = r.emailConfigured
        ? `<b>Check your inbox.</b> If ${email} is registered you'll get a reset link within a minute.`
        : `<b>Email is not configured on this server.</b> Reset link (dev only):<br><a href="${r.devResetLink || '#'}">${r.devResetLink || 'unavailable'}</a>`;
    } catch (err) { box.textContent = err.message; }
  });

  /* ── reset password submit ── */
  $('resetForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const { password, confirm } = e.target;
    const box = $('resetError');
    box.className = 'auth-error';
    if (password.value !== confirm.value) { box.textContent = 'Passwords do not match'; return; }
    try {
      const r = await ETV.api('/auth/reset-password', { method: 'POST', body: { token: resetToken, password: password.value } });
      ETV.setToken(r.token);
      history.replaceState({}, '', '/');
      await enter(r.user);
    } catch (err) { box.textContent = err.message; }
  });
  document.querySelectorAll('.chip[data-user]').forEach((c) => c.addEventListener('click', async () => {
    $('authError').textContent = '';
    try { await doAuth({ username: c.dataset.user, password: c.dataset.pass || 'empire123' }, 'login'); }
    catch (e) { $('authError').textContent = e.message; }
  }));

  $('authForm').addEventListener('submit', (e) => { e.preventDefault(); submitAuth(); });
  setMode('login');

  async function doAuth(payload, kind) {
    const res = await ETV.api('/auth/' + kind, { method: 'POST', body: payload });
    if (!res || !res.token) throw new Error('The server did not return a session token — try again.');
    ETV.setToken(res.token);
    if (!ETV.state.token) throw new Error('This browser is blocking storage, so the session cannot be saved.');
    await enter(res.user);
    return res;
  }

  async function submitAuth() {
    const form = $('authForm');
    const box = $('authError');
    box.textContent = '';
    const payload = {
      username: form.username.value.trim(),
      password: form.password.value,
      email: mode === 'register' ? form.email.value.trim() : undefined,
      displayName: form.displayName.value.trim() || undefined,
      startBalance: Number(form.startBalance.value) || undefined,
    };
    if (!payload.username || !payload.password) {
      box.textContent = 'Enter your email (or username) and password — or press “Enter the demo vault”.';
      return;
    }
    if (mode === 'register' && !payload.email) { box.textContent = 'Email is required — it is how you sign in and recover the account.'; return; }
    if (mode === 'register' && payload.password.length < 8) { box.textContent = 'Password must be at least 8 characters.'; return; }
    try {
      const res = await doAuth(payload, mode === 'register' ? 'register' : 'login');
      if (mode === 'register' && res) {
        if (res.verificationSent) {
          ETV.toast(res.emailConfigured ? 'Confirmation email sent' : 'Account created',
            res.emailConfigured ? 'Check your inbox to confirm your address.' : 'SMTP is not configured, so no email was sent yet.', 'good');
        }
        if (res.devVerifyLink) {
          const note = $('authError');
          note.className = 'auth-note';
          note.innerHTML = `<b>Development mode:</b> email isn't configured, so here is your confirmation link — <a href="${res.devVerifyLink}">confirm ${payload.email}</a>`;
        }
      }
    } catch (e) { box.textContent = e.message; }
  }

  /* ═══════════════════════════════════ shell */
  function renderNav() {
    const nav = $('sideNav');
    nav.innerHTML = '';
    NAV.forEach((n) => {
      if (n.group) { nav.append(el('div', { class: 'nav-group-label', text: n.group })); return; }
      if (n.href) {
        nav.append(el('a', { class: 'nav-item', href: n.href, target: '_blank', rel: 'noopener', style: { textDecoration: 'none' } },
          el('span', { html: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${n.icon}</svg>` }),
          el('span', { text: n.label })));
        return;
      }
      nav.append(el('button', { class: 'nav-item', dataset: { view: n.id }, onclick: () => ETV.go(n.id) },
        el('span', { html: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${n.icon}</svg>` }),
        el('span', { text: n.label }),
        el('span', { class: 'nav-count', id: 'nav-' + n.id, style: { display: 'none' } })));
    });
  }

  function renderMobileNav() {
    const strip = $('mobileNav');
    strip.innerHTML = '';
    NAV.filter((n) => n.id && !n.href).forEach((n) => strip.append(el('button', {
      dataset: { view: n.id }, text: n.label, onclick: () => ETV.go(n.id),
    })));
    ETV.on('navigate', ({ view }) => strip.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.view === view)));
  }

  function renderTicker() {
    const ticker = $('ticker');
    const symbols = ['XAUUSD', 'EURUSD', 'GBPUSD', 'USDINR', 'BTCUSD', 'ETHUSD', 'NAS100', 'SPX500', 'NIFTY50', 'BANKNIFTY', 'USOIL', 'USDJPY'];
    ticker.innerHTML = '';
    symbols.forEach((s) => {
      const q = ETV.quote(s);
      ticker.append(el('button', { class: 'tick', onclick: () => ETV.openTerminal(s, state.chart.tf) },
        el('span', { class: 'ts', text: s }),
        el('span', { class: 'tp ' + (q.changePct >= 0 ? 'up' : 'down'), text: fmt.price(s, q.price) }),
        el('span', { class: 'tp ' + (q.changePct >= 0 ? 'up' : 'down'), style: { fontSize: '11px' }, text: fmt.pct(q.changePct) })));
    });
  }

  function renderSession() {
    const dots = $('sessionDots');
    const set = (sessions) => {
      dots.innerHTML = '';
      (sessions || []).forEach((s) => dots.append(el('span', { class: 'sdot' + (s.open ? ' on' : ''), title: s.name + (s.open ? ' open' : ' closed') })));
    };
    // hydrate immediately from the API, then stay in sync with ticks
    ETV.api('/market/sessions').then((s) => { set(s.sessions); }).catch(() => {});
    ETV.on('tick', (p) => set(p.sessions?.sessions));
    setInterval(() => { $('clockUtc').textContent = new Date().toISOString().slice(11, 16) + ' UTC'; }, 1000);
  }

  async function applyBranding() {
    try {
      const cfg = await ETV.api('/auth/config');
      const set = (id, v) => { const n = $(id); if (n && v) n.textContent = v; };
      set('brandName', (cfg.appName || 'Arjun').toUpperCase());
      set('brandTagline', cfg.owner || 'Trading desk');
      document.title = `${cfg.appName || 'Arjun'} — ${cfg.tagline || 'Trading terminal'}`;
      ETV.state.config = cfg;
      if (!cfg.emailConfigured) {
        const b = document.createElement('div');
        b.className = 'verify-banner';
        b.style.display = 'none';
        b.id = 'mailBanner';
        b.innerHTML = '<span>✉</span><span>Email is not configured on this server (SMTP_HOST) — verification and reset links appear in the server console.</span>';
        document.getElementById('viewHost')?.prepend(b);
      }
    } catch { /* branding is cosmetic */ }
  }

  function renderUser() {
    const u = state.user;
    const block = $('sideUser');
    block.innerHTML = '';
    block.append(ETV.avatar(u, 30),
      el('div', { style: { minWidth: 0 } }, el('div', { class: 'un', text: u.display_name }), el('div', { class: 'ur', text: '@' + u.username })),
      el('span', { class: 'spacer' }),
      el('button', { class: 'icon-btn', title: 'Sign out', onclick: () => ETV.logout(), html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M15 17l5-5-5-5M20 12H9M12 3H6a1 1 0 0 0-1 1v16a1 1 0 0 0 1 1h6"/></svg>' }));
  }

  async function refreshNavCounts() {
    try {
      const [groups, alerts, unread] = await Promise.all([
        ETV.api('/social/groups'), ETV.api('/market/alerts'), ETV.api('/social/unread').catch(() => null),
      ]);
      const msgs = Number.isFinite(unread?.total) ? unread.total : groups.reduce((a, g) => a + (g.unread || 0), 0);
      const setCount = (id, n) => { const n2 = $('nav-' + id); if (n2) { n2.textContent = n; n2.style.display = n ? '' : 'none'; } };
      setCount('rooms', groups.length);
      setCount('messenger', msgs);
      setCount('alerts', alerts.filter((a) => a.status === 'active').length);
    } catch { /* ignore */ }
  }


  /* ═══════════════════════════════════ router */
  const HOST = 'viewHost';
  async function show(view, params) {
    const v = ETV.views[view] || ETV.views.dashboard;
    const host = $(HOST);
    host.dispatchEvent(new Event('etv:leave'));
    host.innerHTML = '';
    state.view = view;
    document.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.view === view));
    try {
      await v.render(host, params);
    } catch (e) {
      console.error(e);
      host.append(el('div', { class: 'empty', text: 'This view failed to render: ' + e.message }));
    }
    host.scrollTop = 0;
    refreshNavCounts();
  }
  ETV.on('navigate', ({ view, params }) => show(view, params));

  /* ═══════════════════════════════════ notifications drawer */
  async function notifPanel() {
    const rows = await ETV.api('/notifications');
    const list = el('div', { style: { maxHeight: '60vh', overflowY: 'auto' } });
    if (!rows.length) list.append(el('div', { class: 'empty', text: 'Nothing yet.' }));
    rows.forEach((n) => list.append(el('div', { class: 'news-item' },
      el('div', { style: { fontSize: '13px', fontWeight: '600' }, text: n.title }),
      el('div', { class: 'news-meta', text: `${n.body} · ${fmt.timeAgo(n.created_at)}` }))));
    ETV.modal({ title: 'Notifications', body: list, footer: [el('button', { class: 'btn', text: 'Mark all read', onclick: async () => { await ETV.api('/notifications/read', { method: 'POST' }); $('notifBadge').classList.add('hidden'); ETV.toast('Inbox cleared'); } })] });
    await ETV.api('/notifications/read', { method: 'POST' });
    $('notifBadge').classList.add('hidden');
  }

  async function refreshBadge() {
    try {
      const rows = await ETV.api('/notifications');
      const unread = rows.filter((n) => !n.read).length;
      const b = $('notifBadge');
      b.textContent = unread;
      b.classList.toggle('hidden', !unread);
    } catch { /* ignore */ }
  }

  // keep the nav badges honest when a room is marked read or a message lands
  ETV.on('unread:changed', () => refreshNavCounts());

  /* ═══════════════════════════════════ command palette */
  function palette() {
    const host = $('paletteHost');
    if (host.classList.contains('open')) { host.classList.remove('open'); host.innerHTML = ''; return; }
    const input = el('input', { placeholder: 'Jump to market, trader, room or command…' });
    const results = el('div', { class: 'palette-results' });
    host.innerHTML = '';
    host.append(el('div', { class: 'palette-bg', onclick: () => palette() }),
      el('div', { class: 'palette' }, input, results));
    host.classList.add('open');
    setTimeout(() => input.focus(), 30);

    const COMMANDS = [
      ['Dashboard', 'command', () => ETV.go('dashboard')],
      ['Terminal — chart', 'command', () => ETV.go('terminal')],
      ['New order', 'command', () => ETV.orderModal()],
      ['Trade blotter', 'command', () => ETV.go('trades')],
      ['Journal entry', 'command', () => ETV.go('journal')],
      ['Edge analytics', 'command', () => ETV.go('analyze')],
      ['Messenger', 'command', () => ETV.go('messenger')],
      ['Trading rooms', 'command', () => ETV.go('rooms')],
      ['Playbooks', 'command', () => ETV.go('playbooks')],
      ['Risk management', 'command', () => ETV.go('risk')],
      ['Price alerts', 'command', () => ETV.go('alerts')],
      ['Watchlist', 'command', () => ETV.go('watchlist')],
      ['News & calendar', 'command', () => ETV.go('news')],
      ['Settings', 'command', () => ETV.go('settings')],
      ['API reference', 'command', () => ETV.go('api')],
    ];

    let timer = null;
    async function run(q) {
      results.innerHTML = '';
      const query = q.trim();
      const cmds = COMMANDS.filter(([l]) => l.toLowerCase().includes(query.toLowerCase()));
      let data = { symbols: [], users: [], groups: [] };
      if (query.length) { try { data = await ETV.api('/search?q=' + encodeURIComponent(query)); } catch {} }
      else { data = { symbols: state.symbols.slice(0, 6), users: [], groups: [] }; }

      const add = (icon, title, sub, fn) => results.append(el('button', { class: 'pres', style: { width: '100%', textAlign: 'left' }, onclick: () => { palette(); fn(); } },
        el('div', { class: 'pi', text: icon }), el('div', {}, el('div', { class: 'pt', text: title }), el('div', { class: 'ps', text: sub }))));

      if (cmds.length) { results.append(el('div', { class: 'eyebrow', style: { padding: '8px 12px 2px' }, text: 'Commands' })); cmds.slice(0, 6).forEach(([l, , fn]) => add('⌘', l, 'action', fn)); }
      if (data.symbols.length) { results.append(el('div', { class: 'eyebrow', style: { padding: '8px 12px 2px' }, text: 'Markets' })); data.symbols.slice(0, 7).forEach((s) => add('$', s.symbol, `${s.name} · ${fmt.price(s.symbol, ETV.quote(s.symbol).price)}`, () => ETV.openTerminal(s.symbol, state.chart.tf))); }
      if (data.users?.length) { results.append(el('div', { class: 'eyebrow', style: { padding: '8px 12px 2px' }, text: 'Traders' })); data.users.forEach((u) => add('@', u.display_name, '@' + u.username, () => { ETV.go('messenger'); setTimeout(() => ETV.emit('room:focus', `dm:${Math.min(u.id, state.user.id)}:${Math.max(u.id, state.user.id)}`), 400); })); }
      if (data.groups?.length) { results.append(el('div', { class: 'eyebrow', style: { padding: '8px 12px 2px' }, text: 'Rooms' })); data.groups.forEach((g) => add('#', g.name, g.topic || 'room', () => ETV.go('messenger', { room: 'g:' + g.id }))); }
      if (!results.children.length) results.append(el('div', { class: 'empty', text: 'Nothing matches that.' }));
    }
    input.addEventListener('input', () => { clearTimeout(timer); timer = setTimeout(() => run(input.value), 160); });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const first = results.querySelector('.pres');
        if (first) first.click();
      }
      if (e.key === 'Escape') palette();
    });
    run('');
  }

  /* ═══════════════════════════════════ boot */
  async function enter(user) {
    state.user = user || await ETV.api('/auth/me').then((r) => r.user);
    // a hiccup in these side-loads must never block sign-in
    try { state.accounts = await ETV.api('/accounts'); }
    catch (e) { state.accounts = []; console.warn('[boot] accounts:', e.message); ETV.toast('Account list unavailable', e.message, 'bad'); }
    try { await ETV.boot(); }
    catch (e) { console.warn('[boot] market index:', e.message); }
    authScreen.classList.add('hidden');
    appEl.classList.remove('hidden');
    renderNav(); renderMobileNav(); renderUser(); renderTicker(); renderSession();
    applyBranding();
    ETV.connect();
    await refreshBadge();
    await show('dashboard');

    ETV.on('tick', () => { renderTicker(); });
    ETV.on('quotes', () => { renderTicker(); });
    ETV.on('live', (l) => {
      const fs = $('feedStatus');
      fs.className = 'feed-status ' + (l.connected ? 'live' : 'offline');
      fs.innerHTML = `<span class="dot"></span>${l.connected ? 'socket live · ' + (state.live.source || 'feed') : 'reconnecting…'}`;
    });
    ETV.on('alert', refreshBadge);
    ETV.on('positions', refreshBadge);
    ETV.on('message', (m) => { refreshBadge(); if (state.view !== 'messenger' && m.user_id !== state.user.id) { const g = m.room.startsWith('g:') ? 'room' : 'DM'; ETV.toast(`New ${g} message`, `${m.display_name}: ${(m.body || m.kind).slice(0, 70)}`); } });
    setInterval(refreshBadge, 60000);

    $('openPalette').addEventListener('click', palette);
    $('btnMenu').addEventListener('click', palette);
    $('btnQuickOrder').addEventListener('click', () => ETV.orderModal());
    $('btnNotif').addEventListener('click', notifPanel);
    $('btnNews').addEventListener('click', () => ETV.go('news'));
    window.addEventListener('keydown', (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); palette(); }
      if (e.key === 'Escape') { $('paletteHost').classList.remove('open'); }
    });
    $('btnOwnerLogin')?.addEventListener('click', ownerLogin);
    paintServerStatus();
    if (state.user && state.user.email && !state.user.emailVerified) {
      setTimeout(() => {
        const host = document.getElementById('viewHost');
        if (!host || document.getElementById('verifyNudge')) return;
        const nudge = document.createElement('div');
        nudge.className = 'verify-banner';
        nudge.id = 'verifyNudge';
        nudge.innerHTML = `✉ <span>Confirm your email <b>${state.user.email}</b> to secure password recovery.</span>`;
        const btn = document.createElement('button');
        btn.className = 'btn btn-xs btn-gold';
        btn.textContent = 'Resend link';
        btn.onclick = async () => {
          const r = await ETV.api('/auth/resend-verification', { method: 'POST' });
          ETV.toast(r.emailConfigured ? 'Confirmation email sent' : 'Reset link (dev)', r.devVerifyLink || 'Check your inbox.', 'good');
        };
        nudge.append(btn);
        host.prepend(nudge);
      }, 1500);
    }
    const fs0 = $('feedStatus');
    fs0.className = 'feed-status live';
    fs0.innerHTML = `<span class="dot"></span>socket live · ${state.live.source || 'feed'}`;
  }

  (async function start() {
    $('btnOwnerLogin')?.addEventListener('click', ownerLogin);
    paintServerStatus();
    if (state.user && state.user.email && !state.user.emailVerified) {
      setTimeout(() => {
        const host = document.getElementById('viewHost');
        if (!host || document.getElementById('verifyNudge')) return;
        const nudge = document.createElement('div');
        nudge.className = 'verify-banner';
        nudge.id = 'verifyNudge';
        nudge.innerHTML = `✉ <span>Confirm your email <b>${state.user.email}</b> to secure password recovery.</span>`;
        const btn = document.createElement('button');
        btn.className = 'btn btn-xs btn-gold';
        btn.textContent = 'Resend link';
        btn.onclick = async () => {
          const r = await ETV.api('/auth/resend-verification', { method: 'POST' });
          ETV.toast(r.emailConfigured ? 'Confirmation email sent' : 'Reset link (dev)', r.devVerifyLink || 'Check your inbox.', 'good');
        };
        nudge.append(btn);
        host.prepend(nudge);
      }, 1500);
    }

    const params = new URLSearchParams(location.search);
    const token = params.get('token');
    if (token && location.pathname === '/verify-email') { authScreen.classList.remove('hidden'); setMode('login'); handleVerifyToken(token); return; }
    if (token && location.pathname === '/reset-password') { authScreen.classList.remove('hidden'); setMode('login'); handleResetToken(token); return; }

    if (!state.token) { authScreen.classList.remove('hidden'); return; }
    try {
      const me = await ETV.api('/auth/me');
      await enter(me.user);
    } catch (e) {
      ETV.setToken('');                       // stale session → back to the sign-in card
      authScreen.classList.remove('hidden');
      if (!e.offline) $('authError').textContent = 'Your previous session expired. Sign in again — or press “Enter the demo vault”.';
    }
  })();
})();
