# Deploying Arjun

Arjun is a single Node service: Express API + **SQLite database file** + **local uploads folder**, serving the frontend and a socket.io realtime channel. That means deployment is just "run the container, keep two folders".

| What must persist | Where |
|---|---|
| The database (accounts, trades, journal, messages, rooms) | `data/arjun.db` |
| Photos + documents sent in the messenger | `uploads/` |

Everything else in the image is disposable.

---

## 1 · Environment variables

Copy `.env.example` → `.env` (or paste the values into your host's dashboard).

| Variable | Needed? | Notes |
|---|---|---|
| `NODE_ENV` | yes | `production` |
| `PORT` | host sets it | Render/Fly inject their own |
| `PUBLIC_URL` | yes | `https://your-domain.com` — used inside verification / reset emails |
| `ALLOWED_ORIGINS` | recommended | comma separated; blank = allow every origin |
| `JWT_SECRET` | **yes** | `openssl rand -hex 32` (Windows: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`) |
| `SMTP_HOST` `SMTP_PORT` `SMTP_SECURE` `SMTP_USER` `SMTP_PASS` `MAIL_FROM` | for real email | see §4 |
| `DATA_DIR` `DB_PATH` `UPLOAD_DIR` | on containers | point both at the mounted volume |
| `MAX_UPLOAD_MB` | optional | default 20 |
| `REQUIRE_EMAIL_VERIFICATION` | optional | `true` blocks sign-in until the email is confirmed |
| `OWNER_PASSWORD` | optional | password for the seeded owner account on a brand-new database |
| `TRUST_PROXY` | on a proxy | keeps real client IPs (rate limiting) correct |
| `ALLOW_IFRAME` | optional | `false` sends `X-Frame-Options: sameorigin` |

On a **fresh volume** Arjun seeds a complete demo desk automatically (first boot takes ~30–60 s because it fetches live prices). Set `SEED_ON_EMPTY=false` to start empty instead.

---

## 2 · Pick a host

### Option A — Render (easiest, has a blueprint)
1. Push this folder to a GitHub repo.
2. Render → **New → Blueprint** → pick the repo (it reads `render.yaml`).
3. Fill the `sync: false` values: `PUBLIC_URL`, `ALLOWED_ORIGINS` (both your `https://<name>.onrender.com`), plus SMTP if you have it.
4. Deploy. Health check is `/api/health`; the 1 GB disk at `/var/data` holds the DB and uploads.
> The **free** plan has no disk — your data resets on redeploy. Use starter+ (or Docker/Fly) for real use.

### Option B — Fly.io (container + volumes, closest to India)
```bash
fly launch --copy-config --name arjun-desk --region bom   # uses fly.toml + Dockerfile
fly volumes create arjun_data    --size 1 --region bom
fly volumes create arjun_uploads --size 1 --region bom
fly secrets set JWT_SECRET=$(openssl rand -hex 32) \
  PUBLIC_URL=https://arjun-desk.fly.dev \
  ALLOWED_ORIGINS=https://arjun-desk.fly.dev \
  SMTP_HOST=smtp.example.com SMTP_PORT=587 SMTP_USER=... SMTP_PASS=... \
  MAIL_FROM="Arjun <no-reply@your-domain.com>"
fly deploy
```

### Option C — any VPS with Docker (full control, cheapest for many users)
```bash
git clone <your-repo> arjun && cd arjun
cp .env.example .env && nano .env         # set JWT_SECRET, PUBLIC_URL, SMTP…
docker compose up -d --build
docker compose logs -f arjun
```
Put nginx/Caddy in front for TLS. Minimal nginx block:
```nginx
server {
  listen 443 ssl; server_name your-domain.com;
  client_max_body_size 25m;                 # allow the 20 MB uploads
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;         # socket.io
    proxy_set_header Connection "upgrade";
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_read_timeout 300s;
  }
}
```
Caddy does the same in two lines: `your-domain.com { reverse_proxy 127.0.0.1:3000 }`.

### Option D — Railway / Heroku-style (Procfile)
`npm ci --omit=dev` → `node server/index.js`, and add a volume mounted at `/app/data` (and one for `/app/uploads`).

---

## 3 · Backups

The whole application state is two folders. Copy them and you have a full backup:
```bash
docker compose exec arjun sh -c "sqlite3 /app/data/arjun.db '.backup /tmp/b.db'"   # if sqlite3 present
# or simply, while the app is running:
docker run --rm -v arjun_arjun-data:/data -v $PWD:/out alpine tar czf /out/arjun-backup.tgz -C /data .
```
Nightly cron on the host works well:
```bash
0 2 * * * cd /srv/arjun && docker compose exec -T arjun tar czf - -C /app data uploads > /backups/arjun-$(date +\%F).tgz
```

---

## 4 · Email (SMTP)

Arjun sends: verification link, password reset, welcome note. Without SMTP it still works — mail is written to the console **and** to the `emails` table, and in development the API returns the action link (`devVerifyLink` / `devResetLink`) so you can test the flow.

Any SMTP provider works — Gmail app password, Zoho, Brevo, Resend, Postmark, SES:

| Provider | `SMTP_HOST` | Port |
|---|---|---|
| Gmail (app password) | `smtp.gmail.com` | 587 |
| Zoho Mail | `smtp.zoho.in` | 587 |
| Brevo | `smtp-relay.brevo.com` | 587 |
| Resend | `smtp.resend.com` | 587 |
| Amazon SES | `email-smtp.<region>.amazonaws.com` | 587 |

Set `SMTP_SECURE=false` for 587 (STARTTLS) and `true` for 465. `MAIL_FROM` must be an address your provider allows, e.g. `MAIL_FROM="Arjun <no-reply@your-domain.com>"`.

---

## 5 · Security checklist before going live

- [ ] `JWT_SECRET` is a long random value (the server warns at boot if it is still the default).
- [ ] `PUBLIC_URL` + `ALLOWED_ORIGINS` point at your real domain (HTTPS).
- [ ] `owner` password changed from `arjun123` — sign in as `arjunshinde`, then **Settings → Change password**.
- [ ] SMTP configured, then `REQUIRE_EMAIL_VERIFICATION=true` if you want confirmed-only sign-ups.
- [ ] Volumes mounted for `/app/data` **and** `/app/uploads`.
- [ ] TLS terminated in front of the app (nginx / Caddy / Render / Fly all do this).
- [ ] Backups scheduled (both folders).
- [ ] `TRUST_PROXY=true` when behind a proxy so rate limits see real IPs.

Already built in: helmet security headers, compression, per-IP rate limits (600 req/min on `/api`, 40 per 15 min on auth, 12 emails/hour), JWT auth on every non-public route, upload type + size whitelist, `nosniff` + forced download for documents, path-traversal-safe static serving, soft-delete for messages, graceful `SIGTERM` shutdown.

---

## 6 · Verifying a deployment

```bash
curl https://your-domain.com/api/health
# {"ok":true,"app":"Arjun","env":"production","counts":{...},"online":n}
```
Then open the site, sign in, send a photo and a PDF in a room, and confirm the file appears in `/uploads` inside the volume. Restart the container and check the message is still there — that proves the volume is wired correctly.
